-- phpMyAdmin SQL Dump
-- version phpStudy 2014
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2017 �?09 �?15 �?08:10
-- 服务器版本: 5.5.53
-- PHP 版本: 5.6.27

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `pinphp`
--

-- --------------------------------------------------------

--
-- 表的结构 `pin_ad`
--

CREATE TABLE IF NOT EXISTS `pin_ad` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `board_id` smallint(5) NOT NULL,
  `type` varchar(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `url` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `extimg` varchar(255) NOT NULL,
  `extval` varchar(200) NOT NULL,
  `desc` varchar(255) NOT NULL,
  `start_time` int(10) NOT NULL,
  `end_time` int(10) NOT NULL,
  `clicks` int(10) NOT NULL DEFAULT '0',
  `add_time` int(10) NOT NULL DEFAULT '0',
  `ordid` tinyint(3) unsigned NOT NULL DEFAULT '255',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=45 ;

--
-- 转存表中的数据 `pin_ad`
--

INSERT INTO `pin_ad` (`id`, `board_id`, `type`, `name`, `url`, `content`, `extimg`, `extval`, `desc`, `start_time`, `end_time`, `clicks`, `add_time`, `ordid`, `status`) VALUES
(1, 1, 'image', '品牌推荐', 'http://lmys.tmall.com', '1211/24/50b06470c9599.jpg', '1211/24/50b06473d4e1d.jpg', '', '浪漫一身', 1353686400, 1488211200, 0, 0, 1, 1),
(12, 1, 'image', '英伦时尚', 'http://miyi.tmall.com/', '1211/24/50b07cc4003e3.jpg', '1211/24/50b07cc6038cf.jpg', '', '米逸旗舰', 1353686400, 1488211200, 0, 0, 2, 1),
(27, 15, 'image', '【demo-shopping】首页banner01', '', '1709/04/59acf09d9cc19.jpg', '', '', '【demo-shopping】首页banner01', 1504454400, 1535990400, 0, 0, 255, 1),
(10, 3, 'image', '米逸皮具', 'http://miyi.tmall.com/', '1211/24/50b072064ff24.jpg', '', '0', '为经典而生', 1353686400, 1385222400, 0, 0, 255, 1),
(5, 2, 'text', '达人申请', 'http://www.pinphp.com', '做最自信的生活达人', '1211/24/50b06839c237c.jpg', '', '达人申请', 1353686400, 1385222400, 0, 0, 255, 1),
(6, 2, 'text', '母婴时尚', 'http://121love13.taobao.com', '辣妈们快看这里', '1211/24/50b06913cb59d.gif', '', '母婴时尚', 1353686400, 1385222400, 0, 0, 255, 1),
(7, 2, 'text', '沙发', 'index.php?m=book&a=cate&cid=235', '给你一个温暖的角落', '1211/24/50b06a05dd1fe.jpg', '', '沙发', 1353686400, 1385222400, 0, 0, 255, 1),
(8, 2, 'text', '围巾', 'index.php?m=book&a=cate&cid=205', '暖上心头，完美配饰', '1211/24/50b06dec66c35.jpg', '', '围巾', 1353686400, 1385222400, 0, 0, 255, 1),
(9, 4, 'image', '米逸', '', '1211/24/50b06e6194838.jpg', '', '', '', 1353686400, 1385222400, 0, 0, 255, 1),
(11, 1, 'image', '时尚品味', 'http://liulianjia.taobao.com/', '1211/24/50b0776f1ab77.jpg', '1211/24/50b07771bdac6.jpg', '', '榴莲菇凉秀', 1353686400, 1488211200, 0, 0, 3, 1),
(14, 5, 'image', '利趣', '', '1211/24/50b08153260ad.jpg', '', '', '', 1353686400, 1417276800, 0, 0, 255, 1),
(15, 10, 'image', '利趣', 'http://www.liqu.com', '1211/24/50b0819343e93.gif', '', '', '', 1353686400, 1385222400, 0, 0, 255, 1),
(17, 11, 'flash', '游戏', 'http://resmkt.dipan.com/reg/7711009/1009.html?pid=10091180151077', '1211/24/50b08300e4cf5.swf', '', '', '', 1353686400, 1417276800, 0, 0, 255, 1),
(18, 3, 'image', '经典传奇', 'http://ruiniansp.tmall.com', '1211/24/50b0845d1e50f.jpg', '', '', '瑞年氨基酸', 1353686400, 1385222400, 0, 0, 255, 1),
(20, 3, 'image', '浪漫一生', 'http://lmys.tmall.com', '1211/24/50b08d95e0b3f.jpg', '', '0', '女人的店，生活的店', 1353686400, 1385222400, 0, 0, 255, 1),
(21, 6, 'image', '专辑按钮上方', 'index.php?m=album&a=index', '1211/24/50b08e24a3f67.png', '', '', '', 1353686400, 1385222400, 0, 0, 255, 1),
(22, 7, 'text', '文字广告', '', '发现时尚经典、收集站外美图、创建个性专辑、购买价廉商品', '', '', '', 1353686400, 1385222400, 0, 0, 255, 1),
(23, 14, 'image', '详细页导航下', 'http://detail.tmall.com/item.htm?id=16006377960', '1211/26/50b2d21ba9791.jpg', '', '', '', 1353686400, 1385222400, 0, 0, 255, 1),
(24, 9, 'flash', '游戏', '', '1211/24/50b099c716787.swf', '', '', '', 1353686400, 1385222400, 0, 0, 255, 1),
(25, 8, 'text', '新浪微博', 'http://weibo.com/dob2c', '新浪微博', '1211/26/50b2ec2508a1f.jpeg', '', '', 1353859200, 1416931200, 0, 0, 255, 1),
(26, 8, 'text', '腾讯微博', 'http://t.qq.com/asfangsong9939', '腾讯微博', '1211/26/50b2ecde1ec17.jpg', '', '', 1353859200, 1416931200, 0, 0, 255, 1),
(28, 15, 'image', '【demo-shopping】首页banner02', '', '1709/04/59ad02edb1792.jpg', '', '', '【demo-shopping】首页banner02', 1504454400, 1535990400, 0, 0, 255, 1),
(29, 15, 'image', '【demo-shopping】首页banner03', '', '1709/04/59ad032017729.jpg', '', '', '【demo-shopping】首页banner03', 1504454400, 1535990400, 0, 0, 255, 1),
(30, 15, 'image', '【demo-shopping】首页banner04', '', '1709/04/59ad033c9c5b0.jpg', '', '', '【demo-shopping】首页banner04', 1504454400, 1535990400, 0, 0, 255, 1),
(31, 16, 'image', '【demo-shopping】首页广告ban01', 'http://www.qjy168.com/', '1709/04/59ad0554922fa.jpg', '', '', '【demo-shopping】首页广告ban01', 1504454400, 1535990400, 0, 0, 255, 1),
(32, 16, 'image', '【demo-shopping】首页广告ban02', 'http://www.qjy168.com/', '1709/04/59ad057517161.jpg', '', '', '【demo-shopping】首页广告ban01', 1504454400, 1535990400, 0, 0, 255, 1),
(33, 16, 'image', '【demo-shopping】首页广告ban03', 'http://www.qjy168.com/', '1709/04/59ad059840fc9.jpg', '', '', '【demo-shopping】首页广告ban01', 1504454400, 1535990400, 0, 0, 255, 1),
(34, 17, 'image', '【demo-shopping】首页左侧宣传广告', 'http://www.qjy168.com/', '1709/04/59ad09d77238b.jpg', '', '', '【demo-shopping】首页广告04,规格自定义', 1504454400, 1535990400, 0, 0, 255, 1),
(35, 18, 'image', '【demo-shopping】首页中部广告1', '', '1709/04/59ad242180185.jpg', '', '', '【demo-shopping】首页中部广告1', 1504454400, 1535990400, 0, 0, 255, 1),
(36, 18, 'image', '【demo-shopping】首页中部广告2', '', '1709/04/59ad24c20de97.jpg', '', '', '【demo-shopping】首页中部广告2', 1504454400, 1535990400, 0, 0, 255, 1),
(37, 19, 'image', '【demo-shopping】热推广告banner', '', '1709/05/59adf7e516529.jpg', '', '', '【demo-shopping】热推广告banner', 1504540800, 1536076800, 0, 0, 255, 1),
(38, 20, 'image', '【demo-shopping】热推列表广告01', '', '1709/05/59adf9b438dd8.jpg', '', '', '【demo-shopping】热推列表广告01', 1504540800, 1536076800, 0, 0, 255, 1),
(39, 20, 'image', '【demo-shopping】热推列表广告02', '', '1709/05/59adfa39c1ffc.jpg', '', '', '【demo-shopping】热推列表广告01', 1504540800, 1536076800, 0, 0, 255, 1),
(40, 20, 'image', '【demo-shopping】热推列表广告03', '', '1709/05/59adfa6110939.jpg', '', '', '【demo-shopping】热推列表广告03', 1504540800, 1536076800, 0, 0, 255, 1),
(41, 20, 'image', '【demo-shopping】热推列表广告04', '', '1709/05/59adfa7f85837.jpg', '', '', '【demo-shopping】热推列表广告04', 1504540800, 1536076800, 0, 0, 255, 1),
(42, 21, 'image', '【demo-shopping】首页资讯广告位01', '', '1709/05/59adfd71db1cf.jpg', '', '', '【demo-shopping】首页资讯广告位01', 1504540800, 1536076800, 0, 0, 255, 1),
(43, 21, 'image', '【demo-shopping】首页资讯广告位02', '', '1709/05/59adfd9a2634b.jpg', '', '', '【demo-shopping】首页资讯广告位01', 1504540800, 1536076800, 0, 0, 255, 1),
(44, 21, 'image', '【demo-shopping】首页资讯广告位03', '', '1709/05/59adfdb955883.jpg', '', '', '【demo-shopping】首页资讯广告位03', 1504540800, 1536076800, 0, 0, 255, 1);

-- --------------------------------------------------------

--
-- 表的结构 `pin_adboard`
--

CREATE TABLE IF NOT EXISTS `pin_adboard` (
  `id` smallint(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `tpl` varchar(20) NOT NULL,
  `width` smallint(5) NOT NULL,
  `height` smallint(5) NOT NULL,
  `description` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=22 ;

--
-- 转存表中的数据 `pin_adboard`
--

INSERT INTO `pin_adboard` (`id`, `name`, `tpl`, `width`, `height`, `description`, `status`) VALUES
(1, '首页焦点图', 'indexfocus', 439, 283, '小图调用扩展图', 1),
(2, '首页会员下方', 'indexmb', 0, 0, '图片调用扩展图', 1),
(3, '专辑页面焦点图', 'albumfocus', 470, 283, '扩展字段值为用户ID', 1),
(4, '首页会员下方-左', 'banner', 142, 44, '', 1),
(5, '首页会员下方-右', 'banner', 135, 44, '', 1),
(6, '专辑页创建按钮上方', 'banner', 170, 60, '', 1),
(7, '专辑页创建按钮下方', 'banner', 0, 0, '', 1),
(8, '关注我们', 'followus', 0, 0, '小图调用扩展图', 1),
(9, '首页顶部伸缩广告', 'banner', 960, 90, '', 1),
(10, '导航下方横幅', 'banner', 960, 90, '', 1),
(11, '底部横幅', 'banner', 960, 90, '', 1),
(12, '发现页热门标签下方', 'banner', 200, 100, '', 1),
(13, '详细页评论下方', 'banner', 390, 90, '', 1),
(14, '详细页导航下方', 'banner', 960, 90, '', 1),
(15, '【demo-shopping】首页banner', 'indexfocus', 1920, 550, '【demo-shopping】首页banner', 1),
(16, '【demo-shopping】首页广告位', 'albumfocus', 390, 196, '【demo-shopping】首页广告位1', 1),
(17, '【demo-shopping】首页左侧广告位', 'stretch', 320, 660, '【demo-shopping】首页左侧广告位', 1),
(18, '【demo-shopping】首页中部广告', 'stretch', 1920, 424, '【demo-shopping】首页中部广告', 1),
(19, '【demo-shopping】首页热推横幅广告', 'banner', 894, 284, '【demo-shopping】首页热推广告', 1),
(20, '【demo-shopping】首页热推列表广告', 'albumfocus', 288, 189, '【demo-shopping】首页热推列表广告', 1),
(21, '【demo-shopping】首页资讯广告位', 'albumfocus', 602, 272, '【demo-shopping】首页资讯广告位', 1);

-- --------------------------------------------------------

--
-- 表的结构 `pin_admin`
--

CREATE TABLE IF NOT EXISTS `pin_admin` (
  `id` mediumint(6) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(32) NOT NULL,
  `role_id` smallint(5) NOT NULL,
  `last_ip` varchar(15) NOT NULL,
  `last_time` int(10) NOT NULL DEFAULT '0',
  `email` varchar(50) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_name` (`username`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- 转存表中的数据 `pin_admin`
--

INSERT INTO `pin_admin` (`id`, `username`, `password`, `role_id`, `last_ip`, `last_time`, `email`, `status`) VALUES
(1, 'admin', 'c80e999bdba0e8956428491050529392', 1, '127.0.0.1', 1505437787, 'admin@qq.com', 1);

-- --------------------------------------------------------

--
-- 表的结构 `pin_admin_auth`
--

CREATE TABLE IF NOT EXISTS `pin_admin_auth` (
  `role_id` tinyint(3) NOT NULL,
  `menu_id` smallint(6) NOT NULL,
  KEY `role_id` (`role_id`,`menu_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `pin_admin_role`
--

CREATE TABLE IF NOT EXISTS `pin_admin_role` (
  `id` tinyint(3) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `remark` text NOT NULL,
  `ordid` tinyint(3) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `pin_admin_role`
--

INSERT INTO `pin_admin_role` (`id`, `name`, `remark`, `ordid`, `status`) VALUES
(1, '超级管理员', '超级管理员', 0, 1);

-- --------------------------------------------------------

--
-- 表的结构 `pin_album`
--

CREATE TABLE IF NOT EXISTS `pin_album` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cate_id` smallint(4) unsigned NOT NULL DEFAULT '0',
  `uid` int(10) unsigned NOT NULL,
  `uname` varchar(20) NOT NULL,
  `title` varchar(200) NOT NULL,
  `intro` varchar(255) DEFAULT NULL,
  `banner` varchar(255) DEFAULT NULL,
  `cover_cache` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `ordid` tinyint(3) unsigned NOT NULL DEFAULT '255',
  `likes` int(10) NOT NULL,
  `items` int(10) unsigned NOT NULL DEFAULT '0',
  `follows` int(10) unsigned NOT NULL DEFAULT '0',
  `is_index` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `add_time` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

--
-- 转存表中的数据 `pin_album`
--

INSERT INTO `pin_album` (`id`, `cate_id`, `uid`, `uname`, `title`, `intro`, `banner`, `cover_cache`, `status`, `ordid`, `likes`, `items`, `follows`, `is_index`, `add_time`) VALUES
(1, 1, 14, '泡芙小米粒', '【大自然的小精灵。】', '', '', 'a:5:{i:0;a:2:{s:3:"img";s:72:"http://img03.taobaocdn.com/bao/uploaded/i3/T197PPXgVoXXcy8OM._112623.jpg";s:5:"intro";s:79:"淘金币 【远步正品】 2012新款 星旗条纹男女帆布鞋情侣鞋子";}i:1;a:2:{s:3:"img";s:72:"http://img04.taobaocdn.com/bao/uploaded/i4/T1wBy7XflaXXX6UvwV_020442.jpg";s:5:"intro";s:86:"MIYI新款鳄鱼纹翻盖潮手包牛皮女包单肩包复古包小包包 清仓包邮";}i:2;a:2:{s:3:"img";s:72:"http://img04.taobaocdn.com/bao/uploaded/i4/T1qdnCXlBhXXbCT873_051140.jpg";s:5:"intro";s:82:"浪漫一身 2012秋装新款 通勤OL开衫V领长袖 纯色百搭时尚小外套";}i:3;a:2:{s:3:"img";s:72:"http://img02.taobaocdn.com/bao/uploaded/i2/T1h4F7XbdAXXce_eEZ_032143.jpg";s:5:"intro";s:79:"浪漫一身 2012秋装新款 专柜正品 亮色带帽长袖休闲格子外套";}i:4;a:2:{s:3:"img";s:72:"http://img03.taobaocdn.com/bao/uploaded/i3/T1o2R8XdRtXXcjNLgV_020417.jpg";s:5:"intro";s:82:"浪漫一身 2012冬装新款 专柜正品 韩版大翻领格纹毛呢大衣外套";}}', 1, 255, 0, 5, 0, 0, 1353896347),
(2, 1, 10, '设计系小女生', '甜美商品惹人爱♡', '', '', 'a:4:{i:0;a:2:{s:3:"img";s:72:"http://img03.taobaocdn.com/bao/uploaded/i3/T1hG1IXelfXXcX4o.9_105150.jpg";s:5:"intro";s:64:"【远步正品】  2011冬季时尚女士平底雪地靴 棉鞋";}i:1;a:2:{s:3:"img";s:72:"http://img01.taobaocdn.com/bao/uploaded/i1/T1tWOuXmFTXXXbvKDb_093608.jpg";s:5:"intro";s:84:"MIYI 2012秋冬新款头层牛皮手提包单肩包水桶真皮女包通勤包包邮";}i:2;a:2:{s:3:"img";s:72:"http://img03.taobaocdn.com/bao/uploaded/i3/T1Xo6dXhptXXb5KSA9_104530.jpg";s:5:"intro";s:77:"浪漫一身 2012秋装新款 线下 专柜正品 韩版双排扣风衣外套";}i:3;a:2:{s:3:"img";s:72:"http://img03.taobaocdn.com/bao/uploaded/i3/T1L.urXiFJXXa2x2w2_043755.jpg";s:5:"intro";s:80:"浪漫一身 2012冬装新款 专柜正品 欧美范 羊毛毛纯色呢短外套";}}', 1, 255, 0, 4, 0, 0, 1353896347),
(3, 2, 19, '安土桃山', '一个人的世界', '', '', 'a:3:{i:0;a:2:{s:3:"img";s:25:"1709/04/59ad1128d930c.jpg";s:5:"intro";s:29:"智利进口新鲜蓝莓 4盒";}i:1;a:2:{s:3:"img";s:72:"http://img01.taobaocdn.com/bao/uploaded/i1/T1RKfEXkxkXXc.bh3U_014824.jpg";s:5:"intro";s:77:"【远步正品】 加厚松高鞋休闲棉帆布鞋 韩版厚底帆松糕鞋";}i:2;a:2:{s:3:"img";s:72:"http://img01.taobaocdn.com/bao/uploaded/i1/T1FGLNXmJbXXbjSLvb_093718.jpg";s:5:"intro";s:85:"浪漫一身 2012秋装新款 专柜正品 休闲长袖薄外套修身立领棒球衫";}}', 1, 255, 0, 3, 0, 0, 1353896347),
(4, 1, 8, '枕水而眠', '❀色彩_谁是那个人', '', '', 'a:5:{i:0;a:2:{s:3:"img";s:25:"1709/04/59ad11bb8a1eb.jpg";s:5:"intro";s:25:"国产绿奇异果 16颗 ";}i:1;a:2:{s:3:"img";s:25:"1709/04/59ad116696dfb.jpg";s:5:"intro";s:26:"美国进口红啤梨 6个";}i:2;a:2:{s:3:"img";s:72:"http://img04.taobaocdn.com/bao/uploaded/i4/T1ac2vXcRvXXXE1hsU_014747.jpg";s:5:"intro";s:84:"【远步正品】2012秋冬新款 英伦印花松糕厚底高帮鞋 松糕鞋女款";}i:3;a:2:{s:3:"img";s:72:"http://img02.taobaocdn.com/bao/uploaded/i2/T1x7C0XhxqXXbW6xwT_012127.jpg";s:5:"intro";s:79:"特卖款2012秋冬新款榴莲家 风衣帅气外套 带帽风衣外套LLS1009";}i:4;a:2:{s:3:"img";s:72:"http://img01.taobaocdn.com/bao/uploaded/i1/T1sPfKXcxbXXXPQIYb_123402.jpg";s:5:"intro";s:87:"MIYI 秋冬新款复古风撞色手提包单肩包斜挎包包 机车包邮差包女包";}}', 1, 255, 0, 9, 0, 0, 1353896347),
(5, 1, 18, '晨雪熙', '一颗心的距离', '', '', 'a:5:{i:0;a:2:{s:3:"img";s:25:"1709/04/59ad12a82ee26.jpg";s:5:"intro";s:34:"浙江涌泉蜜桔无核桔子5斤";}i:1;a:2:{s:3:"img";s:25:"1709/04/59ad10fab7bf9.jpg";s:5:"intro";s:30:"南非进口黄柠檬 6个装 ";}i:2;a:2:{s:3:"img";s:72:"http://img03.taobaocdn.com/bao/uploaded/i3/T1A4n_XglcXXcUv5g0_035537.jpg";s:5:"intro";s:85:"远步正品 韩版潮 厚底松糕鞋 高帮布鞋子学生休闲鞋 女鞋帆布鞋";}i:3;a:2:{s:3:"img";s:72:"http://img04.taobaocdn.com/bao/uploaded/i4/T1ugbYXkpdXXa56jsZ_033049.jpg";s:5:"intro";s:76:"预售款 榴莲家2012秋冬新款 RENEEVON★秋款绝美公主外套20398";}i:4;a:2:{s:3:"img";s:72:"http://img01.taobaocdn.com/bao/uploaded/i1/T1vN18Xe8wXXabtx7U_014829.jpg";s:5:"intro";s:81:"浪漫一身 品牌女装 专柜正品 春夏装中长款抽皱褶无袖短外套";}}', 1, 255, 0, 9, 0, 1, 1353896348),
(6, 1, 6, '起个名字太累', '总有一个角落，卸下你的包袱', '', '', 'a:5:{i:0;a:2:{s:3:"img";s:72:"http://img02.taobaocdn.com/bao/uploaded/i2/T1_tHLXn4fXXXLjDMT_013219.jpg";s:5:"intro";s:72:"【远步正品】2012秋冬季印花高帮帆布鞋 韩版 学生女鞋";}i:1;a:2:{s:3:"img";s:72:"http://img01.taobaocdn.com/bao/uploaded/i1/T1wnqyXXNfXXa2j1I0_034801.jpg";s:5:"intro";s:73:"【远步正品】 越狱米勒系列厚底帆布鞋松糕鞋 欧美ca276";}i:2;a:2:{s:3:"img";s:72:"http://img04.taobaocdn.com/bao/uploaded/i4/T1ZArWXkllXXX.ujTX_085705.jpg";s:5:"intro";s:85:"远步正品 韩版潮 厚底松糕高帮帆布鞋子 学生休闲鞋 女式帆布鞋";}i:3;a:2:{s:3:"img";s:72:"http://img01.taobaocdn.com/bao/uploaded/i1/T17FtRXaBGXXa3dJs6_061244.jpg";s:5:"intro";s:83:"MIYI2012新款全牛皮简约主义韩版糖果女包包复古手提大包单肩包";}i:4;a:2:{s:3:"img";s:72:"http://img02.taobaocdn.com/bao/uploaded/i2/T1Ad58XctiXXcyC0s8_100130.jpg";s:5:"intro";s:86:"MIYI韩版新款真皮女包包2012新款潮女包水桶通勤斜挎单肩机车包邮";}}', 1, 255, 0, 7, 0, 1, 1353896348),
(7, 1, 20, '熊小熊zz', '放慢脚步，细细地品味生活', '', '', 'a:5:{i:0;a:2:{s:3:"img";s:25:"1709/04/59ad119657ec3.jpg";s:5:"intro";s:29:"美国进口无籽红提 1kg ";}i:1;a:2:{s:3:"img";s:72:"http://img02.taobaocdn.com/bao/uploaded/i2/T1Ag54XbtuXXXfz.I5_060343.jpg";s:5:"intro";s:84:"榴莲家2012秋季女装 韩版波点翻袖小西装外套 修身休闲西装 20072";}i:2;a:2:{s:3:"img";s:72:"http://img04.taobaocdn.com/bao/uploaded/i4/T1.Ly7XmhmXXcoBArb_124637.jpg";s:5:"intro";s:85:"MIYI休闲糖果色邮差包韩版撞色单肩斜挎包磨砂牛皮复古包包女包";}i:3;a:2:{s:3:"img";s:72:"http://img01.taobaocdn.com/bao/uploaded/i1/T1xtK1XnlkXXaGp4E6_062100.jpg";s:5:"intro";s:86:"MIYI单肩小包2012新款潮时尚韩版休闲牛皮欧美红色新娘手拿女包包";}i:4;a:2:{s:3:"img";s:72:"http://img02.taobaocdn.com/bao/uploaded/i2/T1m397XXJlXXaqnVg0_033805.jpg";s:5:"intro";s:88:"MIYI时尚可爱复古学院风糖果色单肩斜跨女包包小包牛皮邮差包特价";}}', 1, 255, 0, 7, 0, 1, 1353896348),
(8, 1, 17, 'V小莲小莲V', '美好时光', '', '', 'a:3:{i:0;a:2:{s:3:"img";s:72:"http://img02.taobaocdn.com/bao/uploaded/i2/T1E2O9XhFvXXbOmjZW_024241.jpg";s:5:"intro";s:83:"【远步正品】2012秋冬新款 韩版星星印花女式低帮帆布鞋学生鞋";}i:1;a:2:{s:3:"img";s:72:"http://img01.taobaocdn.com/bao/uploaded/i1/T1h8HdXXXkXXcz7r.4_051921.jpg";s:5:"intro";s:85:"MIYI 鳄鱼纹晚宴包链条包单肩包 牛皮潮女包漆皮菱格包 清仓包邮";}i:2;a:2:{s:3:"img";s:72:"http://img03.taobaocdn.com/bao/uploaded/i3/T1ms_UXi0bXXb4juQ1_041036.jpg";s:5:"intro";s:85:"浪漫一身 2012秋装新款 通勤长袖翻领  OL时尚帅气小西装式短外套";}}', 1, 255, 0, 3, 0, 0, 1353896349),
(9, 1, 12, '跳房子123', '❤ Home❥小小的空间', '', '', 'a:4:{i:0;a:2:{s:3:"img";s:72:"http://img02.taobaocdn.com/bao/uploaded/i2/T1RR2RXkNcXXceltU7_063938.jpg";s:5:"intro";s:60:"【远步正品】男女款 越狱 低帮帆布鞋 情侣鞋";}i:1;a:2:{s:3:"img";s:72:"http://img04.taobaocdn.com/bao/uploaded/i4/T1DxC8Xi4eXXXO8ZZ5_054947.jpg";s:5:"intro";s:86:"MIYI米逸 新款英伦小包卡其色单肩包复古牛皮撞色复古女包邮差包";}i:2;a:2:{s:3:"img";s:72:"http://img02.taobaocdn.com/bao/uploaded/i2/T1X697XjXbXXcMnfM._112229.jpg";s:5:"intro";s:85:"MIYI 红色斜纹牛皮单肩包包女包 2012新款潮包结婚包新娘包晚宴包";}i:3;a:2:{s:3:"img";s:72:"http://img04.taobaocdn.com/bao/uploaded/i4/T1oAbZXkldXXcH5ug2_043616.jpg";s:5:"intro";s:84:"MIYI 英国2013新款头层牛皮撞色真皮女包小包单肩包信封邮差包邮";}}', 1, 255, 0, 4, 0, 0, 1353902316),
(10, 1, 7, '咕咕是一只猫', '手作王国', '', '', 'a:2:{i:0;a:2:{s:3:"img";s:72:"http://img01.taobaocdn.com/bao/uploaded/i1/T18U_SXklkXXcPno7._084022.jpg";s:5:"intro";s:85:"MIYI 2012秋冬新款欧美时尚牛皮邮差包单肩斜挎包 复古百搭女大包";}i:1;a:2:{s:3:"img";s:72:"http://img02.taobaocdn.com/bao/uploaded/i2/T1qrdqXXlwXXa_4U38_101909.jpg";s:5:"intro";s:85:"MIYI 2012英伦复古学院风牛皮撞色邮差包 时尚单肩斜挎潮包女士包";}}', 1, 255, 0, 2, 0, 0, 1353902316),
(11, 1, 11, '彩色淘', '怀旧系，寻找时光的芳', '', '', 'a:5:{i:0;a:2:{s:3:"img";s:72:"http://img01.taobaocdn.com/bao/uploaded/i1/T16.j3XdlbXXa8hGnb_123051.jpg";s:5:"intro";s:89:"【一淘专享价】远步经典糖果低帮系带韩版帆布鞋 潮 男女款情侣鞋";}i:1;a:2:{s:3:"img";s:72:"http://img01.taobaocdn.com/bao/uploaded/i1/T1EzLEXaFlXXcpN3g3_050111.jpg";s:5:"intro";s:88:"淘金币 【远步正品】 经典糖果低帮系带韩版帆布鞋 潮 男女款情侣";}i:2;a:2:{s:3:"img";s:72:"http://img03.taobaocdn.com/bao/uploaded/i3/T1rnuWXbXwXXaT3dnb_093439.jpg";s:5:"intro";s:85:"【清仓】MIYI 简约手提包女包 单肩牛皮大包通勤包 购物包肩挎包";}i:3;a:2:{s:3:"img";s:72:"http://img02.taobaocdn.com/bao/uploaded/i2/T1DsrnXbRkXXanw8_b_124847.jpg";s:5:"intro";s:85:"MIYI 2012新款秋冬头层牛皮女包菱格链条包单肩包 真皮女包宴会包";}i:4;a:2:{s:3:"img";s:72:"http://img03.taobaocdn.com/bao/uploaded/i3/T1yj1xXg01XXX_.NQ8_100702.jpg";s:5:"intro";s:85:"MIYI 英伦学院风复古糖果色牛皮剑桥包 单肩包时尚女包 小包潮包";}}', 1, 255, 0, 5, 0, 1, 1353902316),
(12, 1, 15, 'Prickleman', '小小角落', '', '', 'a:1:{i:0;a:2:{s:3:"img";s:72:"http://img04.taobaocdn.com/bao/uploaded/i4/T1_HC7XhlwXXbMVu7W_023330.jpg";s:5:"intro";s:81:"MIYI秋冬新款牛皮复古OL通勤单肩斜挎女包包英伦潮款特价包邮";}}', 1, 255, 0, 1, 0, 0, 1353902316),
(13, 1, 16, 'Eudora_寻寻', '温暖的小世界。', '', '', 'a:2:{i:0;a:2:{s:3:"img";s:72:"http://img01.taobaocdn.com/bao/uploaded/i1/T1msjzXfFmXXbavIAU_013829.jpg";s:5:"intro";s:76:"【远步正品】2012秋冬新款 印花高帮帆布鞋 韩版 学生女鞋";}i:1;a:2:{s:3:"img";s:72:"http://img04.taobaocdn.com/bao/uploaded/i4/T1gz6JXj8iXXblFxU8_100704.jpg";s:5:"intro";s:87:"MIYI 欧美鸵鸟纹头层牛皮单肩包斜跨复古女包邮差包 手提真皮女包";}}', 1, 255, 0, 2, 0, 0, 1353902317),
(14, 1, 13, '想太多妹子', '创意也能DIY', '', '', 'a:5:{i:0;a:2:{s:3:"img";s:72:"http://img01.taobaocdn.com/bao/uploaded/i1/T1K_vfXlJaXXakVJ37_064254.jpg";s:5:"intro";s:77:"【远步正品】2012秋冬新款 星星印花女式低帮帆布鞋学生鞋";}i:1;a:2:{s:3:"img";s:72:"http://img03.taobaocdn.com/bao/uploaded/i3/T1qYjFXbXfXXXvyygU_015147.jpg";s:5:"intro";s:63:"【远步正品】 男女帆布鞋韩版 高帮 学生情侣鞋";}i:2;a:2:{s:3:"img";s:72:"http://img03.taobaocdn.com/bao/uploaded/i3/T1M463XeBdXXb0fkM9_074304.jpg";s:5:"intro";s:85:"预售定金 榴莲家 英伦双排扣毛呢外套牛角扣肩章羊毛呢大衣20459";}i:3;a:2:{s:3:"img";s:72:"http://img04.taobaocdn.com/bao/uploaded/i4/T1srf5Xm8XXXXV8lI__110350.jpg";s:5:"intro";s:82:"预售款 榴莲家秋冬装新款呢大衣女 双排扣气质呢大衣外套20281";}i:4;a:2:{s:3:"img";s:72:"http://img02.taobaocdn.com/bao/uploaded/i2/T1O9mQXndwXXXD_O.0_035651.jpg";s:5:"intro";s:85:"MIYI 2012秋冬新款欧美头层牛皮单肩斜挎包 韩版真皮女包通勤包包";}}', 1, 255, 0, 5, 0, 1, 1353902318),
(15, 1, 9, 'wingsa区', '韩范范思密达', '', '', 'a:2:{i:0;a:2:{s:3:"img";s:72:"http://img02.taobaocdn.com/bao/uploaded/i2/T1MDaHXc0rXXaonAs9_104246.jpg";s:5:"intro";s:80:"【远步正品】2012秋冬新款时尚女士平底加绒中筒雪地靴 包邮";}i:1;a:2:{s:3:"img";s:72:"http://img04.taobaocdn.com/bao/uploaded/i4/T1l3fIXkFgXXc53Jk9_102745.jpg";s:5:"intro";s:86:"【远步正品】2012秋冬新款男女帆布鞋韩版 女 潮 高帮 学生情侣鞋";}}', 1, 255, 0, 2, 0, 0, 1353902642);

-- --------------------------------------------------------

--
-- 表的结构 `pin_album_cate`
--

CREATE TABLE IF NOT EXISTS `pin_album_cate` (
  `id` smallint(4) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `img` varchar(255) NOT NULL,
  `ordid` tinyint(3) unsigned NOT NULL DEFAULT '255',
  `albums` int(10) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `seo_title` varchar(255) NOT NULL,
  `seo_keys` varchar(255) NOT NULL,
  `seo_desc` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=28 ;

--
-- 转存表中的数据 `pin_album_cate`
--

INSERT INTO `pin_album_cate` (`id`, `name`, `img`, `ordid`, `albums`, `status`, `seo_title`, `seo_keys`, `seo_desc`) VALUES
(1, '甜美', '', 0, 0, 1, '', '', ''),
(2, '欧美', '', 0, 0, 1, '', '', ''),
(3, '街拍', '', 0, 0, 1, '', '', ''),
(4, '复古', '', 0, 0, 1, '', '', ''),
(5, '明星', '', 0, 0, 1, '', '', ''),
(6, '穿搭', '', 0, 0, 1, '', '', ''),
(7, '品牌', '', 0, 0, 1, '', '', ''),
(8, '婚礼', '', 0, 0, 1, '', '', ''),
(9, '美妆', '', 0, 0, 1, '', '', ''),
(10, '美发', '', 0, 0, 1, '', '', ''),
(11, '个性', '', 0, 0, 1, '', '', ''),
(12, '日系', '', 0, 0, 1, '', '', ''),
(13, '韩系', '', 0, 0, 1, '', '', ''),
(14, '清新', '', 0, 0, 1, '', '', ''),
(15, '英伦', '', 0, 0, 1, '', '', ''),
(16, 'BF风', '', 0, 0, 1, '', '', ''),
(17, '朋克', '', 0, 0, 1, '', '', ''),
(18, '优雅', '', 0, 0, 1, '', '', ''),
(19, '名媛', '', 0, 0, 1, '', '', ''),
(20, '森女', '', 0, 0, 1, '', '', ''),
(21, '性感', '', 0, 0, 1, '', '', ''),
(22, '流行', '', 0, 0, 1, '', '', ''),
(23, '时尚', '', 0, 0, 1, '', '', ''),
(24, '简约', '', 0, 0, 1, '', '', ''),
(25, '民族', '', 0, 0, 1, '', '', ''),
(26, '原单', '', 0, 0, 1, '', '', ''),
(27, 'OL', '', 0, 0, 1, '', '', '');

-- --------------------------------------------------------

--
-- 表的结构 `pin_album_comment`
--

CREATE TABLE IF NOT EXISTS `pin_album_comment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `album_id` int(10) unsigned NOT NULL,
  `uid` int(10) unsigned NOT NULL,
  `uname` varchar(20) NOT NULL,
  `info` text NOT NULL,
  `add_time` int(10) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `pin_album_follow`
--

CREATE TABLE IF NOT EXISTS `pin_album_follow` (
  `uid` int(10) NOT NULL,
  `album_id` int(10) NOT NULL,
  `add_time` int(10) NOT NULL,
  UNIQUE KEY `uid` (`uid`,`album_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `pin_album_item`
--

CREATE TABLE IF NOT EXISTS `pin_album_item` (
  `album_id` int(10) unsigned NOT NULL,
  `item_id` int(10) unsigned NOT NULL,
  `intro` varchar(255) NOT NULL,
  `add_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`album_id`,`item_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `pin_album_item`
--

INSERT INTO `pin_album_item` (`album_id`, `item_id`, `intro`, `add_time`) VALUES
(1, 1, '浪漫一身 2012冬装新款 专柜正品 韩版大翻领格纹毛呢大衣外套', 1353896347),
(2, 2, '浪漫一身 2012冬装新款 专柜正品 欧美范 羊毛毛纯色呢短外套', 1353896347),
(3, 3, '浪漫一身 2012秋装新款 专柜正品 休闲长袖薄外套修身立领棒球衫', 1353896347),
(4, 4, '浪漫一身 2012冬装新款 欧美仿麂皮翻领长袖 修身加厚短外套', 1353896347),
(4, 5, '浪漫一身 2012秋装新款 韩版蝙蝠袖长袖 假两件休闲棉质马甲外套', 1353896347),
(5, 6, '浪漫一身  直筒带帽休闲加薄长款棉衣外套', 1353896348),
(6, 7, '浪漫一身 2012秋装新款 修身街头运动 拉链带帽拼接袋鼠兜短外套', 1353896348),
(5, 8, '浪漫宣言新款春秋修身单扣长袖女装短外套1016111', 1353896348),
(7, 9, '浪漫一身 2012秋装新款 专柜正品 韩版蝙蝠袖西装式针织开衫外套', 1353896348),
(4, 10, '浪漫一身 2012秋装新款 直筒运动休闲长袖 短款立领拉链纯色外套', 1353896348),
(5, 11, '浪漫一身 2012秋装新款 宽松加厚运动休闲 带拉链连帽毛衣外套', 1353896348),
(7, 12, '浪漫一身 2012冬装新款 专柜正品 通勤简约 柳钉拼接时尚短外套', 1353896348),
(1, 13, '浪漫一身 2012秋装新款 专柜正品 亮色带帽长袖休闲格子外套', 1353896348),
(1, 14, '浪漫一身 2012秋装新款 通勤OL开衫V领长袖 纯色百搭时尚小外套', 1353896349),
(4, 15, '浪漫一身 线下专柜正品 2012春装一粒扣短款西装 韩版胸花短外套', 1353896349),
(5, 16, '浪漫一身 线下 专柜正品 2012春装翻领长袖中长款 夹克风衣外套女', 1353896349),
(2, 17, '浪漫一身 2012秋装新款 线下 专柜正品 韩版双排扣风衣外套', 1353896349),
(8, 18, '浪漫一身 2012秋装新款 通勤长袖翻领  OL时尚帅气小西装式短外套', 1353896349),
(6, 19, '浪漫一身 冬装 专柜正品 羊毛毛呢短外套  外套 女装长袖', 1353896349),
(5, 20, '浪漫一身 品牌女装 专柜正品 春夏装中长款抽皱褶无袖短外套', 1353896349),
(9, 21, 'MIYI 英国2013新款头层牛皮撞色真皮女包小包单肩包信封邮差包邮', 1353902316),
(10, 22, 'MIYI 2012英伦复古学院风牛皮撞色邮差包 时尚单肩斜挎潮包女士包', 1353902316),
(11, 23, 'MIYI 英伦学院风复古糖果色牛皮剑桥包 单肩包时尚女包 小包潮包', 1353902316),
(11, 24, 'MIYI 2012新款秋冬头层牛皮女包菱格链条包单肩包 真皮女包宴会包', 1353902316),
(10, 25, 'MIYI 2012秋冬新款欧美时尚牛皮邮差包单肩斜挎包 复古百搭女大包', 1353902316),
(12, 26, 'MIYI秋冬新款牛皮复古OL通勤单肩斜挎女包包英伦潮款特价包邮', 1353902316),
(11, 27, '【清仓】MIYI 简约手提包女包 单肩牛皮大包通勤包 购物包肩挎包', 1353902316),
(4, 28, 'MIYI 秋冬新款复古风撞色手提包单肩包斜挎包包 机车包邮差包女包', 1353902317),
(13, 29, 'MIYI 欧美鸵鸟纹头层牛皮单肩包斜跨复古女包邮差包 手提真皮女包', 1353902317),
(7, 30, 'MIYI时尚可爱复古学院风糖果色单肩斜跨女包包小包牛皮邮差包特价', 1353902317),
(9, 31, 'MIYI 红色斜纹牛皮单肩包包女包 2012新款潮包结婚包新娘包晚宴包', 1353902317),
(9, 32, 'MIYI米逸 新款英伦小包卡其色单肩包复古牛皮撞色复古女包邮差包', 1353902317),
(1, 33, 'MIYI新款鳄鱼纹翻盖潮手包牛皮女包单肩包复古包小包包 清仓包邮', 1353902317),
(2, 34, 'MIYI 2012秋冬新款头层牛皮手提包单肩包水桶真皮女包通勤包包邮', 1353902317),
(7, 35, 'MIYI单肩小包2012新款潮时尚韩版休闲牛皮欧美红色新娘手拿女包包', 1353902318),
(6, 36, 'MIYI韩版新款真皮女包包2012新款潮女包水桶通勤斜挎单肩机车包邮', 1353902318),
(14, 37, 'MIYI 2012秋冬新款欧美头层牛皮单肩斜挎包 韩版真皮女包通勤包包', 1353902318),
(6, 38, 'MIYI2012新款全牛皮简约主义韩版糖果女包包复古手提大包单肩包', 1353902318),
(8, 39, 'MIYI 鳄鱼纹晚宴包链条包单肩包 牛皮潮女包漆皮菱格包 清仓包邮', 1353902318),
(7, 40, 'MIYI休闲糖果色邮差包韩版撞色单肩斜挎包磨砂牛皮复古包包女包', 1353902318),
(14, 41, '预售款 榴莲家秋冬装新款呢大衣女 双排扣气质呢大衣外套20281', 1353902490),
(4, 42, '特卖款2012秋冬新款榴莲家 风衣帅气外套 带帽风衣外套LLS1009', 1353902490),
(7, 43, '榴莲家2012秋季女装 韩版波点翻袖小西装外套 修身休闲西装 20072', 1353902490),
(5, 44, '预售款 榴莲家2012秋冬新款 RENEEVON★秋款绝美公主外套20398', 1353902490),
(14, 45, '预售定金 榴莲家 英伦双排扣毛呢外套牛角扣肩章羊毛呢大衣20459', 1353902490),
(6, 46, '远步正品 韩版潮 厚底松糕高帮帆布鞋子 学生休闲鞋 女式帆布鞋', 1353902641),
(11, 47, '淘金币 【远步正品】 经典糖果低帮系带韩版帆布鞋 潮 男女款情侣', 1353902641),
(11, 48, '【一淘专享价】远步经典糖果低帮系带韩版帆布鞋 潮 男女款情侣鞋', 1353902641),
(14, 49, '【远步正品】 男女帆布鞋韩版 高帮 学生情侣鞋', 1353902641),
(14, 50, '【远步正品】2012秋冬新款 星星印花女式低帮帆布鞋学生鞋', 1353902642),
(9, 51, '【远步正品】男女款 越狱 低帮帆布鞋 情侣鞋', 1353902642),
(6, 52, '【远步正品】 越狱米勒系列厚底帆布鞋松糕鞋 欧美ca276', 1353902642),
(1, 53, '淘金币 【远步正品】 2012新款 星旗条纹男女帆布鞋情侣鞋子', 1353902642),
(4, 54, '【远步正品】2012秋冬新款 英伦印花松糕厚底高帮鞋 松糕鞋女款', 1353902642),
(8, 55, '【远步正品】2012秋冬新款 韩版星星印花女式低帮帆布鞋学生鞋', 1353902642),
(15, 56, '【远步正品】2012秋冬新款男女帆布鞋韩版 女 潮 高帮 学生情侣鞋', 1353902642),
(13, 57, '【远步正品】2012秋冬新款 印花高帮帆布鞋 韩版 学生女鞋', 1353902642),
(3, 58, '【远步正品】 加厚松高鞋休闲棉帆布鞋 韩版厚底帆松糕鞋', 1353902643),
(6, 59, '【远步正品】2012秋冬季印花高帮帆布鞋 韩版 学生女鞋', 1353902643),
(5, 60, '远步正品 韩版潮 厚底松糕鞋 高帮布鞋子学生休闲鞋 女鞋帆布鞋', 1353902643),
(15, 61, '【远步正品】2012秋冬新款时尚女士平底加绒中筒雪地靴 包邮', 1353902643),
(2, 62, '【远步正品】  2011冬季时尚女士平底雪地靴 棉鞋', 1353902643),
(5, 63, '南非进口黄柠檬 6个装 ', 1504514299),
(3, 64, '智利进口新鲜蓝莓 4盒', 1504514345),
(4, 65, '美国进口红啤梨 6个', 1504514406),
(7, 66, '美国进口无籽红提 1kg ', 1504514454),
(4, 67, '国产绿奇异果 16颗 ', 1504514491),
(5, 68, '浙江涌泉蜜桔无核桔子5斤', 1504514728);

-- --------------------------------------------------------

--
-- 表的结构 `pin_article`
--

CREATE TABLE IF NOT EXISTS `pin_article` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `cate_id` smallint(4) unsigned NOT NULL,
  `title` varchar(255) NOT NULL,
  `colors` varchar(10) NOT NULL,
  `author` varchar(100) NOT NULL,
  `tags` varchar(100) NOT NULL,
  `img` varchar(255) NOT NULL,
  `intro` varchar(255) NOT NULL,
  `info` text NOT NULL,
  `comments` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '评论数',
  `hits` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '浏览数',
  `ordid` tinyint(3) unsigned NOT NULL DEFAULT '255' COMMENT '排序值',
  `add_time` int(10) unsigned NOT NULL DEFAULT '0',
  `last_time` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `seo_title` varchar(255) NOT NULL,
  `seo_keys` varchar(255) NOT NULL,
  `seo_desc` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- 转存表中的数据 `pin_article`
--

INSERT INTO `pin_article` (`id`, `cate_id`, `title`, `colors`, `author`, `tags`, `img`, `intro`, `info`, `comments`, `hits`, `ordid`, `add_time`, `last_time`, `status`, `seo_title`, `seo_keys`, `seo_desc`) VALUES
(1, 8, '富士苹果', '', '河南省济源市', '富士 苹果', '', '5.5/kg', '富士苹果', 0, 0, 255, 1504575419, 0, 1, '', '', ''),
(2, 8, '新疆西瓜', '', '新疆乌鲁木齐', '新疆 西瓜', '', '10/kg', '', 0, 0, 255, 1504575475, 0, 1, '', '', ''),
(3, 8, '车厘子', '', '美国洛杉矶', '车厘子', '', '58.5/kg', '', 0, 0, 255, 1504575540, 0, 1, '', '', ''),
(4, 8, '水东菜心', '', '广东茂名水东', '水东 菜心', '', '5.5/kg', '', 0, 0, 255, 1504575916, 0, 1, '', '', ''),
(5, 8, '西兰花', '', '河南省信阳市', '西兰花', '', '3.5/kg', '', 0, 0, 255, 1504575956, 0, 1, '', '', '');

-- --------------------------------------------------------

--
-- 表的结构 `pin_article_cate`
--

CREATE TABLE IF NOT EXISTS `pin_article_cate` (
  `id` smallint(4) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(100) NOT NULL,
  `alias` varchar(50) NOT NULL,
  `img` varchar(255) NOT NULL,
  `pid` smallint(4) unsigned NOT NULL DEFAULT '0',
  `spid` varchar(50) NOT NULL,
  `ordid` smallint(4) unsigned NOT NULL DEFAULT '255',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `seo_title` varchar(255) NOT NULL,
  `seo_keys` varchar(255) NOT NULL,
  `seo_desc` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- 转存表中的数据 `pin_article_cate`
--

INSERT INTO `pin_article_cate` (`id`, `type`, `name`, `alias`, `img`, `pid`, `spid`, `ordid`, `status`, `seo_title`, `seo_keys`, `seo_desc`) VALUES
(1, 1, '网站信息', '', '', 0, '0', 255, 1, '', '', ''),
(2, 1, '关于我们', '', '', 1, '1|', 255, 1, '', '', ''),
(3, 1, '联系我们', '', '', 1, '1|', 255, 1, '', '', ''),
(4, 1, '加入我们', '', '', 1, '1|', 255, 1, '', '', ''),
(5, 1, '内置文章', '', '', 0, '0', 255, 1, '', '', ''),
(6, 1, '积分规则', '', '', 5, '5|', 255, 1, '', '', ''),
(7, 1, '兑换说明', '', '', 5, '5|', 255, 1, '', '', ''),
(8, 0, '【demo-shopping】蔬果资讯', '', '', 0, '0', 255, 1, '', '', '');

-- --------------------------------------------------------

--
-- 表的结构 `pin_article_page`
--

CREATE TABLE IF NOT EXISTS `pin_article_page` (
  `cate_id` smallint(4) unsigned NOT NULL DEFAULT '0',
  `title` varchar(120) NOT NULL,
  `info` text NOT NULL,
  `seo_title` varchar(255) NOT NULL,
  `seo_keys` varchar(255) NOT NULL,
  `seo_desc` text NOT NULL,
  `last_time` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`cate_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `pin_article_page`
--

INSERT INTO `pin_article_page` (`cate_id`, `title`, `info`, `seo_title`, `seo_keys`, `seo_desc`, `last_time`) VALUES
(2, '关于我们', '<div>\r\n	欢迎来到PinPHP－拼品网， 拼品网是一个技术驱动创造时尚的互联网创业型公司，通过搜索引擎、图形处理、视觉搜索等核心技术研发优势，为中国千百万的个人站长提供一个解决如何快速抢建一个社会化的电子商务导购平台，它可以帮助爱美丽的女生找到适合的穿衣搭配、在哪里购买合适的时装搭配网购社区平台；我们将致力于为每一个时尚女孩都能轻松地创建属于自己的搭配宝典库而矢志不移的奉献青春年华。\r\n</div>\r\n<div>\r\n	<br />\r\n</div>\r\n<div>\r\n	　　来逛拼品网&nbsp;，你将发现更多喜爱的搭配风格，找到你最喜欢的时尚元素，你也将发现全球各地流行的风格与趋势，你还能很方便的在线拼贴搭配出你的时尚品味；懂得搭配的女人才更美丽，拉上你的好姐妹们一起来逛拼品网吧！\r\n</div>\r\n<div>\r\n	<br />\r\n</div>\r\n<div>\r\n	　　Logo寓意诠释：化蛹成碟的美丽蜕变，意思是通过来逛拼品网能让女孩们蜕变得更美丽！\r\n</div>', '', '', '', 0),
(3, '联系我们', '<p style="margin-top:0px;margin-bottom:0px;padding:0px;color:#666666;font-family:Arial;font-size:14px;line-height:22px;white-space:normal;background-color:#FFFFFF;">\r\n	联系电话：0571-28058597\r\n</p>\r\n<p style="margin-top:0px;margin-bottom:0px;padding:0px;color:#666666;font-family:Arial;font-size:14px;line-height:22px;white-space:normal;background-color:#FFFFFF;">\r\n	&nbsp;\r\n</p>\r\n<p style="margin-top:0px;margin-bottom:0px;padding:0px;color:#666666;font-family:Arial;font-size:14px;line-height:22px;white-space:normal;background-color:#FFFFFF;">\r\n	官方网站：www.pinphp.com\r\n</p>\r\n<p style="margin-top:0px;margin-bottom:0px;padding:0px;color:#666666;font-family:Arial;font-size:14px;line-height:22px;white-space:normal;background-color:#FFFFFF;">\r\n	&nbsp;\r\n</p>\r\n<p style="margin-top:0px;margin-bottom:0px;padding:0px;color:#666666;font-family:Arial;font-size:14px;line-height:22px;white-space:normal;background-color:#FFFFFF;">\r\n	地址：杭州市万塘路６９号华星科技苑Ａ楼\r\n</p>\r\n<p style="margin-top:0px;margin-bottom:0px;padding:0px;color:#666666;font-family:Arial;font-size:14px;line-height:22px;white-space:normal;background-color:#FFFFFF;">\r\n	&nbsp;\r\n</p>\r\n<p style="margin-top:0px;margin-bottom:0px;padding:0px;color:#666666;font-family:Arial;font-size:14px;line-height:22px;white-space:normal;background-color:#FFFFFF;">\r\n	邮编：３１００１２\r\n</p>', '', '', '', 0),
(4, '加入我们', '<span style="white-space:nowrap;"><strong>岗位名称：信息编辑</strong></span><br />\r\n<span style="white-space:nowrap;">&nbsp; &nbsp;<strong> 岗位职责：&nbsp;</strong></span><br />\r\n<span style="white-space:nowrap;">&nbsp; &nbsp; &nbsp; &nbsp; 1、产业网站内容建设；&nbsp;</span><br />\r\n<span style="white-space:nowrap;">&nbsp; &nbsp; &nbsp; &nbsp; 2、产业数据搜集整理；</span><br />\r\n<span style="white-space:nowrap;">&nbsp;</span><br />\r\n<span style="white-space:nowrap;">&nbsp; &nbsp; <strong>任职要求 ：&nbsp;</strong></span><br />\r\n<span style="white-space:nowrap;">&nbsp; &nbsp; &nbsp; &nbsp; 1、大专以上学历，传媒、新闻、电子商务相关专业优先；&nbsp;</span><br />\r\n<span style="white-space:nowrap;">&nbsp; &nbsp; &nbsp; &nbsp; 2、1年以上互联网行业媒体从业经验，有电子商务相关从业经历者优先；&nbsp;</span><br />\r\n<span style="white-space:nowrap;">&nbsp; &nbsp; &nbsp; &nbsp; 3、熟悉网页制作软件，良好的文字功底、有原创采写经验者优先；&nbsp;</span><br />\r\n<span style="white-space:nowrap;">&nbsp; &nbsp; &nbsp; &nbsp; 4、对新闻、电子商务等产业有持续关注兴趣，良好的英文阅读能力；&nbsp;</span><br />\r\n<span style="white-space:nowrap;">&nbsp; &nbsp; &nbsp; &nbsp; 5、具有较强学习能力和责任心，以及团队合作精神；&nbsp;</span><br />\r\n<span style="white-space:nowrap;">&nbsp; &nbsp; &nbsp; &nbsp; 6、优秀应届毕业生可放宽工作经验要求；</span><br />\r\n<span style="white-space:nowrap;">&nbsp; &nbsp; &nbsp; &nbsp;</span><br />\r\n<span style="white-space:nowrap;">&nbsp; &nbsp; &nbsp; &nbsp; 有意者请发送简历至：HR#insuny.com （#替换成@）</span><br />\r\n<span style="white-space:nowrap;"><br />\r\n</span><br />\r\n<span style="white-space:nowrap;"><strong>岗位名称：开发工程师</strong></span><br />\r\n<span style="white-space:nowrap;"><strong>&nbsp; &nbsp; 岗位职责：&nbsp;</strong></span><br />\r\n<span style="white-space:nowrap;">&nbsp; &nbsp; &nbsp; &nbsp; 1、负责网站系统及B/S架构产品开发；&nbsp;</span><br />\r\n<span style="white-space:nowrap;">&nbsp; &nbsp; &nbsp; &nbsp; 2、负责产品体验优化；</span><br />\r\n<span style="white-space:nowrap;">&nbsp;</span><br />\r\n<span style="white-space:nowrap;">&nbsp; &nbsp;<strong> 任职要求 ：</strong>&nbsp;</span><br />\r\n<span style="white-space:nowrap;">&nbsp; &nbsp; &nbsp; &nbsp; 1、大学专科及以上，计算机相关专业优先；&nbsp;</span><br />\r\n<span style="white-space:nowrap;">&nbsp; &nbsp; &nbsp; &nbsp; 2、2年以上B/S架构开发经验；有独立开发开发经验者优先；&nbsp;</span><br />\r\n<span style="white-space:nowrap;">&nbsp; &nbsp; &nbsp; &nbsp; 3、良好掌握PHP开发语言及MySQL数据库；&nbsp;</span><br />\r\n<span style="white-space:nowrap;">&nbsp; &nbsp; &nbsp; &nbsp; 4、熟练掌握javascript / ajax等；&nbsp;</span><br />\r\n<span style="white-space:nowrap;">&nbsp; &nbsp; &nbsp; &nbsp; 5、有激情，热爱互联网行业，熟悉web2.0应用；</span><br />\r\n<span style="white-space:nowrap;"><br />\r\n</span><br />\r\n<span style="white-space:nowrap;">&nbsp; &nbsp; &nbsp; 有意者请发送简历至：HR#insuny.com（#替换成@）</span><br />\r\n<span style="white-space:nowrap;"><br />\r\n</span><br />\r\n<span style="white-space:nowrap;"><strong>岗位名称：网页设计师</strong></span><br />\r\n<span style="white-space:nowrap;"><strong>&nbsp; &nbsp; 岗位职责：</strong>&nbsp;</span><br />\r\n<span style="white-space:nowrap;">&nbsp; &nbsp; &nbsp; &nbsp; 1、负责网站及B/S架构产品前端界面设计及重构；&nbsp;</span><br />\r\n<span style="white-space:nowrap;">&nbsp; &nbsp; &nbsp; &nbsp; 2、负责产品体验优化；</span><br />\r\n<span style="white-space:nowrap;">&nbsp;</span><br />\r\n<span style="white-space:nowrap;">&nbsp; &nbsp;<strong> 任职要求 ：</strong>&nbsp;</span><br />\r\n<span style="white-space:nowrap;">&nbsp; &nbsp; &nbsp; &nbsp; 1、大学专科及以上，计算机相关专业优先；&nbsp;</span><br />\r\n<span style="white-space:nowrap;">&nbsp; &nbsp; &nbsp; &nbsp; 2、2年以上网站设计经验；有整站设计重构经验者优先；&nbsp;</span><br />\r\n<span style="white-space:nowrap;">&nbsp; &nbsp; &nbsp; &nbsp; 3、良好掌握XHTML，CSS手工书写页面，熟悉W3C标准，精通div+css；&nbsp;</span><br />\r\n<span style="white-space:nowrap;">&nbsp; &nbsp; &nbsp; &nbsp; 4、精通Photoshop、Dreamweaver、Flash等多种网页设计制作软件；&nbsp;</span><br />\r\n<span style="white-space:nowrap;">&nbsp; &nbsp; &nbsp; &nbsp; 5、有激情，热爱互联网行业，熟悉web2.0应用；</span><br />\r\n<span style="white-space:nowrap;"><br />\r\n</span><br />\r\n<span style="white-space:nowrap;">&nbsp; &nbsp; &nbsp; &nbsp;有意者请发送简历至：HR#insuny.com （#替换成@）</span><br />', '', '', '', 0),
(6, '会员加减分规则', '<p>\r\n	<strong>积分兑换</strong>\r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	积分是为了答谢支持PinPHP网站会员而制定的一种奖励方式，您可以进入账户中的积分页面查看积分明细，同时PinPHP会推出各类积分兑换活动，请随时关注关于积分的活动告知。\r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	<strong>积分获得：</strong>\r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	1、会员注册：会员注册即送20点积分，一个账户只能得一次注册积分；\r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	2、每日登录：会员每日首次登录PinPHP网站能获得10积分，每日上限5次；\r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	3、发布分享：会员分享新商品到PinPHP网站能获得20积分，每日上限10次；\r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	4、添加喜欢：针对PinPHP网站上的商品会员点击喜欢可获得1积分，每日上限10次；\r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	5、添加到专辑：会员把喜欢的商品添加进个人的专辑中可获得2积分，每日上限10次；\r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	6、转发分享：会员转发PinPHP网站上商品到其他网站上可获2积分，每日上限10次；\r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	7、发布评论：会员评论PinPHP网站商品可获1积分，每日上线5次。\r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	<strong>积分扣除：</strong>\r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	1、删除分享：会员删除自己添加的商品减20积分，每日上限100次；\r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	2、兑换商品：会员使用积分兑换自己喜欢的商品会扣除相对应的积分。\r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<div>\r\n	<br />\r\n</div>', '', '', '', 0),
(7, '兑换说明', '1、奖品价格已经包含邮寄费用在内，您无须另行支付。兑奖前请确认您的帐户中有足够数量的积分！<br />\r\n2、奖品寄送方式：QQ直充类奖品兑奖审核通过后会直接充入您的QQ号码中，其余虚拟奖品采用在线发送卡密的方式；实体奖品全部采用快递方式。<br />\r\n3、虚拟奖品有效期：虚拟卡密类奖品除手机充值卡10/20/30元卡密，因为充值卡金额少，有效期比较短，大约一周左右,其余卡密类奖品有效期为1个月；虚拟卡直冲类为即时发货即时到账，无有效期限制！积分兑换含有有效期的奖品，请尽快充值使用，如过有效期未充值导致卡密失效，PinPHP网概不负责。<br />\r\n4、确认您的奖品邮寄地址、联系电话正确无误后提交兑奖申请！如因您未提供详细信息或信息错误，导致奖品错投或无法寄送，网站不负任何责任，并不再补发奖品。<br />\r\n5、实物奖品将在兑奖提交后的2-5工作日内发出(奖品状态您可通过“积分订单”查询)！<br />\r\n6、实物奖品按照会员申请的要求发出去之后，无破损、短缺等质量问题或因个人喜好（色泽、外观）要求退换货将无法受理。<br />\r\n7、兑奖中心所有实物奖品颜色均为随机发送, 敬请谅解！<br />\r\n<br />\r\n<strong>注意：</strong><br />\r\n<br />\r\n1、签收奖品前，务必仔细检查货物是否完好！如果发现有破损、短缺情况，请直接让快递公司退回，无需承担任何费用，并及时与我们联系。签收后提出货物破损等问题，一律责任自负！无法受理退换货要求！他人代签与本人签收一样。<br />\r\n2、收到奖品7天内，若发现质量问题，请及时与我们联系并提供图片说明。如因个人使用不当导致的奖品问题无法更换。<br />\r\n3、如提交兑奖后，由于商家缺货导致无法发货的情况，会员会收到站内信息通知并取消兑奖，请重新选择其他奖品兑换。<br />\r\n<br />\r\n兑奖过程中如有问题请通过“联系我们”联系咨询。<br />\r\n以上奖品图片仅供参考,请您以收取的实物为准！如有异议请联系客服人员确认奖品情况。<br />', '', '', '', 0);

-- --------------------------------------------------------

--
-- 表的结构 `pin_auto_user`
--

CREATE TABLE IF NOT EXISTS `pin_auto_user` (
  `id` smallint(4) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `users` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `pin_auto_user`
--

INSERT INTO `pin_auto_user` (`id`, `name`, `users`) VALUES
(1, '商品采集采集', '熊小熊zz,安土桃山,晨雪熙,V小莲小莲V,Eudora_寻寻,Prickleman,泡芙小米粒,想太多妹子,跳房子123,彩色淘,设计系小女生,wingsa区,枕水而眠,咕咕是一只猫,起个名字太累');

-- --------------------------------------------------------

--
-- 表的结构 `pin_badword`
--

CREATE TABLE IF NOT EXISTS `pin_badword` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `word_type` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '1：禁用；2：替换；3：审核',
  `badword` varchar(100) NOT NULL,
  `replaceword` varchar(100) NOT NULL,
  `add_time` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `pin_flink`
--

CREATE TABLE IF NOT EXISTS `pin_flink` (
  `id` smallint(4) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `img` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `cate_id` smallint(5) NOT NULL,
  `ordid` tinyint(3) unsigned NOT NULL DEFAULT '255',
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `pin_flink`
--

INSERT INTO `pin_flink` (`id`, `name`, `img`, `url`, `cate_id`, `ordid`, `status`) VALUES
(1, 'PinPHP', '', 'http://www.pinphp.com', 1, 0, 1);

-- --------------------------------------------------------

--
-- 表的结构 `pin_flink_cate`
--

CREATE TABLE IF NOT EXISTS `pin_flink_cate` (
  `id` smallint(4) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `ordid` tinyint(3) unsigned NOT NULL DEFAULT '255',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `pin_flink_cate`
--

INSERT INTO `pin_flink_cate` (`id`, `name`, `ordid`, `status`) VALUES
(1, '友情链接', 255, 1);

-- --------------------------------------------------------

--
-- 表的结构 `pin_ipban`
--

CREATE TABLE IF NOT EXISTS `pin_ipban` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `type` varchar(30) NOT NULL,
  `expires_time` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `pin_item`
--

CREATE TABLE IF NOT EXISTS `pin_item` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cate_id` smallint(4) unsigned DEFAULT NULL,
  `orig_id` smallint(6) NOT NULL,
  `uid` int(10) unsigned NOT NULL DEFAULT '0',
  `uname` varchar(20) NOT NULL,
  `key_id` varchar(50) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `intro` varchar(255) NOT NULL,
  `img` varchar(255) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `rates` float(8,2) NOT NULL COMMENT '佣金比率xxx.xx%',
  `url` text,
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1:商品,2:图片',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  `likes` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '喜欢数',
  `comments` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '评论数',
  `cmt_taobao_time` int(10) unsigned NOT NULL DEFAULT '0',
  `add_time` int(10) NOT NULL,
  `tag_cache` text NOT NULL,
  `comments_cache` text NOT NULL,
  `seo_title` varchar(255) DEFAULT NULL,
  `seo_keys` varchar(255) DEFAULT NULL,
  `seo_desc` text,
  `ordid` tinyint(3) unsigned NOT NULL DEFAULT '255',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `key_id` (`key_id`),
  KEY `cid` (`cate_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=69 ;

--
-- 转存表中的数据 `pin_item`
--

INSERT INTO `pin_item` (`id`, `cate_id`, `orig_id`, `uid`, `uname`, `key_id`, `title`, `intro`, `img`, `price`, `rates`, `url`, `type`, `hits`, `likes`, `comments`, `cmt_taobao_time`, `add_time`, `tag_cache`, `comments_cache`, `seo_title`, `seo_keys`, `seo_desc`, `ordid`, `status`) VALUES
(1, 3, 1, 14, '泡芙小米粒', 'taobao_12449893551', '浪漫一身 2012冬装新款 专柜正品 韩版大翻领格纹毛呢大衣外套', '浪漫一身 2012冬装新款 专柜正品 韩版大翻领格纹毛呢大衣外套', 'http://img03.taobaocdn.com/bao/uploaded/i3/T1o2R8XdRtXXcjNLgV_020417.jpg', '869.00', 6.00, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CFcRfH0G7DbPkiN9MMMnneK3vquA29OInF264WChjSaKH%2FfRp5I%2BALaiIP7nXcMegDu1ZsbRAQ12mpIK9e7FXadXUmubx27IaWn4OVRmYJUtkBKl64nZf2TvRFo97q3a25LtkOzTaLEibXgqWprz5xIZpvZqAxS7HclMfCXBbyL9DM%3D&spm=2014.21069764.12504724.0', 1, 1, 0, 0, 0, 1353896347, 'a:10:{i:47;s:6:"翻领";i:48;s:12:"毛呢大衣";i:49;s:6:"冬装";i:50;s:6:"专柜";i:51;s:6:"正品";i:1;s:6:"外套";i:52;s:6:"新款";i:53;s:6:"一身";i:54;s:6:"浪漫";i:55;s:9:"韩版大";}', '', NULL, NULL, NULL, 255, 1),
(2, 3, 1, 10, '设计系小女生', 'taobao_13108467207', '浪漫一身 2012冬装新款 专柜正品 欧美范 羊毛毛纯色呢短外套', '浪漫一身 2012冬装新款 专柜正品 欧美范 羊毛毛纯色呢短外套', 'http://img03.taobaocdn.com/bao/uploaded/i3/T1L.urXiFJXXa2x2w2_043755.jpg', '1159.00', 6.00, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CFcRfH0G7DbPkiN9MMMnneK3vquA29OInF264WChjSaKH%2FfRp5I%2BALaiIP7nXcMegDu1ZsbRAQ12mpIK9e7FXadXUmubx27IaWn4OVRmYJUtkBKl64nZf2TvRFo97q3a25LtkOzTaLEibXgqWprz5xIZpvZqAxS7Haj9xmz%2BtZDh1k%3D&spm=2014.21069764.12504724.0', 1, 1, 0, 0, 0, 1353896347, 'a:10:{i:56;s:6:"纯色";i:57;s:9:"短外套";i:49;s:6:"冬装";i:50;s:6:"专柜";i:58;s:6:"羊毛";i:51;s:6:"正品";i:52;s:6:"新款";i:53;s:6:"一身";i:25;s:6:"欧美";i:54;s:6:"浪漫";}', '', NULL, NULL, NULL, 255, 1),
(3, 3, 1, 19, '安土桃山', 'taobao_15846726000', '浪漫一身 2012秋装新款 专柜正品 休闲长袖薄外套修身立领棒球衫', '浪漫一身 2012秋装新款 专柜正品 休闲长袖薄外套修身立领棒球衫', 'http://img01.taobaocdn.com/bao/uploaded/i1/T1FGLNXmJbXXbjSLvb_093718.jpg', '399.00', 6.00, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CFcRfH0G7DbPkiN9MMMnneK3vquA29OInF264WChjSaKH%2FfRp5I%2BALaiIP7nXcMegDu1ZsbRAQ12mpIK9e7FXadXUmubx27IaWn4OVRmYJUtkBKl64nZf2TvRFo97q3a25LtkOzTaLEibXgqWprz5xIZpvZqAxS7HDIXmx1E90q388%3D&spm=2014.21069764.12504724.0', 1, 0, 0, 0, 0, 1353896347, 'a:10:{i:59;s:6:"秋装";i:60;s:6:"球衫";i:61;s:6:"立领";i:62;s:6:"修身";i:63;s:6:"长袖";i:50;s:6:"专柜";i:51;s:6:"正品";i:1;s:6:"外套";i:52;s:6:"新款";i:53;s:6:"一身";}', '', NULL, NULL, NULL, 255, 1),
(4, 3, 1, 8, '枕水而眠', 'taobao_13797023681', '浪漫一身 2012冬装新款 欧美仿麂皮翻领长袖 修身加厚短外套', '浪漫一身 2012冬装新款 欧美仿麂皮翻领长袖 修身加厚短外套', 'http://img02.taobaocdn.com/bao/uploaded/i2/T1Fw5FXmxmXXc2RowZ_034012.jpg', '879.00', 6.00, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CFcRfH0G7DbPkiN9MMMnneK3vquA29OInF264WChjSaKH%2FfRp5I%2BALaiIP7nXcMegDu1ZsbRAQ12mpIK9e7FXadXUmubx27IaWn4OVRmYJUtkBKl64nZf2TvRFo97q3a25LtkOzTaLEibXgqWprz5xIZpvZqAxS7HaldPmKSBWJYqw%3D&spm=2014.21069764.12504724.0', 1, 0, 0, 0, 0, 1353896347, 'a:10:{i:64;s:6:"麂皮";i:47;s:6:"翻领";i:57;s:9:"短外套";i:65;s:6:"加厚";i:49;s:6:"冬装";i:62;s:6:"修身";i:63;s:6:"长袖";i:52;s:6:"新款";i:53;s:6:"一身";i:25;s:6:"欧美";}', '', NULL, NULL, NULL, 255, 1),
(5, 3, 1, 8, '枕水而眠', 'taobao_15643358055', '浪漫一身 2012秋装新款 韩版蝙蝠袖长袖 假两件休闲棉质马甲外套', '浪漫一身 2012秋装新款 韩版蝙蝠袖长袖 假两件休闲棉质马甲外套', 'http://img04.taobaocdn.com/bao/uploaded/i4/T1tmvLXnhmXXXxzzQW_024228.jpg', '759.00', 6.00, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CFcRfH0G7DbPkiN9MMMnneK3vquA29OInF264WChjSaKH%2FfRp5I%2BALaiIP7nXcMegDu1ZsbRAQ12mpIK9e7FXadXUmubx27IaWn4OVRmYJUtkBKl64nZf2TvRFo97q3a25LtkOzTaLEibXgqWprz5xIZpvZqAxS7HDGpoNP0L92oUo%3D&spm=2014.21069764.12504724.0', 1, 0, 0, 0, 0, 1353896347, 'a:10:{i:59;s:6:"秋装";i:66;s:6:"棉质";i:7;s:6:"马甲";i:63;s:6:"长袖";i:67;s:6:"蝙蝠";i:1;s:6:"外套";i:52;s:6:"新款";i:53;s:6:"一身";i:54;s:6:"浪漫";i:68;s:6:"休闲";}', '', NULL, NULL, NULL, 255, 1),
(6, 3, 1, 18, '晨雪熙', 'taobao_13119046174', '浪漫一身  直筒带帽休闲加薄长款棉衣外套', '浪漫一身  直筒带帽休闲加薄长款棉衣外套', 'http://img01.taobaocdn.com/bao/uploaded/i1/T1dmCzXaxgXXcNQv71_040909.jpg', '749.00', 6.00, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CFcRfH0G7DbPkiN9MMMnneK3vquA29OInF264WChjSaKH%2FfRp5I%2BALaiIP7nXcMegDu1ZsbRAQ12mpIK9e7FXadXUmubx27IaWn4OVRmYJUtkBKl64nZf2TvRFo97q3a25LtkOzTaLEibXgqWprz5xIZpvZqAxS7Haj9luYeaibXdU%3D&spm=2014.21069764.12504724.0', 1, 0, 0, 0, 0, 1353896348, 'a:6:{i:69;s:6:"带帽";i:70;s:6:"棉衣";i:1;s:6:"外套";i:53;s:6:"一身";i:54;s:6:"浪漫";i:68;s:6:"休闲";}', '', NULL, NULL, NULL, 255, 1),
(7, 3, 1, 6, '起个名字太累', 'taobao_15860034983', '浪漫一身 2012秋装新款 修身街头运动 拉链带帽拼接袋鼠兜短外套', '浪漫一身 2012秋装新款 修身街头运动 拉链带帽拼接袋鼠兜短外套', 'http://img01.taobaocdn.com/bao/uploaded/i1/T1yhLQXnVqXXXEh_71_042519.jpg', '589.00', 6.00, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CFcRfH0G7DbPkiN9MMMnneK3vquA29OInF264WChjSaKH%2FfRp5I%2BALaiIP7nXcMegDu1ZsbRAQ12mpIK9e7FXadXUmubx27IaWn4OVRmYJUtkBKl64nZf2TvRFo97q3a25LtkOzTaLEibXgqWprz5xIZpvZqAxS7HDIXAPt9jR0G3k%3D&spm=2014.21069764.12504724.0', 1, 0, 0, 0, 0, 1353896348, 'a:10:{i:69;s:6:"带帽";i:59;s:6:"秋装";i:57;s:9:"短外套";i:17;s:6:"拼接";i:71;s:6:"袋鼠";i:62;s:6:"修身";i:72;s:6:"拉链";i:52;s:6:"新款";i:53;s:6:"一身";i:73;s:6:"街头";}', '', NULL, NULL, NULL, 255, 1),
(8, 3, 1, 18, '晨雪熙', 'taobao_15529276351', '浪漫宣言新款春秋修身单扣长袖女装短外套1016111', '浪漫宣言新款春秋修身单扣长袖女装短外套1016111', 'http://img03.taobaocdn.com/bao/uploaded/i3/T1ssGRXeVoXXXa7CQ5_060120.jpg', '289.00', 12.50, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CFcRfH0G7DbPkiN9MMMnneK3vquA29OInF264WChjSaKH%2FfRp5I%2BALaiIP7nXcMegDu1ZsbRAfBQ8QLTHXrq4OTymgvHm3DXe8E367qMREkJxvuttbquEgPGB9vNBb42xYPNz3zElKcKFq5RLIRtvx9Jo6aQkHCrOsc6gssTKquyLQ%3D&spm=2014.21069764.12504724.0', 1, 0, 0, 0, 0, 1353896348, 'a:9:{i:57;s:9:"短外套";i:62;s:6:"修身";i:63;s:6:"长袖";i:74;s:6:"女装";i:75;s:6:"春秋";i:52;s:6:"新款";i:76;s:6:"宣言";i:77;s:7:"1016111";i:54;s:6:"浪漫";}', '', NULL, NULL, NULL, 255, 1),
(9, 3, 1, 20, '熊小熊zz', 'taobao_12794807963', '浪漫一身 2012秋装新款 专柜正品 韩版蝙蝠袖西装式针织开衫外套', '浪漫一身 2012秋装新款 专柜正品 韩版蝙蝠袖西装式针织开衫外套', 'http://img01.taobaocdn.com/bao/uploaded/i1/T1hP1mXjRrXXcK2PU3_050554.jpg', '489.00', 6.00, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CFcRfH0G7DbPkiN9MMMnneK3vquA29OInF264WChjSaKH%2FfRp5I%2BALaiIP7nXcMegDu1ZsbRAQ12mpIK9e7FXadXUmubx27IaWn4OVRmYJUtkBKl64nZf2TvRFo97q3a25LtkOzTaLEibXgqWprz5xIZpvZqAxS7HcmepSCFw0Lyd4%3D&spm=2014.21069764.12504724.0', 1, 0, 0, 0, 0, 1353896348, 'a:10:{i:59;s:6:"秋装";i:78;s:6:"开衫";i:4;s:6:"西装";i:67;s:6:"蝙蝠";i:50;s:6:"专柜";i:51;s:6:"正品";i:1;s:6:"外套";i:36;s:6:"针织";i:52;s:6:"新款";i:53;s:6:"一身";}', '', NULL, NULL, NULL, 255, 1),
(10, 3, 1, 8, '枕水而眠', 'taobao_15617721916', '浪漫一身 2012秋装新款 直筒运动休闲长袖 短款立领拉链纯色外套', '浪漫一身 2012秋装新款 直筒运动休闲长袖 短款立领拉链纯色外套', 'http://img01.taobaocdn.com/bao/uploaded/i1/T1As6HXiBmXXcXtaPb_093121.jpg', '759.00', 6.00, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CFcRfH0G7DbPkiN9MMMnneK3vquA29OInF264WChjSaKH%2FfRp5I%2BALaiIP7nXcMegDu1ZsbRAQ12mpIK9e7FXadXUmubx27IaWn4OVRmYJUtkBKl64nZf2TvRFo97q3a25LtkOzTaLEibXgqWprz5xIZpvZqAxS7HDGo3JBjpXHpn8%3D&spm=2014.21069764.12504724.0', 1, 0, 0, 0, 0, 1353896348, 'a:10:{i:59;s:6:"秋装";i:61;s:6:"立领";i:79;s:6:"短款";i:56;s:6:"纯色";i:63;s:6:"长袖";i:72;s:6:"拉链";i:1;s:6:"外套";i:52;s:6:"新款";i:80;s:12:"运动休闲";i:53;s:6:"一身";}', '', NULL, NULL, NULL, 255, 1),
(11, 3, 1, 18, '晨雪熙', 'taobao_15888234757', '浪漫一身 2012秋装新款 宽松加厚运动休闲 带拉链连帽毛衣外套', '浪漫一身 2012秋装新款 宽松加厚运动休闲 带拉链连帽毛衣外套', 'http://img01.taobaocdn.com/bao/uploaded/i1/T1_fvTXbdjXXc3i8E1_042214.jpg', '659.00', 6.00, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CFcRfH0G7DbPkiN9MMMnneK3vquA29OInF264WChjSaKH%2FfRp5I%2BALaiIP7nXcMegDu1ZsbRAQ12mpIK9e7FXadXUmubx27IaWn4OVRmYJUtkBKl64nZf2TvRFo97q3a25LtkOzTaLEibXgqWprz5xIZpvZqAxS7HDIUm66EH1bSnA%3D&spm=2014.21069764.12504724.0', 1, 0, 0, 0, 0, 1353896348, 'a:10:{i:59;s:6:"秋装";i:2;s:6:"毛衣";i:65;s:6:"加厚";i:23;s:6:"宽松";i:72;s:6:"拉链";i:1;s:6:"外套";i:52;s:6:"新款";i:80;s:12:"运动休闲";i:53;s:6:"一身";i:54;s:6:"浪漫";}', '', NULL, NULL, NULL, 255, 1),
(12, 3, 1, 20, '熊小熊zz', 'taobao_20106024978', '浪漫一身 2012冬装新款 专柜正品 通勤简约 柳钉拼接时尚短外套', '浪漫一身 2012冬装新款 专柜正品 通勤简约 柳钉拼接时尚短外套', 'http://img04.taobaocdn.com/bao/uploaded/i4/T1vdvYXktiXXb1Opc__104853.jpg', '539.00', 6.00, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CFcRfH0G7DbPkiN9MMMnneK3vquA29OInF264WChjSaKH%2FfRp5I%2BALaiIP7nXcMegDu1ZsbRAQ12mpIK9e7FXadXUmubx27IaWn4OVRmYJUtkBKl64nZf2TvRFo97q3a25LtkOzTaLEibXgqWprz5xIZpvZqAxS79ZxxMnBelYL5dk%3D&spm=2014.21069764.12504724.0', 1, 2, 0, 0, 0, 1353896348, 'a:10:{i:81;s:6:"通勤";i:57;s:9:"短外套";i:17;s:6:"拼接";i:49;s:6:"冬装";i:50;s:6:"专柜";i:29;s:6:"简约";i:51;s:6:"正品";i:52;s:6:"新款";i:53;s:6:"一身";i:54;s:6:"浪漫";}', '', NULL, NULL, NULL, 255, 1),
(13, 3, 1, 14, '泡芙小米粒', 'taobao_12625560540', '浪漫一身 2012秋装新款 专柜正品 亮色带帽长袖休闲格子外套', '浪漫一身 2012秋装新款 专柜正品 亮色带帽长袖休闲格子外套', 'http://img02.taobaocdn.com/bao/uploaded/i2/T1h4F7XbdAXXce_eEZ_032143.jpg', '489.00', 6.00, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CFcRfH0G7DbPkiN9MMMnneK3vquA29OInF264WChjSaKH%2FfRp5I%2BALaiIP7nXcMegDu1ZsbRAQ12mpIK9e7FXadXUmubx27IaWn4OVRmYJUtkBKl64nZf2TvRFo97q3a25LtkOzTaLEibXgqWprz5xIZpvZqAxS7Hcn0SiF6pzyZ9c%3D&spm=2014.21069764.12504724.0', 1, 0, 0, 0, 0, 1353896348, 'a:10:{i:69;s:6:"带帽";i:59;s:6:"秋装";i:82;s:6:"亮色";i:63;s:6:"长袖";i:19;s:6:"格子";i:50;s:6:"专柜";i:51;s:6:"正品";i:1;s:6:"外套";i:52;s:6:"新款";i:53;s:6:"一身";}', '', NULL, NULL, NULL, 255, 1),
(14, 3, 1, 14, '泡芙小米粒', 'taobao_16571375886', '浪漫一身 2012秋装新款 通勤OL开衫V领长袖 纯色百搭时尚小外套', '浪漫一身 2012秋装新款 通勤OL开衫V领长袖 纯色百搭时尚小外套', 'http://img04.taobaocdn.com/bao/uploaded/i4/T1qdnCXlBhXXbCT873_051140.jpg', '589.00', 6.00, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CFcRfH0G7DbPkiN9MMMnneK3vquA29OInF264WChjSaKH%2FfRp5I%2BALaiIP7nXcMegDu1ZsbRAQ12mpIK9e7FXadXUmubx27IaWn4OVRmYJUtkBKl64nZf2TvRFo97q3a25LtkOzTaLEibXgqWprz5xIZpvZqAxS7HOKnr5%2Fy7%2BASa0%3D&spm=2014.21069764.12504724.0', 1, 0, 0, 0, 0, 1353896349, 'a:10:{i:59;s:6:"秋装";i:81;s:6:"通勤";i:78;s:6:"开衫";i:56;s:6:"纯色";i:63;s:6:"长袖";i:1;s:6:"外套";i:52;s:6:"新款";i:53;s:6:"一身";i:54;s:6:"浪漫";i:83;s:6:"时尚";}', '', NULL, NULL, NULL, 255, 1),
(15, 3, 1, 8, '枕水而眠', 'taobao_14054558722', '浪漫一身 线下专柜正品 2012春装一粒扣短款西装 韩版胸花短外套', '浪漫一身 线下专柜正品 2012春装一粒扣短款西装 韩版胸花短外套', 'http://img01.taobaocdn.com/bao/uploaded/i1/T1QEO7XcBdXXXWXn.U_015911.jpg', '529.00', 6.00, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CFcRfH0G7DbPkiN9MMMnneK3vquA29OInF264WChjSaKH%2FfRp5I%2BALaiIP7nXcMegDu1ZsbRAQ12mpIK9e7FXadXUmubx27IaWn4OVRmYJUtkBKl64nZf2TvRFo97q3a25LtkOzTaLEibXgqWprz5xIZpvZqAxS7HHx0%2BHY9j8%2Bz2c%3D&spm=2014.21069764.12504724.0', 1, 0, 0, 0, 0, 1353896349, 'a:10:{i:79;s:6:"短款";i:84;s:6:"胸花";i:4;s:6:"西装";i:57;s:9:"短外套";i:85;s:6:"线下";i:86;s:6:"春装";i:50;s:6:"专柜";i:51;s:6:"正品";i:53;s:6:"一身";i:54;s:6:"浪漫";}', '', NULL, NULL, NULL, 255, 1),
(16, 3, 1, 18, '晨雪熙', 'taobao_15727168344', '浪漫一身 线下 专柜正品 2012春装翻领长袖中长款 夹克风衣外套女', '浪漫一身 线下 专柜正品 2012春装翻领长袖中长款 夹克风衣外套女', 'http://img02.taobaocdn.com/bao/uploaded/i2/T1DReVXjtbXXcISRE9_104415.jpg', '519.00', 6.00, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CFcRfH0G7DbPkiN9MMMnneK3vquA29OInF264WChjSaKH%2FfRp5I%2BALaiIP7nXcMegDu1ZsbRAQ12mpIK9e7FXadXUmubx27IaWn4OVRmYJUtkBKl64nZf2TvRFo97q3a25LtkOzTaLEibXgqWprz5xIZpvZqAxS7HDHQDyEtz3oMqY%3D&spm=2014.21069764.12504724.0', 1, 7, 0, 0, 0, 1353896349, 'a:10:{i:47;s:6:"翻领";i:87;s:6:"夹克";i:5;s:6:"风衣";i:88;s:6:"中长";i:85;s:6:"线下";i:86;s:6:"春装";i:63;s:6:"长袖";i:50;s:6:"专柜";i:51;s:6:"正品";i:1;s:6:"外套";}', '', NULL, NULL, NULL, 255, 1),
(17, 3, 1, 10, '设计系小女生', 'taobao_15728140008', '浪漫一身 2012秋装新款 线下 专柜正品 韩版双排扣风衣外套', '浪漫一身 2012秋装新款 线下 专柜正品 韩版双排扣风衣外套', 'http://img03.taobaocdn.com/bao/uploaded/i3/T1Xo6dXhptXXb5KSA9_104530.jpg', '599.00', 6.00, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CFcRfH0G7DbPkiN9MMMnneK3vquA29OInF264WChjSaKH%2FfRp5I%2BALaiIP7nXcMegDu1ZsbRAQ12mpIK9e7FXadXUmubx27IaWn4OVRmYJUtkBKl64nZf2TvRFo97q3a25LtkOzTaLEibXgqWprz5xIZpvZqAxS7HDHQDOdAKUNi8o%3D&spm=2014.21069764.12504724.0', 1, 0, 0, 0, 0, 1353896349, 'a:10:{i:59;s:6:"秋装";i:89;s:6:"双排";i:5;s:6:"风衣";i:85;s:6:"线下";i:50;s:6:"专柜";i:51;s:6:"正品";i:1;s:6:"外套";i:52;s:6:"新款";i:53;s:6:"一身";i:54;s:6:"浪漫";}', '', NULL, NULL, NULL, 255, 1),
(18, 3, 1, 17, 'V小莲小莲V', 'taobao_15890937883', '浪漫一身 2012秋装新款 通勤长袖翻领  OL时尚帅气小西装式短外套', '浪漫一身 2012秋装新款 通勤长袖翻领  OL时尚帅气小西装式短外套', 'http://img03.taobaocdn.com/bao/uploaded/i3/T1ms_UXi0bXXb4juQ1_041036.jpg', '639.00', 6.00, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CFcRfH0G7DbPkiN9MMMnneK3vquA29OInF264WChjSaKH%2FfRp5I%2BALaiIP7nXcMegDu1ZsbRAQ12mpIK9e7FXadXUmubx27IaWn4OVRmYJUtkBKl64nZf2TvRFo97q3a25LtkOzTaLEibXgqWprz5xIZpvZqAxS7HDIU41z%2B5X9pwc%3D&spm=2014.21069764.12504724.0', 1, 1, 0, 0, 0, 1353896349, 'a:10:{i:59;s:6:"秋装";i:81;s:6:"通勤";i:47;s:6:"翻领";i:90;s:9:"小西装";i:57;s:9:"短外套";i:63;s:6:"长袖";i:91;s:6:"帅气";i:52;s:6:"新款";i:53;s:6:"一身";i:54;s:6:"浪漫";}', '', NULL, NULL, NULL, 255, 1),
(19, 3, 1, 6, '起个名字太累', 'taobao_13941300183', '浪漫一身 冬装 专柜正品 羊毛毛呢短外套  外套 女装长袖', '浪漫一身 冬装 专柜正品 羊毛毛呢短外套  外套 女装长袖', 'http://img02.taobaocdn.com/bao/uploaded/i2/T1V_KxXkXuXXX2Qls4_053710.jpg', '719.00', 6.00, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CFcRfH0G7DbPkiN9MMMnneK3vquA29OInF264WChjSaKH%2FfRp5I%2BALaiIP7nXcMegDu1ZsbRAQ12mpIK9e7FXadXUmubx27IaWn4OVRmYJUtkBKl64nZf2TvRFo97q3a25LtkOzTaLEibXgqWprz5xIZpvZqAxS7HarXbtmoRTcBx0%3D&spm=2014.21069764.12504724.0', 1, 0, 0, 0, 0, 1353896349, 'a:10:{i:35;s:6:"毛呢";i:57;s:9:"短外套";i:49;s:6:"冬装";i:63;s:6:"长袖";i:50;s:6:"专柜";i:58;s:6:"羊毛";i:51;s:6:"正品";i:1;s:6:"外套";i:74;s:6:"女装";i:53;s:6:"一身";}', '', NULL, NULL, NULL, 255, 1),
(20, 3, 1, 18, '晨雪熙', 'taobao_15140755590', '浪漫一身 品牌女装 专柜正品 春夏装中长款抽皱褶无袖短外套', '浪漫一身 品牌女装 专柜正品 春夏装中长款抽皱褶无袖短外套', 'http://img01.taobaocdn.com/bao/uploaded/i1/T1vN18Xe8wXXabtx7U_014829.jpg', '349.00', 6.00, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CFcRfH0G7DbPkiN9MMMnneK3vquA29OInF264WChjSaKH%2FfRp5I%2BALaiIP7nXcMegDu1ZsbRAQ12mpIK9e7FXadXUmubx27IaWn4OVRmYJUtkBKl64nZf2TvRFo97q3a25LtkOzTaLEibXgqWprz5xIZpvZqAxS7HDBNPBC622EGlw%3D&spm=2014.21069764.12504724.0', 1, 2, 0, 0, 0, 1353896349, 'a:10:{i:92;s:6:"无袖";i:93;s:6:"皱褶";i:94;s:12:"品牌女装";i:88;s:6:"中长";i:57;s:9:"短外套";i:95;s:6:"夏装";i:50;s:6:"专柜";i:51;s:6:"正品";i:53;s:6:"一身";i:54;s:6:"浪漫";}', '', NULL, NULL, NULL, 255, 1),
(21, 161, 1, 12, '跳房子123', 'taobao_16255285189', 'MIYI 英国2013新款头层牛皮撞色真皮女包小包单肩包信封邮差包邮', 'MIYI 英国2013新款头层牛皮撞色真皮女包小包单肩包信封邮差包邮', 'http://img04.taobaocdn.com/bao/uploaded/i4/T1oAbZXkldXXcH5ug2_043616.jpg', '699.00', 3.00, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CFcRfH0G7DbPkiN9MMMn63%2BmSeCugYXvNBw%2Bn2JNZPYX6rsb5kSrNVff4SB%2FAih1PC6sh8xxuLCe8I2cwxmlKTSqGmwdZnksB7g%2FAUExUi%2BNsiq2xeJHfrsHIEmgAdicJSN%2BfVEl8j9JHIvH5hTXYZAyleokCRvo05KGbgipjWhzC4%3D&spm=2014.21069764.12504724.0', 1, 0, 0, 0, 0, 1353902315, 'a:10:{i:217;s:6:"邮差";i:218;s:9:"单肩包";i:219;s:6:"女包";i:220;s:6:"真皮";i:221;s:6:"英国";i:222;s:6:"小包";i:223;s:6:"牛皮";i:224;s:6:"信封";i:52;s:6:"新款";i:225;s:6:"包邮";}', '', NULL, NULL, NULL, 255, 1),
(22, 161, 1, 7, '咕咕是一只猫', 'taobao_17226971405', 'MIYI 2012英伦复古学院风牛皮撞色邮差包 时尚单肩斜挎潮包女士包', 'MIYI 2012英伦复古学院风牛皮撞色邮差包 时尚单肩斜挎潮包女士包', 'http://img02.taobaocdn.com/bao/uploaded/i2/T1qrdqXXlwXXa_4U38_101909.jpg', '386.00', 5.00, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CFcRfH0G7DbPkiN9MMMn63%2BmSeCugYXvNBw%2Bn2JNZPYX6rsb5kSrNVff4SB%2FAih1PC6sh8xxuLCe8I2cwxmlKTSqGmwdZnksB7g%2FAUExUi%2BNsiq2xeJHfrsHIEmgAdicJSN%2BfVEl8j9JHIvH5hTXYZAyleokCRvo08Iory3v8tnXHc%3D&spm=2014.21069764.12504724.0', 1, 2, 0, 0, 0, 1353902316, 'a:10:{i:30;s:6:"英伦";i:217;s:6:"邮差";i:226;s:6:"单肩";i:227;s:6:"斜挎";i:223;s:6:"牛皮";i:28;s:6:"复古";i:228;s:6:"女士";i:229;s:6:"学院";i:83;s:6:"时尚";i:230;s:4:"MIYI";}', '', NULL, NULL, NULL, 255, 1),
(23, 161, 1, 11, '彩色淘', 'taobao_16013976537', 'MIYI 英伦学院风复古糖果色牛皮剑桥包 单肩包时尚女包 小包潮包', 'MIYI 英伦学院风复古糖果色牛皮剑桥包 单肩包时尚女包 小包潮包', 'http://img03.taobaocdn.com/bao/uploaded/i3/T1yj1xXg01XXX_.NQ8_100702.jpg', '368.00', 4.00, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CFcRfH0G7DbPkiN9MMMn63%2BmSeCugYXvNBw%2Bn2JNZPYX6rsb5kSrNVff4SB%2FAih1PC6sh8xxuLCe8I2cwxmlKTSqGmwdZnksB7g%2FAUExUi%2BNsiq2xeJHfrsHIEmgAdicJSN%2BfVEl8j9JHIvH5hTXYZAyleokCRvo05IKGfkjh%2BBCNo%3D&spm=2014.21069764.12504724.0', 1, 0, 0, 0, 0, 1353902316, 'a:10:{i:30;s:6:"英伦";i:231;s:6:"剑桥";i:219;s:6:"女包";i:218;s:9:"单肩包";i:222;s:6:"小包";i:223;s:6:"牛皮";i:28;s:6:"复古";i:232;s:6:"糖果";i:229;s:6:"学院";i:83;s:6:"时尚";}', '', NULL, NULL, NULL, 255, 1),
(24, 161, 1, 11, '彩色淘', 'taobao_14320270365', 'MIYI 2012新款秋冬头层牛皮女包菱格链条包单肩包 真皮女包宴会包', 'MIYI 2012新款秋冬头层牛皮女包菱格链条包单肩包 真皮女包宴会包', 'http://img02.taobaocdn.com/bao/uploaded/i2/T1DsrnXbRkXXanw8_b_124847.jpg', '499.00', 5.00, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CFcRfH0G7DbPkiN9MMMn63%2BmSeCugYXvNBw%2Bn2JNZPYX6rsb5kSrNVff4SB%2FAih1PC6sh8xxuLCe8I2cwxmlKTSqGmwdZnksB7g%2FAUExUi%2BNsiq2xeJHfrsHIEmgAdicJSN%2BfVEl8j9JHIvH5hTXYZAyleokCRvo0wKpbw%2BrCF5BsU%3D&spm=2014.21069764.12504724.0', 1, 0, 0, 0, 0, 1353902316, 'a:10:{i:219;s:6:"女包";i:218;s:9:"单肩包";i:220;s:6:"真皮";i:233;s:6:"链条";i:223;s:6:"牛皮";i:234;s:6:"宴会";i:235;s:6:"秋冬";i:52;s:6:"新款";i:230;s:4:"MIYI";i:236;s:4:"2012";}', '', NULL, NULL, NULL, 255, 1),
(25, 161, 1, 7, '咕咕是一只猫', 'taobao_15890381872', 'MIYI 2012秋冬新款欧美时尚牛皮邮差包单肩斜挎包 复古百搭女大包', 'MIYI 2012秋冬新款欧美时尚牛皮邮差包单肩斜挎包 复古百搭女大包', 'http://img01.taobaocdn.com/bao/uploaded/i1/T18U_SXklkXXcPno7._084022.jpg', '428.00', 5.00, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CFcRfH0G7DbPkiN9MMMn63%2BmSeCugYXvNBw%2Bn2JNZPYX6rsb5kSrNVff4SB%2FAih1PC6sh8xxuLCe8I2cwxmlKTSqGmwdZnksB7g%2FAUExUi%2BNsiq2xeJHfrsHIEmgAdicJSN%2BfVEl8j9JHIvH5hTXYZAyleokCRvo03wEVPhUIXhA%2Bo%3D&spm=2014.21069764.12504724.0', 1, 0, 0, 0, 0, 1353902316, 'a:10:{i:217;s:6:"邮差";i:237;s:9:"斜挎包";i:226;s:6:"单肩";i:223;s:6:"牛皮";i:238;s:6:"大包";i:28;s:6:"复古";i:235;s:6:"秋冬";i:52;s:6:"新款";i:25;s:6:"欧美";i:83;s:6:"时尚";}', '', NULL, NULL, NULL, 255, 1),
(26, 161, 1, 15, 'Prickleman', 'taobao_19754816126', 'MIYI秋冬新款牛皮复古OL通勤单肩斜挎女包包英伦潮款特价包邮', 'MIYI秋冬新款牛皮复古OL通勤单肩斜挎女包包英伦潮款特价包邮', 'http://img04.taobaocdn.com/bao/uploaded/i4/T1_HC7XhlwXXbMVu7W_023330.jpg', '399.00', 3.00, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CFcRfH0G7DbPkiN9MMMn63%2BmSeCugYXvNBw%2Bn2JNZPYX6rsb5kSrNVff4SB%2FAih1PC6sh8xxuLCe8I2cwxmlKTSqGmwdZnksB7g%2FAUExUi%2BNsiq2xeJHfrsHIEmgAdicJSN%2BfVEl8j9JHIvH5hTXYZAyleokCRvo0FbXn9r9wdHiI4%3D&spm=2014.21069764.12504724.0', 1, 0, 0, 0, 0, 1353902316, 'a:10:{i:30;s:6:"英伦";i:81;s:6:"通勤";i:227;s:6:"斜挎";i:226;s:6:"单肩";i:223;s:6:"牛皮";i:28;s:6:"复古";i:239;s:6:"包包";i:235;s:6:"秋冬";i:52;s:6:"新款";i:240;s:6:"特价";}', '', NULL, NULL, NULL, 255, 1),
(27, 161, 1, 11, '彩色淘', 'taobao_15109223455', '【清仓】MIYI 简约手提包女包 单肩牛皮大包通勤包 购物包肩挎包', '【清仓】MIYI 简约手提包女包 单肩牛皮大包通勤包 购物包肩挎包', 'http://img03.taobaocdn.com/bao/uploaded/i3/T1rnuWXbXwXXaT3dnb_093439.jpg', '398.00', 5.00, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CFcRfH0G7DbPkiN9MMMn63%2BmSeCugYXvNBw%2Bn2JNZPYX6rsb5kSrNVff4SB%2FAih1PC6sh8xxuLCe8I2cwxmlKTSqGmwdZnksB7g%2FAUExUi%2BNsiq2xeJHfrsHIEmgAdicJSN%2BfVEl8j9JHIvH5hTXYZAyleokCRvo035m9UA0dIvwk0%3D&spm=2014.21069764.12504724.0', 1, 0, 0, 0, 0, 1353902316, 'a:10:{i:81;s:6:"通勤";i:219;s:6:"女包";i:241;s:9:"手提包";i:226;s:6:"单肩";i:242;s:6:"挎包";i:243;s:6:"清仓";i:223;s:6:"牛皮";i:238;s:6:"大包";i:29;s:6:"简约";i:244;s:6:"购物";}', '', NULL, NULL, NULL, 255, 1),
(28, 161, 1, 8, '枕水而眠', 'taobao_15823554855', 'MIYI 秋冬新款复古风撞色手提包单肩包斜挎包包 机车包邮差包女包', 'MIYI 秋冬新款复古风撞色手提包单肩包斜挎包包 机车包邮差包女包', 'http://img01.taobaocdn.com/bao/uploaded/i1/T1sPfKXcxbXXXPQIYb_123402.jpg', '499.00', 5.00, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CFcRfH0G7DbPkiN9MMMn63%2BmSeCugYXvNBw%2Bn2JNZPYX6rsb5kSrNVff4SB%2FAih1PC6sh8xxuLCe8I2cwxmlKTSqGmwdZnksB7g%2FAUExUi%2BNsiq2xeJHfrsHIEmgAdicJSN%2BfVEl8j9JHIvH5hTXYZAyleokCRvo03wGp24NnaCcdU%3D&spm=2014.21069764.12504724.0', 1, 0, 0, 0, 0, 1353902317, 'a:10:{i:217;s:6:"邮差";i:245;s:6:"古风";i:246;s:9:"机车包";i:227;s:6:"斜挎";i:219;s:6:"女包";i:218;s:9:"单肩包";i:241;s:9:"手提包";i:239;s:6:"包包";i:235;s:6:"秋冬";i:52;s:6:"新款";}', '', NULL, NULL, NULL, 255, 1),
(29, 161, 1, 16, 'Eudora_寻寻', 'taobao_16612384785', 'MIYI 欧美鸵鸟纹头层牛皮单肩包斜跨复古女包邮差包 手提真皮女包', 'MIYI 欧美鸵鸟纹头层牛皮单肩包斜跨复古女包邮差包 手提真皮女包', 'http://img04.taobaocdn.com/bao/uploaded/i4/T1gz6JXj8iXXblFxU8_100704.jpg', '599.00', 5.00, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CFcRfH0G7DbPkiN9MMMn63%2BmSeCugYXvNBw%2Bn2JNZPYX6rsb5kSrNVff4SB%2FAih1PC6sh8xxuLCe8I2cwxmlKTSqGmwdZnksB7g%2FAUExUi%2BNsiq2xeJHfrsHIEmgAdicJSN%2BfVEl8j9JHIvH5hTXYZAyleokCRvo05OkwVCBTw4x00%3D&spm=2014.21069764.12504724.0', 1, 0, 0, 0, 0, 1353902317, 'a:10:{i:219;s:6:"女包";i:217;s:6:"邮差";i:220;s:6:"真皮";i:247;s:6:"手提";i:218;s:9:"单肩包";i:248;s:6:"鸵鸟";i:223;s:6:"牛皮";i:28;s:6:"复古";i:25;s:6:"欧美";i:230;s:4:"MIYI";}', '', NULL, NULL, NULL, 255, 1),
(30, 161, 1, 20, '熊小熊zz', 'taobao_16345335657', 'MIYI时尚可爱复古学院风糖果色单肩斜跨女包包小包牛皮邮差包特价', 'MIYI时尚可爱复古学院风糖果色单肩斜跨女包包小包牛皮邮差包特价', 'http://img02.taobaocdn.com/bao/uploaded/i2/T1m397XXJlXXaqnVg0_033805.jpg', '298.00', 4.00, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CFcRfH0G7DbPkiN9MMMn63%2BmSeCugYXvNBw%2Bn2JNZPYX6rsb5kSrNVff4SB%2FAih1PC6sh8xxuLCe8I2cwxmlKTSqGmwdZnksB7g%2FAUExUi%2BNsiq2xeJHfrsHIEmgAdicJSN%2BfVEl8j9JHIvH5hTXYZAyleokCRvo05LStXX%2FGLM87I%3D&spm=2014.21069764.12504724.0', 1, 0, 0, 0, 0, 1353902317, 'a:10:{i:217;s:6:"邮差";i:249;s:12:"单肩斜跨";i:222;s:6:"小包";i:223;s:6:"牛皮";i:28;s:6:"复古";i:232;s:6:"糖果";i:239;s:6:"包包";i:240;s:6:"特价";i:250;s:6:"可爱";i:229;s:6:"学院";}', '', NULL, NULL, NULL, 255, 1),
(31, 161, 1, 12, '跳房子123', 'taobao_14055073344', 'MIYI 红色斜纹牛皮单肩包包女包 2012新款潮包结婚包新娘包晚宴包', 'MIYI 红色斜纹牛皮单肩包包女包 2012新款潮包结婚包新娘包晚宴包', 'http://img02.taobaocdn.com/bao/uploaded/i2/T1X697XjXbXXcMnfM._112229.jpg', '398.00', 3.00, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CFcRfH0G7DbPkiN9MMMn63%2BmSeCugYXvNBw%2Bn2JNZPYX6rsb5kSrNVff4SB%2FAih1PC6sh8xxuLCe8I2cwxmlKTSqGmwdZnksB7g%2FAUExUi%2BNsiq2xeJHfrsHIEmgAdicJSN%2BfVEl8j9JHIvH5hTXYZAyleokCRvo0wJ15cqiz5AJR4%3D&spm=2014.21069764.12504724.0', 1, 0, 0, 0, 0, 1353902317, 'a:10:{i:251;s:6:"斜纹";i:226;s:6:"单肩";i:219;s:6:"女包";i:252;s:6:"晚宴";i:223;s:6:"牛皮";i:239;s:6:"包包";i:52;s:6:"新款";i:253;s:6:"新娘";i:42;s:6:"红色";i:254;s:6:"结婚";}', '', NULL, NULL, NULL, 255, 1),
(32, 161, 1, 12, '跳房子123', 'taobao_16704204880', 'MIYI米逸 新款英伦小包卡其色单肩包复古牛皮撞色复古女包邮差包', 'MIYI米逸 新款英伦小包卡其色单肩包复古牛皮撞色复古女包邮差包', 'http://img04.taobaocdn.com/bao/uploaded/i4/T1DxC8Xi4eXXXO8ZZ5_054947.jpg', '356.00', 3.00, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CFcRfH0G7DbPkiN9MMMn63%2BmSeCugYXvNBw%2Bn2JNZPYX6rsb5kSrNVff4SB%2FAih1PC6sh8xxuLCe8I2cwxmlKTSqGmwdZnksB7g%2FAUExUi%2BNsiq2xeJHfrsHIEmgAdicJSN%2BfVEl8j9JHIvH5hTXYZAyleokCRvo05PTPveAXCAOLc%3D&spm=2014.21069764.12504724.0', 1, 0, 0, 0, 0, 1353902317, 'a:10:{i:28;s:6:"复古";i:30;s:6:"英伦";i:255;s:9:"卡其色";i:217;s:6:"邮差";i:219;s:6:"女包";i:218;s:9:"单肩包";i:222;s:6:"小包";i:223;s:6:"牛皮";i:52;s:6:"新款";i:256;s:6:"米逸";}', '', NULL, NULL, NULL, 255, 1),
(33, 161, 1, 14, '泡芙小米粒', 'taobao_14320122714', 'MIYI新款鳄鱼纹翻盖潮手包牛皮女包单肩包复古包小包包 清仓包邮', 'MIYI新款鳄鱼纹翻盖潮手包牛皮女包单肩包复古包小包包 清仓包邮', 'http://img04.taobaocdn.com/bao/uploaded/i4/T1wBy7XflaXXX6UvwV_020442.jpg', '298.00', 3.00, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CFcRfH0G7DbPkiN9MMMn63%2BmSeCugYXvNBw%2Bn2JNZPYX6rsb5kSrNVff4SB%2FAih1PC6sh8xxuLCe8I2cwxmlKTSqGmwdZnksB7g%2FAUExUi%2BNsiq2xeJHfrsHIEmgAdicJSN%2BfVEl8j9JHIvH5hTXYZAyleokCRvo0wKpbw9tZlGyMI%3D&spm=2014.21069764.12504724.0', 1, 0, 0, 0, 0, 1353902317, 'a:10:{i:257;s:6:"手包";i:218;s:9:"单肩包";i:258;s:9:"鳄鱼纹";i:219;s:6:"女包";i:259;s:9:"复古包";i:260;s:6:"翻盖";i:243;s:6:"清仓";i:223;s:6:"牛皮";i:239;s:6:"包包";i:52;s:6:"新款";}', '', NULL, NULL, NULL, 255, 1),
(34, 161, 1, 10, '设计系小女生', 'taobao_14379470082', 'MIYI 2012秋冬新款头层牛皮手提包单肩包水桶真皮女包通勤包包邮', 'MIYI 2012秋冬新款头层牛皮手提包单肩包水桶真皮女包通勤包包邮', 'http://img01.taobaocdn.com/bao/uploaded/i1/T1tWOuXmFTXXXbvKDb_093608.jpg', '596.00', 3.00, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CFcRfH0G7DbPkiN9MMMn63%2BmSeCugYXvNBw%2Bn2JNZPYX6rsb5kSrNVff4SB%2FAih1PC6sh8xxuLCe8I2cwxmlKTSqGmwdZnksB7g%2FAUExUi%2BNsiq2xeJHfrsHIEmgAdicJSN%2BfVEl8j9JHIvH5hTXYZAyleokCRvo0wKoHwugzDUfJA%3D&spm=2014.21069764.12504724.0', 1, 0, 0, 0, 0, 1353902317, 'a:10:{i:81;s:6:"通勤";i:220;s:6:"真皮";i:219;s:6:"女包";i:218;s:9:"单肩包";i:241;s:9:"手提包";i:261;s:6:"水桶";i:223;s:6:"牛皮";i:239;s:6:"包包";i:235;s:6:"秋冬";i:52;s:6:"新款";}', '', NULL, NULL, NULL, 255, 1),
(35, 161, 1, 20, '熊小熊zz', 'taobao_16703956470', 'MIYI单肩小包2012新款潮时尚韩版休闲牛皮欧美红色新娘手拿女包包', 'MIYI单肩小包2012新款潮时尚韩版休闲牛皮欧美红色新娘手拿女包包', 'http://img01.taobaocdn.com/bao/uploaded/i1/T1xtK1XnlkXXaGp4E6_062100.jpg', '299.00', 3.00, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CFcRfH0G7DbPkiN9MMMn63%2BmSeCugYXvNBw%2Bn2JNZPYX6rsb5kSrNVff4SB%2FAih1PC6sh8xxuLCe8I2cwxmlKTSqGmwdZnksB7g%2FAUExUi%2BNsiq2xeJHfrsHIEmgAdicJSN%2BfVEl8j9JHIvH5hTXYZAyleokCRvo05PTPwUaALhr0w%3D&spm=2014.21069764.12504724.0', 1, 0, 0, 0, 0, 1353902318, 'a:10:{i:226;s:6:"单肩";i:222;s:6:"小包";i:223;s:6:"牛皮";i:239;s:6:"包包";i:52;s:6:"新款";i:253;s:6:"新娘";i:42;s:6:"红色";i:25;s:6:"欧美";i:68;s:6:"休闲";i:83;s:6:"时尚";}', '', NULL, NULL, NULL, 255, 1),
(36, 161, 1, 6, '起个名字太累', 'taobao_17083463220', 'MIYI韩版新款真皮女包包2012新款潮女包水桶通勤斜挎单肩机车包邮', 'MIYI韩版新款真皮女包包2012新款潮女包水桶通勤斜挎单肩机车包邮', 'http://img02.taobaocdn.com/bao/uploaded/i2/T1Ad58XctiXXcyC0s8_100130.jpg', '599.00', 5.00, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CFcRfH0G7DbPkiN9MMMn63%2BmSeCugYXvNBw%2Bn2JNZPYX6rsb5kSrNVff4SB%2FAih1PC6sh8xxuLCe8I2cwxmlKTSqGmwdZnksB7g%2FAUExUi%2BNsiq2xeJHfrsHIEmgAdicJSN%2BfVEl8j9JHIvH5hTXYZAyleokCRvo08KtkI1KPKr%2By8%3D&spm=2014.21069764.12504724.0', 1, 0, 0, 0, 0, 1353902318, 'a:10:{i:52;s:6:"新款";i:81;s:6:"通勤";i:219;s:6:"女包";i:246;s:9:"机车包";i:220;s:6:"真皮";i:226;s:6:"单肩";i:227;s:6:"斜挎";i:261;s:6:"水桶";i:239;s:6:"包包";i:262;s:6:"韩版";}', '', NULL, NULL, NULL, 255, 1),
(37, 161, 1, 13, '想太多妹子', 'taobao_14312565544', 'MIYI 2012秋冬新款欧美头层牛皮单肩斜挎包 韩版真皮女包通勤包包', 'MIYI 2012秋冬新款欧美头层牛皮单肩斜挎包 韩版真皮女包通勤包包', 'http://img02.taobaocdn.com/bao/uploaded/i2/T1O9mQXndwXXXD_O.0_035651.jpg', '569.00', 3.00, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CFcRfH0G7DbPkiN9MMMn63%2BmSeCugYXvNBw%2Bn2JNZPYX6rsb5kSrNVff4SB%2FAih1PC6sh8xxuLCe8I2cwxmlKTSqGmwdZnksB7g%2FAUExUi%2BNsiq2xeJHfrsHIEmgAdicJSN%2BfVEl8j9JHIvH5hTXYZAyleokCRvo0wKpjq%2Faawnvbc%3D&spm=2014.21069764.12504724.0', 1, 0, 0, 0, 0, 1353902318, 'a:10:{i:81;s:6:"通勤";i:220;s:6:"真皮";i:219;s:6:"女包";i:237;s:9:"斜挎包";i:226;s:6:"单肩";i:223;s:6:"牛皮";i:239;s:6:"包包";i:235;s:6:"秋冬";i:52;s:6:"新款";i:25;s:6:"欧美";}', '', NULL, NULL, NULL, 255, 1),
(38, 161, 1, 6, '起个名字太累', 'taobao_16704804437', 'MIYI2012新款全牛皮简约主义韩版糖果女包包复古手提大包单肩包', 'MIYI2012新款全牛皮简约主义韩版糖果女包包复古手提大包单肩包', 'http://img01.taobaocdn.com/bao/uploaded/i1/T17FtRXaBGXXa3dJs6_061244.jpg', '499.00', 3.00, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CFcRfH0G7DbPkiN9MMMn63%2BmSeCugYXvNBw%2Bn2JNZPYX6rsb5kSrNVff4SB%2FAih1PC6sh8xxuLCe8I2cwxmlKTSqGmwdZnksB7g%2FAUExUi%2BNsiq2xeJHfrsHIEmgAdicJSN%2BfVEl8j9JHIvH5hTXYZAyleokCRvo05PTPvUsr6elgM%3D&spm=2014.21069764.12504724.0', 1, 0, 0, 0, 0, 1353902318, 'a:10:{i:263;s:12:"简约主义";i:247;s:6:"手提";i:218;s:9:"单肩包";i:223;s:6:"牛皮";i:238;s:6:"大包";i:28;s:6:"复古";i:232;s:6:"糖果";i:239;s:6:"包包";i:52;s:6:"新款";i:264;s:8:"MIYI2012";}', '', NULL, NULL, NULL, 255, 1),
(39, 161, 1, 17, 'V小莲小莲V', 'taobao_16013916115', 'MIYI 鳄鱼纹晚宴包链条包单肩包 牛皮潮女包漆皮菱格包 清仓包邮', 'MIYI 鳄鱼纹晚宴包链条包单肩包 牛皮潮女包漆皮菱格包 清仓包邮', 'http://img01.taobaocdn.com/bao/uploaded/i1/T1h8HdXXXkXXcz7r.4_051921.jpg', '499.00', 3.00, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CFcRfH0G7DbPkiN9MMMn63%2BmSeCugYXvNBw%2Bn2JNZPYX6rsb5kSrNVff4SB%2FAih1PC6sh8xxuLCe8I2cwxmlKTSqGmwdZnksB7g%2FAUExUi%2BNsiq2xeJHfrsHIEmgAdicJSN%2BfVEl8j9JHIvH5hTXYZAyleokCRvo05IKGfkiLQbV3g%3D&spm=2014.21069764.12504724.0', 1, 0, 0, 0, 0, 1353902318, 'a:10:{i:265;s:6:"漆皮";i:219;s:6:"女包";i:218;s:9:"单肩包";i:258;s:9:"鳄鱼纹";i:243;s:6:"清仓";i:252;s:6:"晚宴";i:233;s:6:"链条";i:223;s:6:"牛皮";i:225;s:6:"包邮";i:230;s:4:"MIYI";}', '', NULL, NULL, NULL, 255, 1),
(40, 161, 1, 20, '熊小熊zz', 'taobao_14668523511', 'MIYI休闲糖果色邮差包韩版撞色单肩斜挎包磨砂牛皮复古包包女包', 'MIYI休闲糖果色邮差包韩版撞色单肩斜挎包磨砂牛皮复古包包女包', 'http://img04.taobaocdn.com/bao/uploaded/i4/T1.Ly7XmhmXXcoBArb_124637.jpg', '398.00', 3.00, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CFcRfH0G7DbPkiN9MMMn63%2BmSeCugYXvNBw%2Bn2JNZPYX6rsb5kSrNVff4SB%2FAih1PC6sh8xxuLCe8I2cwxmlKTSqGmwdZnksB7g%2FAUExUi%2BNsiq2xeJHfrsHIEmgAdicJSN%2BfVEl8j9JHIvH5hTXYZAyleokCRvo0wPBO0A6iguFtc%3D&spm=2014.21069764.12504724.0', 1, 0, 0, 0, 0, 1353902318, 'a:10:{i:217;s:6:"邮差";i:266;s:6:"磨砂";i:219;s:6:"女包";i:237;s:9:"斜挎包";i:226;s:6:"单肩";i:223;s:6:"牛皮";i:28;s:6:"复古";i:232;s:6:"糖果";i:239;s:6:"包包";i:68;s:6:"休闲";}', '', NULL, NULL, NULL, 255, 1),
(41, 3, 1, 13, '想太多妹子', 'taobao_17746295470', '预售款 榴莲家秋冬装新款呢大衣女 双排扣气质呢大衣外套20281', '预售款 榴莲家秋冬装新款呢大衣女 双排扣气质呢大衣外套20281', 'http://img04.taobaocdn.com/bao/uploaded/i4/T1srf5Xm8XXXXV8lI__110350.jpg', '598.00', 5.00, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CITy7klxn%2F7bvn0ay1EA9eYwgGce5X%2FVuK%2F1saFvsUNDKxUoVaj%2Bnu20ZHbE%2BK%2FyHA5iWtQmx1tf%2FVrnk7FgGMwWCrqy3GnH%2BGb3dceDBlCRZCVnS%2BssiomB5oTYYgVWR2PfbhAVaT5A17r5wNbzAjPgNbD0bF9a4sY3mnhUrJI1QU%3D&spm=2014.21069764.12504724.0', 1, 1, 0, 0, 0, 1353902490, 'a:9:{i:272;s:9:"呢大衣";i:89;s:6:"双排";i:273;s:6:"榴莲";i:274;s:9:"秋冬装";i:275;s:6:"预售";i:1;s:6:"外套";i:52;s:6:"新款";i:276;s:6:"气质";i:277;s:5:"20281";}', '', NULL, NULL, NULL, 255, 1),
(42, 3, 1, 8, '枕水而眠', 'taobao_14762203005', '特卖款2012秋冬新款榴莲家 风衣帅气外套 带帽风衣外套LLS1009', '特卖款2012秋冬新款榴莲家 风衣帅气外套 带帽风衣外套LLS1009', 'http://img02.taobaocdn.com/bao/uploaded/i2/T1x7C0XhxqXXbW6xwT_012127.jpg', '168.00', 5.00, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CITy7klxn%2F7bvn0ay1EA9eYwgGce5X%2FVuK%2F1saFvsUNDKxUoVaj%2Bnu20ZHbE%2BK%2FyHA5iWtQmx1tf%2FVrnk7FgGMwWCrqy3GnH%2BGb3dceDBlCRZCVnS%2BssiomB5oTYYgVWR2PfbhAVaT5A17r5wNbzAjPgNbD0bF9a4i5YBIUPsRLrGY%3D&spm=2014.21069764.12504724.0', 1, 0, 0, 0, 0, 1353902490, 'a:10:{i:5;s:6:"风衣";i:69;s:6:"带帽";i:1;s:6:"外套";i:273;s:6:"榴莲";i:278;s:6:"特卖";i:91;s:6:"帅气";i:235;s:6:"秋冬";i:52;s:6:"新款";i:279;s:7:"LLS1009";i:236;s:4:"2012";}', '', NULL, NULL, NULL, 255, 1),
(43, 3, 1, 20, '熊小熊zz', 'taobao_13945261956', '榴莲家2012秋季女装 韩版波点翻袖小西装外套 修身休闲西装 20072', '榴莲家2012秋季女装 韩版波点翻袖小西装外套 修身休闲西装 20072', 'http://img02.taobaocdn.com/bao/uploaded/i2/T1Ag54XbtuXXXfz.I5_060343.jpg', '138.00', 5.00, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CITy7klxn%2F7bvn0ay1EA9eYwgGce5X%2FVuK%2F1saFvsUNDKxUoVaj%2Bnu20ZHbE%2BK%2FyHA5iWtQmx1tf%2FVrnk7FgGMwWCrqy3GnH%2BGb3dceDBlCRZCVnS%2BssiomB5oTYYgVWR2PfbhAVaT5A17r5wNbzAjPgNbD0bF9a4%2FNFb1NzhRMHQI%3D&spm=2014.21069764.12504724.0', 1, 1, 0, 0, 0, 1353902490, 'a:10:{i:273;s:6:"榴莲";i:4;s:6:"西装";i:90;s:9:"小西装";i:62;s:6:"修身";i:280;s:6:"秋季";i:1;s:6:"外套";i:74;s:6:"女装";i:68;s:6:"休闲";i:281;s:5:"20072";i:282;s:9:"韩版波";}', '', NULL, NULL, NULL, 255, 1),
(44, 3, 1, 18, '晨雪熙', 'taobao_20520088006', '预售款 榴莲家2012秋冬新款 RENEEVON★秋款绝美公主外套20398', '预售款 榴莲家2012秋冬新款 RENEEVON★秋款绝美公主外套20398', 'http://img04.taobaocdn.com/bao/uploaded/i4/T1ugbYXkpdXXa56jsZ_033049.jpg', '9999.00', 5.00, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CITy7klxn%2F7bvn0ay1EA9eYwgGce5X%2FVuK%2F1saFvsUNDKxUoVaj%2Bnu20ZHbE%2BK%2FyHA5iWtQmx1tf%2FVrnk7FgGMwWCrqy3GnH%2BGb3dceDBlCRZCVnS%2BssiomB5oTYYgVWR2PfbhAVaT5A17r5wNbzAjPgNbD0bF9aNscxYWO6Y3T2ak%3D&spm=2014.21069764.12504724.0', 1, 0, 0, 0, 0, 1353902490, 'a:9:{i:273;s:6:"榴莲";i:275;s:6:"预售";i:235;s:6:"秋冬";i:1;s:6:"外套";i:52;s:6:"新款";i:283;s:8:"RENEEVON";i:284;s:6:"公主";i:285;s:5:"20398";i:236;s:4:"2012";}', '', NULL, NULL, NULL, 255, 1),
(45, 3, 1, 13, '想太多妹子', 'taobao_16349006926', '预售定金 榴莲家 英伦双排扣毛呢外套牛角扣肩章羊毛呢大衣20459', '预售定金 榴莲家 英伦双排扣毛呢外套牛角扣肩章羊毛呢大衣20459', 'http://img03.taobaocdn.com/bao/uploaded/i3/T1M463XeBdXXb0fkM9_074304.jpg', '2.00', 5.00, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CITy7klxn%2F7bvn0ay1EA9eYwgGce5X%2FVuK%2F1saFvsUNDKxUoVaj%2Bnu20ZHbE%2BK%2FyHA5iWtQmx1tf%2FVrnk7FgGMwWCrqy3GnH%2BGb3dceDBlCRZCVnS%2BssiomB5oTYYgVWR2PfbhAVaT5A17r5wNbzAjPgNbD0bF9a4qaj0gnHglBPFY%3D&spm=2014.21069764.12504724.0', 1, 0, 0, 0, 0, 1353902490, 'a:10:{i:30;s:6:"英伦";i:272;s:9:"呢大衣";i:35;s:6:"毛呢";i:286;s:6:"肩章";i:89;s:6:"双排";i:273;s:6:"榴莲";i:287;s:6:"牛角";i:288;s:6:"定金";i:275;s:6:"预售";i:58;s:6:"羊毛";}', '', NULL, NULL, NULL, 255, 1),
(46, 85, 1, 6, '起个名字太累', 'taobao_12982195747', '远步正品 韩版潮 厚底松糕高帮帆布鞋子 学生休闲鞋 女式帆布鞋', '远步正品 韩版潮 厚底松糕高帮帆布鞋子 学生休闲鞋 女式帆布鞋', 'http://img04.taobaocdn.com/bao/uploaded/i4/T1ZArWXkllXXX.ujTX_085705.jpg', '60.00', 12.50, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CFcRfH0G7DbPkiN9MMMn63%2BnqL8gBcQFdO98b50HYbsskrFEte23HyV7lZ00qP6h3jHsJOqfmR0qC5XAMgK2YydcreFTl5JozOXQzxK1Wb2pZNEXLlCMa6cOlLHAl4yObMOLUPS0wlk62XTU6IRJ9SJWucCj00%2FD87atg12rjPGJKk%3D&spm=2014.21069764.12504724.0', 1, 0, 0, 0, 0, 1353902641, 'a:10:{i:298;s:6:"高帮";i:299;s:6:"松糕";i:300;s:9:"帆布鞋";i:301;s:9:"休闲鞋";i:302;s:6:"帆布";i:303;s:6:"女式";i:51;s:6:"正品";i:304;s:6:"鞋子";i:305;s:6:"学生";i:306;s:9:"韩版潮";}', '', NULL, NULL, NULL, 255, 1),
(47, 85, 1, 11, '彩色淘', 'taobao_15952249939', '淘金币 【远步正品】 经典糖果低帮系带韩版帆布鞋 潮 男女款情侣', '淘金币 【远步正品】 经典糖果低帮系带韩版帆布鞋 潮 男女款情侣', 'http://img01.taobaocdn.com/bao/uploaded/i1/T1EzLEXaFlXXcpN3g3_050111.jpg', '60.00', 12.50, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CFcRfH0G7DbPkiN9MMMn63%2BnqL8gBcQFdO98b50HYbsskrFEte23HyV7lZ00qP6h3jHsJOqfmR0qC5XAMgK2YydcreFTl5JozOXQzxK1Wb2pZNEXLlCMa6cOlLHAl4yObMOLUPS0wlk62XTU6IRJ9SJWucCj00%2FD8mrUL%2BBbYYBCEs%3D&spm=2014.21069764.12504724.0', 1, 0, 0, 0, 0, 1353902641, 'a:9:{i:307;s:6:"女款";i:308;s:6:"系带";i:300;s:9:"帆布鞋";i:309;s:6:"金币";i:51;s:6:"正品";i:232;s:6:"糖果";i:310;s:6:"情侣";i:311;s:6:"经典";i:262;s:6:"韩版";}', '', NULL, NULL, NULL, 255, 1),
(48, 85, 1, 11, '彩色淘', 'taobao_12980731767', '【一淘专享价】远步经典糖果低帮系带韩版帆布鞋 潮 男女款情侣鞋', '【一淘专享价】远步经典糖果低帮系带韩版帆布鞋 潮 男女款情侣鞋', 'http://img01.taobaocdn.com/bao/uploaded/i1/T16.j3XdlbXXa8hGnb_123051.jpg', '41.00', 12.50, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CFcRfH0G7DbPkiN9MMMn63%2BnqL8gBcQFdO98b50HYbsskrFEte23HyV7lZ00qP6h3jHsJOqfmR0qC5XAMgK2YydcreFTl5JozOXQzxK1Wb2pZNEXLlCMa6cOlLHAl4yObMOLUPS0wlk62XTU6IRJ9SJWucCj00%2FD87atg90wyoBEZ8%3D&spm=2014.21069764.12504724.0', 1, 0, 0, 0, 0, 1353902641, 'a:7:{i:307;s:6:"女款";i:308;s:6:"系带";i:300;s:9:"帆布鞋";i:232;s:6:"糖果";i:310;s:6:"情侣";i:311;s:6:"经典";i:262;s:6:"韩版";}', '', NULL, NULL, NULL, 255, 1),
(49, 85, 1, 13, '想太多妹子', 'taobao_12785365662', '【远步正品】 男女帆布鞋韩版 高帮 学生情侣鞋', '【远步正品】 男女帆布鞋韩版 高帮 学生情侣鞋', 'http://img03.taobaocdn.com/bao/uploaded/i3/T1qYjFXbXfXXXvyygU_015147.jpg', '50.00', 12.50, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CFcRfH0G7DbPkiN9MMMn63%2BnqL8gBcQFdO98b50HYbsskrFEte23HyV7lZ00qP6h3jHsJOqfmR0qC5XAMgK2YydcreFTl5JozOXQzxK1Wb2pZNEXLlCMa6cOlLHAl4yObMOLUPS0wlk62XTU6IRJ9SJWucCj00%2FD87UPl%2By7BuIBZk%3D&spm=2014.21069764.12504724.0', 1, 0, 0, 0, 0, 1353902641, 'a:7:{i:298;s:6:"高帮";i:300;s:9:"帆布鞋";i:51;s:6:"正品";i:310;s:6:"情侣";i:312;s:6:"男女";i:305;s:6:"学生";i:262;s:6:"韩版";}', '', NULL, NULL, NULL, 255, 1),
(50, 85, 1, 13, '想太多妹子', 'taobao_15768599582', '【远步正品】2012秋冬新款 星星印花女式低帮帆布鞋学生鞋', '【远步正品】2012秋冬新款 星星印花女式低帮帆布鞋学生鞋', 'http://img01.taobaocdn.com/bao/uploaded/i1/T1K_vfXlJaXXakVJ37_064254.jpg', '72.00', 12.50, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CFcRfH0G7DbPkiN9MMMn63%2BnqL8gBcQFdO98b50HYbsskrFEte23HyV7lZ00qP6h3jHsJOqfmR0qC5XAMgK2YydcreFTl5JozOXQzxK1Wb2pZNEXLlCMa6cOlLHAl4yObMOLUPS0wlk62XTU6IRJ9SJWucCj00%2FD8mlzWCw2NoRMb4%3D&spm=2014.21069764.12504724.0', 1, 1, 0, 0, 0, 1353902641, 'a:9:{i:313;s:9:"学生鞋";i:300;s:9:"帆布鞋";i:303;s:6:"女式";i:51;s:6:"正品";i:314;s:6:"印花";i:235;s:6:"秋冬";i:52;s:6:"新款";i:315;s:6:"星星";i:236;s:4:"2012";}', '', NULL, NULL, NULL, 255, 1),
(51, 85, 1, 12, '跳房子123', 'taobao_14873257471', '【远步正品】男女款 越狱 低帮帆布鞋 情侣鞋', '【远步正品】男女款 越狱 低帮帆布鞋 情侣鞋', 'http://img02.taobaocdn.com/bao/uploaded/i2/T1RR2RXkNcXXceltU7_063938.jpg', '72.00', 12.50, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CFcRfH0G7DbPkiN9MMMn63%2BnqL8gBcQFdO98b50HYbsskrFEte23HyV7lZ00qP6h3jHsJOqfmR0qC5XAMgK2YydcreFTl5JozOXQzxK1Wb2pZNEXLlCMa6cOlLHAl4yObMOLUPS0wlk62XTU6IRJ9SJWucCj00%2FD8g9RPzfYizGfeY%3D&spm=2014.21069764.12504724.0', 1, 0, 0, 0, 0, 1353902642, 'a:5:{i:307;s:6:"女款";i:300;s:9:"帆布鞋";i:51;s:6:"正品";i:316;s:6:"越狱";i:310;s:6:"情侣";}', '', NULL, NULL, NULL, 255, 1),
(52, 85, 1, 6, '起个名字太累', 'taobao_12782178273', '【远步正品】 越狱米勒系列厚底帆布鞋松糕鞋 欧美ca276', '【远步正品】 越狱米勒系列厚底帆布鞋松糕鞋 欧美ca276', 'http://img01.taobaocdn.com/bao/uploaded/i1/T1wnqyXXNfXXa2j1I0_034801.jpg', '15.00', 18.75, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CFcRfH0G7DbPkiN9MMMn63%2BnqL8gBcQFdO98b50HYbsskrFEte23HyV7lZ00qP6h3jHsJOqfmR0qC5XAMgK2YydcreFTl5JozOXQzxK1Wb2pZNEXLlCMa6cOlLHAl4yObMOLUPS0wlk62XTU6IRJ9SJWucCj00%2FD87UPlgEXc20Mfo%3D&spm=2014.21069764.12504724.0', 1, 0, 0, 0, 0, 1353902642, 'a:8:{i:317;s:6:"米勒";i:318;s:9:"松糕鞋";i:300;s:9:"帆布鞋";i:51;s:6:"正品";i:316;s:6:"越狱";i:25;s:6:"欧美";i:319;s:6:"系列";i:320;s:5:"ca276";}', '', NULL, NULL, NULL, 255, 1),
(53, 85, 1, 14, '泡芙小米粒', 'taobao_20660344503', '淘金币 【远步正品】 2012新款 星旗条纹男女帆布鞋情侣鞋子', '淘金币 【远步正品】 2012新款 星旗条纹男女帆布鞋情侣鞋子', 'http://img03.taobaocdn.com/bao/uploaded/i3/T197PPXgVoXXcy8OM._112623.jpg', '60.00', 12.50, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CFcRfH0G7DbPkiN9MMMn63%2BnqL8gBcQFdO98b50HYbsskrFEte23HyV7lZ00qP6h3jHsJOqfmR0qC5XAMgK2YydcreFTl5JozOXQzxK1Wb2pZNEXLlCMa6cOlLHAl4yObMOLUPS0wlk62XTU6IRJ9SJWucCj00%2FDCTp2ZZlsJkJKw8%3D&spm=2014.21069764.12504724.0', 1, 0, 0, 0, 0, 1353902642, 'a:10:{i:321;s:6:"星旗";i:300;s:9:"帆布鞋";i:322;s:6:"条纹";i:309;s:6:"金币";i:51;s:6:"正品";i:304;s:6:"鞋子";i:52;s:6:"新款";i:310;s:6:"情侣";i:312;s:6:"男女";i:236;s:4:"2012";}', '', NULL, NULL, NULL, 255, 1),
(54, 85, 1, 8, '枕水而眠', 'taobao_12981939978', '【远步正品】2012秋冬新款 英伦印花松糕厚底高帮鞋 松糕鞋女款', '【远步正品】2012秋冬新款 英伦印花松糕厚底高帮鞋 松糕鞋女款', 'http://img04.taobaocdn.com/bao/uploaded/i4/T1ac2vXcRvXXXE1hsU_014747.jpg', '60.00', 12.50, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CFcRfH0G7DbPkiN9MMMn63%2BnqL8gBcQFdO98b50HYbsskrFEte23HyV7lZ00qP6h3jHsJOqfmR0qC5XAMgK2YydcreFTl5JozOXQzxK1Wb2pZNEXLlCMa6cOlLHAl4yObMOLUPS0wlk62XTU6IRJ9SJWucCj00%2FD87atg4fR6yCAUY%3D&spm=2014.21069764.12504724.0', 1, 0, 0, 0, 0, 1353902642, 'a:10:{i:307;s:6:"女款";i:30;s:6:"英伦";i:299;s:6:"松糕";i:323;s:9:"高帮鞋";i:318;s:9:"松糕鞋";i:314;s:6:"印花";i:51;s:6:"正品";i:235;s:6:"秋冬";i:52;s:6:"新款";i:236;s:4:"2012";}', '', NULL, NULL, NULL, 255, 1),
(55, 85, 1, 17, 'V小莲小莲V', 'taobao_14784242453', '【远步正品】2012秋冬新款 韩版星星印花女式低帮帆布鞋学生鞋', '【远步正品】2012秋冬新款 韩版星星印花女式低帮帆布鞋学生鞋', 'http://img02.taobaocdn.com/bao/uploaded/i2/T1E2O9XhFvXXbOmjZW_024241.jpg', '40.00', 12.50, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CFcRfH0G7DbPkiN9MMMn63%2BnqL8gBcQFdO98b50HYbsskrFEte23HyV7lZ00qP6h3jHsJOqfmR0qC5XAMgK2YydcreFTl5JozOXQzxK1Wb2pZNEXLlCMa6cOlLHAl4yObMOLUPS0wlk62XTU6IRJ9SJWucCj00%2FD8gySmTQ9k3k3QE%3D&spm=2014.21069764.12504724.0', 1, 0, 0, 0, 0, 1353902642, 'a:10:{i:313;s:9:"学生鞋";i:300;s:9:"帆布鞋";i:303;s:6:"女式";i:51;s:6:"正品";i:314;s:6:"印花";i:235;s:6:"秋冬";i:52;s:6:"新款";i:315;s:6:"星星";i:262;s:6:"韩版";i:236;s:4:"2012";}', '', NULL, NULL, NULL, 255, 1),
(56, 85, 1, 9, 'wingsa区', 'taobao_15952469075', '【远步正品】2012秋冬新款男女帆布鞋韩版 女 潮 高帮 学生情侣鞋', '【远步正品】2012秋冬新款男女帆布鞋韩版 女 潮 高帮 学生情侣鞋', 'http://img04.taobaocdn.com/bao/uploaded/i4/T1l3fIXkFgXXc53Jk9_102745.jpg', '70.00', 12.50, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CFcRfH0G7DbPkiN9MMMn63%2BnqL8gBcQFdO98b50HYbsskrFEte23HyV7lZ00qP6h3jHsJOqfmR0qC5XAMgK2YydcreFTl5JozOXQzxK1Wb2pZNEXLlCMa6cOlLHAl4yObMOLUPS0wlk62XTU6IRJ9SJWucCj00%2FD8mrUL%2BHlCMFnrc%3D&spm=2014.21069764.12504724.0', 1, 0, 0, 0, 0, 1353902642, 'a:10:{i:298;s:6:"高帮";i:300;s:9:"帆布鞋";i:51;s:6:"正品";i:235;s:6:"秋冬";i:52;s:6:"新款";i:310;s:6:"情侣";i:312;s:6:"男女";i:305;s:6:"学生";i:262;s:6:"韩版";i:236;s:4:"2012";}', '', NULL, NULL, NULL, 255, 1),
(57, 85, 1, 16, 'Eudora_寻寻', 'taobao_12782230855', '【远步正品】2012秋冬新款 印花高帮帆布鞋 韩版 学生女鞋', '【远步正品】2012秋冬新款 印花高帮帆布鞋 韩版 学生女鞋', 'http://img01.taobaocdn.com/bao/uploaded/i1/T1msjzXfFmXXbavIAU_013829.jpg', '59.00', 12.50, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CFcRfH0G7DbPkiN9MMMn63%2BnqL8gBcQFdO98b50HYbsskrFEte23HyV7lZ00qP6h3jHsJOqfmR0qC5XAMgK2YydcreFTl5JozOXQzxK1Wb2pZNEXLlCMa6cOlLHAl4yObMOLUPS0wlk62XTU6IRJ9SJWucCj00%2FD87UPlgHfNMDUGk%3D&spm=2014.21069764.12504724.0', 1, 0, 0, 0, 0, 1353902642, 'a:10:{i:298;s:6:"高帮";i:300;s:9:"帆布鞋";i:324;s:6:"女鞋";i:51;s:6:"正品";i:314;s:6:"印花";i:235;s:6:"秋冬";i:52;s:6:"新款";i:305;s:6:"学生";i:262;s:6:"韩版";i:236;s:4:"2012";}', '', NULL, NULL, NULL, 255, 1),
(58, 85, 1, 19, '安土桃山', 'taobao_13314371652', '【远步正品】 加厚松高鞋休闲棉帆布鞋 韩版厚底帆松糕鞋', '【远步正品】 加厚松高鞋休闲棉帆布鞋 韩版厚底帆松糕鞋', 'http://img01.taobaocdn.com/bao/uploaded/i1/T1RKfEXkxkXXc.bh3U_014824.jpg', '56.00', 12.50, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CFcRfH0G7DbPkiN9MMMn63%2BnqL8gBcQFdO98b50HYbsskrFEte23HyV7lZ00qP6h3jHsJOqfmR0qC5XAMgK2YydcreFTl5JozOXQzxK1Wb2pZNEXLlCMa6cOlLHAl4yObMOLUPS0wlk62XTU6IRJ9SJWucCj00%2FD89EJRJXWpriwO0%3D&spm=2014.21069764.12504724.0', 1, 0, 0, 0, 0, 1353902643, 'a:7:{i:300;s:9:"帆布鞋";i:318;s:9:"松糕鞋";i:65;s:6:"加厚";i:51;s:6:"正品";i:68;s:6:"休闲";i:325;s:6:"高鞋";i:326;s:9:"韩版厚";}', '', NULL, NULL, NULL, 255, 1),
(59, 85, 1, 6, '起个名字太累', 'taobao_19956712265', '【远步正品】2012秋冬季印花高帮帆布鞋 韩版 学生女鞋', '【远步正品】2012秋冬季印花高帮帆布鞋 韩版 学生女鞋', 'http://img02.taobaocdn.com/bao/uploaded/i2/T1_tHLXn4fXXXLjDMT_013219.jpg', '60.00', 12.50, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CFcRfH0G7DbPkiN9MMMn63%2BnqL8gBcQFdO98b50HYbsskrFEte23HyV7lZ00qP6h3jHsJOqfmR0qC5XAMgK2YydcreFTl5JozOXQzxK1Wb2pZNEXLlCMa6cOlLHAl4yObMOLUPS0wlk62XTU6IRJ9SJWucCj00%2FD8XQM%2FadiioY1J4%3D&spm=2014.21069764.12504724.0', 1, 0, 0, 0, 0, 1353902643, 'a:9:{i:298;s:6:"高帮";i:327;s:9:"秋冬季";i:300;s:9:"帆布鞋";i:324;s:6:"女鞋";i:51;s:6:"正品";i:314;s:6:"印花";i:305;s:6:"学生";i:262;s:6:"韩版";i:236;s:4:"2012";}', '', NULL, NULL, NULL, 255, 1);
INSERT INTO `pin_item` (`id`, `cate_id`, `orig_id`, `uid`, `uname`, `key_id`, `title`, `intro`, `img`, `price`, `rates`, `url`, `type`, `hits`, `likes`, `comments`, `cmt_taobao_time`, `add_time`, `tag_cache`, `comments_cache`, `seo_title`, `seo_keys`, `seo_desc`, `ordid`, `status`) VALUES
(60, 85, 1, 18, '晨雪熙', 'taobao_17617443867', '远步正品 韩版潮 厚底松糕鞋 高帮布鞋子学生休闲鞋 女鞋帆布鞋', '远步正品 韩版潮 厚底松糕鞋 高帮布鞋子学生休闲鞋 女鞋帆布鞋', 'http://img03.taobaocdn.com/bao/uploaded/i3/T1A4n_XglcXXcUv5g0_035537.jpg', '110.00', 12.50, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CFcRfH0G7DbPkiN9MMMn63%2BnqL8gBcQFdO98b50HYbsskrFEte23HyV7lZ00qP6h3jHsJOqfmR0qC5XAMgK2YydcreFTl5JozOXQzxK1Wb2pZNEXLlCMa6cOlLHAl4yObMOLUPS0wlk62XTU6IRJ9SJWucCj00%2FD8stN1dxo62Vsxs%3D&spm=2014.21069764.12504724.0', 1, 0, 0, 0, 0, 1353902643, 'a:9:{i:298;s:6:"高帮";i:328;s:6:"子学";i:318;s:9:"松糕鞋";i:301;s:9:"休闲鞋";i:300;s:9:"帆布鞋";i:324;s:6:"女鞋";i:329;s:6:"布鞋";i:51;s:6:"正品";i:306;s:9:"韩版潮";}', '', NULL, NULL, NULL, 255, 1),
(61, 85, 1, 9, 'wingsa区', 'taobao_12789081315', '【远步正品】2012秋冬新款时尚女士平底加绒中筒雪地靴 包邮', '【远步正品】2012秋冬新款时尚女士平底加绒中筒雪地靴 包邮', 'http://img02.taobaocdn.com/bao/uploaded/i2/T1MDaHXc0rXXaonAs9_104246.jpg', '85.00', 12.50, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CFcRfH0G7DbPkiN9MMMn63%2BnqL8gBcQFdO98b50HYbsskrFEte23HyV7lZ00qP6h3jHsJOqfmR0qC5XAMgK2YydcreFTl5JozOXQzxK1Wb2pZNEXLlCMa6cOlLHAl4yObMOLUPS0wlk62XTU6IRJ9SJWucCj00%2FD87UPlNQJaowqzY%3D&spm=2014.21069764.12504724.0', 1, 0, 0, 0, 0, 1353902643, 'a:9:{i:331;s:6:"平底";i:332;s:9:"雪地靴";i:51;s:6:"正品";i:235;s:6:"秋冬";i:52;s:6:"新款";i:228;s:6:"女士";i:83;s:6:"时尚";i:225;s:6:"包邮";i:236;s:4:"2012";}', '', NULL, NULL, NULL, 255, 1),
(62, 88, 1, 10, '设计系小女生', 'taobao_13413548963', '【远步正品】  2011冬季时尚女士平底雪地靴 棉鞋', '【远步正品】  2011冬季时尚女士平底雪地靴 棉鞋', 'http://img03.taobaocdn.com/bao/uploaded/i3/T1hG1IXelfXXcX4o.9_105150.jpg', '85.00', 12.50, 'http://s.click.taobao.com/t?e=zGU34CA7K%2BPkqB07S4%2FK0CFcRfH0G7DbPkiN9MMMn63%2BnqL8gBcQFdO98b50HYbsskrFEte23HyV7lZ00qP6h3jHsJOqfmR0qC5XAMgK2YydcreFTl5JozOXQzxK1Wb2pZNEXLlCMa6cOlLHAl4yObMOLUPS0wlk62XTU6IRJ9SJWucCj00%2FD89D5%2BIHk0v7raI%3D&spm=2014.21069764.12504724.0', 1, 0, 0, 0, 0, 1353902643, 'a:8:{i:333;s:6:"棉鞋";i:331;s:6:"平底";i:332;s:9:"雪地靴";i:51;s:6:"正品";i:334;s:6:"冬季";i:228;s:6:"女士";i:83;s:6:"时尚";i:335;s:4:"2011";}', '', '', '', '', 255, 1),
(63, 333, 1, 18, '晨雪熙', NULL, '南非进口黄柠檬 6个装 ', '南非进口黄柠檬 6个装 ', '1709/04/59ad10fab7bf9.jpg', '29.00', 0.00, '', 1, 0, 0, 0, 0, 1504514298, 'a:3:{i:420;s:6:"南非";i:421;s:6:"柠檬";i:422;s:6:"进口";}', '', '', '', '', 255, 1),
(64, 333, 1, 19, '安土桃山', NULL, '智利进口新鲜蓝莓 4盒', '智利进口新鲜蓝莓 4盒', '1709/04/59ad1128d930c.jpg', '99.00', 0.00, '', 1, 0, 0, 0, 0, 1504514345, 'a:4:{i:423;s:6:"智利";i:424;s:6:"蓝莓";i:425;s:6:"新鲜";i:422;s:6:"进口";}', '', '', '', '', 255, 1),
(65, 333, 1, 8, '枕水而眠', NULL, '美国进口红啤梨 6个', '美国进口红啤梨 6个', '1709/04/59ad116696dfb.jpg', '48.00', 0.00, '', 1, 0, 0, 0, 0, 1504514406, 'a:2:{i:123;s:6:"口红";i:426;s:6:"美国";}', '', '', '', '', 255, 1),
(66, 333, 1, 20, '熊小熊zz', NULL, '美国进口无籽红提 1kg ', '美国进口无籽红提 1kg ', '1709/04/59ad119657ec3.jpg', '39.00', 0.00, '', 1, 0, 0, 0, 0, 1504514454, 'a:5:{i:427;s:6:"红提";i:428;s:6:"无籽";i:426;s:6:"美国";i:422;s:6:"进口";i:429;s:3:"1kg";}', '', '', '', '', 255, 1),
(67, 333, 1, 8, '枕水而眠', NULL, '国产绿奇异果 16颗 ', '国产绿奇异果 16颗 ', '1709/04/59ad11bb8a1eb.jpg', '47.00', 0.00, '', 1, 0, 0, 0, 0, 1504514491, 'a:2:{i:430;s:6:"奇异";i:431;s:6:"国产";}', '', '', '', '', 255, 1),
(68, 333, 1, 18, '晨雪熙', NULL, '浙江涌泉蜜桔无核桔子5斤', '浙江涌泉蜜桔无核桔子5斤', '1709/04/59ad12a82ee26.jpg', '89.00', 0.00, '', 1, 0, 0, 0, 0, 1504514728, 'a:5:{i:432;s:6:"蜜桔";i:433;s:6:"无核";i:434;s:6:"涌泉";i:435;s:6:"桔子";i:436;s:6:"浙江";}', '', '', '', '', 255, 1);

-- --------------------------------------------------------

--
-- 表的结构 `pin_item_attr`
--

CREATE TABLE IF NOT EXISTS `pin_item_attr` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `item_id` int(10) NOT NULL,
  `attr_name` varchar(50) NOT NULL,
  `attr_value` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `pin_item_cate`
--

CREATE TABLE IF NOT EXISTS `pin_item_cate` (
  `id` smallint(4) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `tags` varchar(50) NOT NULL,
  `pid` smallint(4) unsigned NOT NULL,
  `spid` varchar(50) NOT NULL,
  `img` varchar(255) NOT NULL,
  `fcolor` varchar(10) NOT NULL,
  `remark` text NOT NULL,
  `add_time` int(10) NOT NULL,
  `items` int(10) unsigned NOT NULL DEFAULT '0',
  `likes` int(10) NOT NULL,
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0:商品分类 1:标签分类',
  `ordid` tinyint(3) unsigned NOT NULL DEFAULT '255',
  `status` tinyint(1) NOT NULL,
  `is_index` tinyint(1) NOT NULL DEFAULT '0',
  `is_default` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `seo_title` varchar(255) NOT NULL,
  `seo_keys` varchar(255) NOT NULL,
  `seo_desc` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=334 ;

--
-- 转存表中的数据 `pin_item_cate`
--

INSERT INTO `pin_item_cate` (`id`, `name`, `tags`, `pid`, `spid`, `img`, `fcolor`, `remark`, `add_time`, `items`, `likes`, `type`, `ordid`, `status`, `is_index`, `is_default`, `seo_title`, `seo_keys`, `seo_desc`) VALUES
(1, '衣服', '', 0, '0', '', '', '', 0, 0, 0, 0, 1, 1, 1, 0, '', '', ''),
(2, '热门款式', '', 1, '1|', '', '', '', 0, 0, 0, 0, 1, 1, 0, 0, '', '', ''),
(3, '外套', '', 2, '1|2|', '50b2e01aea8b9_thumb.jpg', '', '', 0, 0, 0, 0, 255, 1, 1, 0, '', '', ''),
(4, '毛衣', '', 2, '1|2|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(5, 'T恤', '', 2, '1|2|', '50b2e02405c92_thumb.jpg', '', '', 0, 0, 0, 0, 255, 1, 1, 0, '', '', ''),
(6, '西装', '', 2, '1|2|', '50b2e02e0332f_thumb.jpg', '', '', 0, 0, 0, 0, 255, 1, 1, 0, '', '', ''),
(7, '风衣', '', 2, '1|2|', '50b2e03a38859_thumb.jpg', '', '', 0, 0, 0, 0, 255, 1, 1, 0, '', '', ''),
(8, '卫衣', '', 2, '1|2|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(9, '马甲', '', 2, '1|2|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(10, '牛仔裤', '', 2, '1|2|', '50b2e044c46ad_thumb.jpg', '', '', 0, 0, 0, 0, 255, 1, 1, 0, '', '', ''),
(11, '小脚裤', '', 2, '1|2|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(12, '哈伦裤', '', 2, '1|2|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(319, '黑色', '', 315, '1|315|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(318, '黄色', '', 315, '1|315|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(317, '绿色', '', 315, '1|315|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(316, '红色', '', 315, '1|315|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(17, '打底裤', '', 2, '1|2|', '50b2e06575aa1_thumb.jpg', '', '', 0, 0, 0, 0, 255, 1, 1, 0, '', '', ''),
(18, '五分裤', '', 2, '1|2|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(315, '颜色', '', 1, '1|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(20, '当季流行', '', 1, '1|', '', '', '', 0, 0, 0, 1, 2, 1, 0, 0, '', '', ''),
(21, '蕾丝', '', 20, '1|20|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(22, '打底', '', 20, '1|20|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(23, '牛仔', '', 20, '1|20|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(24, '镂空', '', 20, '1|20|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(25, '拼接', '', 20, '1|20|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(26, '紧身', '', 20, '1|20|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(27, '格子', '', 20, '1|20|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(28, '水洗', '', 20, '1|20|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(29, '高腰', '', 20, '1|20|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(30, '磨旧', '', 20, '1|20|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(31, '热门风格', '', 1, '1|', '', '', '', 0, 0, 0, 1, 3, 1, 0, 0, '', '', ''),
(32, '宽松', '', 31, '1|31|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(33, '清新', '', 31, '1|31|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(34, '欧美', '', 31, '1|31|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(35, '韩系', '', 31, '1|31|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(36, '甜美', '', 31, '1|31|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(37, '复古', '', 31, '1|31|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(38, '简约', '', 31, '1|31|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(39, '英伦', '', 31, '1|31|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(40, '材质', '', 1, '1|', '', '', '', 0, 0, 0, 1, 4, 1, 0, 0, '', '', ''),
(41, '珊瑚绒', '', 40, '1|40|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(42, '莫代尔', '', 40, '1|40|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(43, '纯棉', '', 40, '1|40|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(44, '全棉', '', 40, '1|40|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(45, '毛呢', '', 40, '1|40|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(46, '牛仔', '', 40, '1|40|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(47, '针织', '', 40, '1|40|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(48, '毛绒', '', 40, '1|40|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(49, '雪纺', '', 40, '1|40|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(50, '鞋子', '', 0, '0', '', '', '', 0, 0, 0, 0, 2, 1, 1, 0, '', '', ''),
(51, '热门风格', '', 50, '50|', '', '', '', 0, 0, 0, 1, 5, 1, 1, 0, '', '', ''),
(52, '优雅', '', 51, '50|51|', '', '', '', 0, 0, 0, 1, 255, 1, 1, 0, '', '', ''),
(53, '朋克', '', 51, '50|51|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(54, '名媛', '', 51, '50|51|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(55, '复古', '', 51, '50|51|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(56, '甜美', '', 51, '50|51|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(57, '百搭', '', 51, '50|51|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(58, '欧美', '', 51, '50|51|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(59, '英伦', '', 51, '50|51|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(60, '当季流行', '', 50, '50|', '', '', '', 0, 0, 0, 1, 4, 1, 0, 0, '', '', ''),
(61, '细跟', '', 60, '50|60|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(62, '圆头', '', 60, '50|60|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(63, '铆钉', '', 60, '50|60|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(64, '豹纹', '', 60, '50|60|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(65, '防水台', '', 60, '50|60|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(66, '流苏', '', 60, '50|60|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(67, '粗跟', '', 60, '50|60|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(68, '尖头', '', 60, '50|60|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(69, '坡跟', '', 60, '50|60|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(70, '厚底', '', 60, '50|60|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(71, '系带', '', 60, '50|60|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(72, '撞色', '', 60, '50|60|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(73, '当季热款', '', 50, '50|', '', '', '', 0, 0, 0, 0, 3, 1, 0, 0, '', '', ''),
(74, '工装靴', '', 73, '50|73|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(75, '长靴', '', 73, '50|73|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(76, '复古鞋', '', 73, '50|73|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(77, '马靴', '', 73, '50|73|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(78, '布洛克鞋', '', 73, '50|73|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(79, '及裸靴', '', 73, '50|73|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(80, '休闲风格', '', 50, '50|', '', '', '', 0, 0, 0, 0, 2, 1, 0, 0, '', '', ''),
(81, '豆豆鞋', '', 80, '50|80|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(82, '休闲鞋', '', 80, '50|80|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(83, '高帮鞋', '', 80, '50|80|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(84, '运动鞋', '', 80, '50|80|', '50b2e09aa9967_thumb.jpeg', '', '', 0, 0, 0, 0, 255, 1, 1, 0, '', '', ''),
(85, '帆布鞋', '', 80, '50|80|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(86, '松糕鞋', '', 80, '50|80|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(87, '厚底鞋', '', 80, '50|80|', '50b2e0a2e6b97_thumb.jpeg', '', '', 0, 0, 0, 0, 255, 1, 1, 0, '', '', ''),
(88, '雪地靴', '', 80, '50|80|', '50b2e0aabcb80_thumb.jpeg', '', '', 0, 0, 0, 0, 255, 1, 1, 0, '', '', ''),
(89, '家居鞋', '', 80, '50|80|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(90, '时尚单鞋', '', 50, '50|', '', '', '', 0, 0, 0, 0, 1, 1, 0, 0, '', '', ''),
(91, '低跟鞋', '', 90, '50|90|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(92, '细跟鞋', '', 90, '50|90|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(93, '牛津鞋', '', 90, '50|90|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(94, '中跟鞋', '', 90, '50|90|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(95, '单鞋', '', 90, '50|90|', '50b2e07ae109c_thumb.jpeg', '', '', 0, 0, 0, 0, 255, 1, 1, 0, '', '', ''),
(96, '粗跟鞋', '', 90, '50|90|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(97, '坡跟鞋', '', 90, '50|90|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(98, '平底鞋', '', 90, '50|90|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(99, '马丁靴', '', 90, '50|90|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(100, '高跟鞋', '', 90, '50|90|', '50b2e086780ab_thumb.jpeg', '', '', 0, 0, 0, 0, 255, 1, 1, 0, '', '', ''),
(101, '短靴', '', 90, '50|90|', '50b2e091e2cec_thumb.jpeg', '', '', 0, 0, 0, 0, 255, 1, 1, 0, '', '', ''),
(102, '包包', '', 0, '0', '', '', '', 0, 0, 0, 0, 255, 1, 1, 0, '', '', ''),
(103, '材质属性', '', 102, '102|', '', '', '', 0, 0, 0, 1, 4, 1, 0, 0, '', '', ''),
(104, '真皮', '', 103, '102|103|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(105, '金属', '', 103, '102|103|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(106, '透明', '', 103, '102|103|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(107, '棉麻', '', 103, '102|103|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(108, '羊皮', '', 103, '102|103|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(109, 'PU', '', 103, '102|103|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(110, '帆布', '', 103, '102|103|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(111, '牛皮', '', 103, '102|103|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(112, '当季流行', '', 102, '102|', '', '', '', 0, 0, 0, 1, 3, 1, 0, 0, '', '', ''),
(113, '代购', '', 112, '102|112|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(114, '配饰', '', 0, '0', '', '', '', 0, 0, 0, 0, 255, 1, 1, 0, '', '', ''),
(115, '家居', '', 0, '0', '', '', '', 0, 0, 0, 0, 255, 1, 1, 0, '', '', ''),
(116, '美容', '', 0, '0', '', '', '', 0, 0, 0, 0, 255, 1, 1, 0, '', '', ''),
(117, '铆钉', '', 112, '102|112|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(118, '豹纹', '', 112, '102|112|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(119, '菱形格', '', 112, '102|112|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(120, '甜美', '', 112, '102|112|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(121, '复古', '', 112, '102|112|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(122, '外贸', '', 112, '102|112|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(123, '链条', '', 112, '102|112|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(125, '经典包包', '', 102, '102|', '', '', '', 0, 0, 0, 0, 1, 1, 0, 0, '', '', ''),
(126, '热门款式', '', 102, '102|', '', '', '', 0, 0, 0, 0, 2, 1, 0, 0, '', '', ''),
(127, '马鞍包', '', 125, '102|125|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(128, '相机包', '', 125, '102|125|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(129, '热门元素', '', 114, '114|', '', '', '', 0, 0, 0, 1, 5, 1, 0, 0, '', '', ''),
(130, '信封包', '', 125, '102|125|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(131, '热门风格', '', 114, '114|', '', '', '', 0, 0, 0, 1, 4, 1, 0, 0, '', '', ''),
(132, '剑桥包', '', 125, '102|125|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(133, '医生包', '', 125, '102|125|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(134, '当季流行', '', 114, '114|', '', '', '', 0, 0, 0, 0, 1, 1, 0, 0, '', '', ''),
(135, '笑脸包', '', 125, '102|125|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(136, '热门首饰', '', 114, '114|', '', '', '', 0, 0, 0, 0, 2, 1, 0, 0, '', '', ''),
(137, '波士顿包', '', 125, '102|125|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(138, '热门配件', '', 114, '114|', '', '', '', 0, 0, 0, 0, 3, 1, 0, 0, '', '', ''),
(139, '邮差包', '', 125, '102|125|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(140, '机车包', '', 125, '102|125|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(141, '行李箱', '', 125, '102|125|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(142, '厨房', '', 115, '115|', '', '', '', 0, 0, 0, 0, 2, 1, 0, 0, '', '', ''),
(143, '水桶包', '', 125, '102|125|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(144, '卧室', '', 115, '115|', '', '', '', 0, 0, 0, 0, 3, 1, 0, 0, '', '', ''),
(145, '手提包', '', 125, '102|125|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(146, '起居室', '', 115, '115|', '', '', '', 0, 0, 0, 0, 4, 1, 0, 0, '', '', ''),
(147, '家', '', 115, '115|', '', '', '', 0, 0, 0, 0, 1, 1, 0, 0, '', '', ''),
(148, '帆布包', '', 126, '102|126|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(149, '卫浴', '', 115, '115|', '', '', '', 0, 0, 0, 0, 5, 1, 0, 0, '', '', ''),
(150, '链条包', '', 126, '102|126|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(151, '复古包', '', 126, '102|126|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(152, '手拿包', '', 126, '102|126|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(153, '功效', '', 116, '116|', '', '', '', 0, 0, 0, 1, 4, 1, 0, 0, '', '', ''),
(154, '斜挎包', '', 126, '102|126|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(155, '热门品牌', '', 116, '116|', '', '', '', 0, 0, 0, 1, 5, 1, 0, 0, '', '', ''),
(156, '大包', '', 126, '102|126|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(157, '美体', '', 116, '116|', '', '', '', 0, 0, 0, 0, 1, 1, 0, 0, '', '', ''),
(158, '钱包', '', 126, '102|126|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(159, '彩妆', '', 116, '116|', '', '', '', 0, 0, 0, 0, 2, 1, 0, 0, '', '', ''),
(160, '双肩包', '', 126, '102|126|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(161, '单肩包', '', 126, '102|126|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(162, '护肤', '', 116, '116|', '', '', '', 0, 0, 0, 0, 3, 1, 0, 0, '', '', ''),
(163, '花朵', '', 129, '114|129|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(164, '玉', '', 129, '114|129|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(165, '24K金', '', 129, '114|129|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(166, '水晶', '', 129, '114|129|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(167, '玫瑰金', '', 129, '114|129|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(168, '银饰', '', 129, '114|129|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(169, '印花', '', 129, '114|129|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(170, '哥特', '', 131, '114|131|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(171, '欧美', '', 131, '114|131|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(172, '韩系', '', 131, '114|131|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(173, '英伦', '', 131, '114|131|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(174, '个性', '', 131, '114|131|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(175, '甜美', '', 131, '114|131|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(176, '朋克', '', 131, '114|131|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(177, '复古', '', 131, '114|131|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(178, '袜套', '', 134, '114|134|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(179, '电子表', '', 134, '114|134|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(180, '发带', '', 134, '114|134|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(181, '礼帽', '', 134, '114|134|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(182, '锁骨链', '', 134, '114|134|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(183, '鸭舌帽', '', 134, '114|134|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(184, '贝雷帽', '', 134, '114|134|', '50b2dc6c73cb4_thumb.jpeg', '', '', 0, 0, 0, 0, 255, 1, 1, 0, '', '', ''),
(185, '假领', '', 134, '114|134|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(186, '发饰', '', 134, '114|134|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(187, '脚链', '', 136, '114|136|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(188, '腰链', '', 136, '114|136|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(189, '手镯', '', 136, '114|136|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(190, '手链', '', 136, '114|136|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(191, '耳环', '', 136, '114|136|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(192, '戒指', '', 136, '114|136|', '50b2dc7deb82f_thumb.jpeg', '', '', 0, 0, 0, 0, 255, 1, 1, 0, '', '', ''),
(193, '耳钉', '', 136, '114|136|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(194, '项链', '', 136, '114|136|', '50b2dc8787567_thumb.jpeg', '', '', 0, 0, 0, 0, 255, 1, 1, 0, '', '', ''),
(195, '墨镜', '', 138, '114|138|', '50b2dcb8b134a_thumb.jpeg', '', '', 0, 0, 0, 0, 255, 1, 1, 0, '', '', ''),
(196, '钥匙链', '', 138, '114|138|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(197, '腰带', '', 138, '114|138|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(198, '手套', '', 138, '114|138|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(199, '头花', '', 138, '114|138|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(200, '毛衣链', '', 138, '114|138|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(201, '瘦腿袜', '', 138, '114|138|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(202, '发箍', '', 138, '114|138|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(203, '手表', '', 138, '114|138|', '50b2dc974a19b_thumb.jpeg', '', '', 0, 0, 0, 0, 255, 1, 1, 0, '', '', ''),
(204, '帽子', '', 138, '114|138|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(205, '围巾', '', 138, '114|138|', '50b2dca7045fc_thumb.jpeg', '', '', 0, 0, 0, 0, 255, 1, 1, 0, '', '', ''),
(206, '储物罐', '', 142, '115|142|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(207, '烹饪', '', 142, '115|142|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(208, '烘焙', '', 142, '115|142|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(209, '锅具', '', 142, '115|142|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(210, '饭盒', '', 142, '115|142|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(211, '筷子', '', 142, '115|142|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(212, '勺', '', 142, '115|142|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(213, '茶具', '', 142, '115|142|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(214, '水壶', '', 142, '115|142|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(215, '盘碟', '', 142, '115|142|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(216, '调味瓶', '', 142, '115|142|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(217, '餐巾', '', 142, '115|142|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(218, '餐垫', '', 142, '115|142|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(219, '床上用品', '', 144, '115|144|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(220, '梳妆', '', 144, '115|144|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(221, '家居鞋', '', 144, '115|144|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(222, '窗帘', '', 144, '115|144|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(223, '斗柜', '', 144, '115|144|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(224, '衣柜', '', 144, '115|144|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(225, '床头柜', '', 144, '115|144|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(226, '床', '', 144, '115|144|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(227, '茶几', '', 146, '115|146|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(228, '搁板', '', 146, '115|146|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(229, '电视柜', '', 146, '115|146|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(230, '椅子', '', 146, '115|146|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(231, '桌子', '', 146, '115|146|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(232, '坐垫', '', 146, '115|146|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(233, '沙发垫', '', 146, '115|146|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(234, '照片墙', '', 146, '115|146|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(235, '沙发', '', 146, '115|146|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(236, '相框', '', 146, '115|146|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(237, '收纳', '', 147, '115|147|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(238, '台灯', '', 147, '115|147|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(239, '时钟', '', 147, '115|147|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(240, '吊灯', '', 147, '115|147|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(241, '吸顶灯', '', 147, '115|147|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(242, '杯子', '', 147, '115|147|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(243, '置物架', '', 147, '115|147|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(244, '香薰', '', 147, '115|147|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(245, '地毯', '', 147, '115|147|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(246, '落地灯', '', 147, '115|147|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(247, '桌布', '', 147, '115|147|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(248, '摆件', '', 147, '115|147|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(249, '墙贴', '', 147, '115|147|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(250, '烛台', '', 147, '115|147|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(251, '书柜', '', 147, '115|147|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(252, '挂钩', '', 149, '115|149|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(253, '马桶刷', '', 149, '115|149|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(254, '衣架', '', 149, '115|149|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(255, '皂盒', '', 149, '115|149|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(256, '浴室垫', '', 149, '115|149|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(257, '浴室套件', '', 149, '115|149|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(258, '浴帘', '', 149, '115|149|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(259, '毛巾', '', 149, '115|149|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(260, '补水', '', 153, '116|153|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(261, '控油', '', 153, '116|153|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(262, '美白', '', 153, '116|153|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(263, '遮瑕', '', 153, '116|153|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(264, '去角质', '', 153, '116|153|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(265, '祛痘', '', 153, '116|153|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(266, '保湿', '', 153, '116|153|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(267, '洁面', '', 153, '116|153|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(268, '去黑头', '', 153, '116|153|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(269, '收毛孔', '', 153, '116|153|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(270, '去眼袋', '', 153, '116|153|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(271, '倩碧', '', 155, '116|155|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(272, '雅漾', '', 155, '116|155|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(273, '资生堂', '', 155, '116|155|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(274, '娇韵诗', '', 155, '116|155|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(275, '欧舒丹', '', 155, '116|155|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(276, '兰蔻', '', 155, '116|155|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(277, '水宝宝', '', 155, '116|155|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(278, '雅诗兰黛', '', 155, '116|155|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(279, '丝芙兰', '', 155, '116|155|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(280, '露得清', '', 155, '116|155|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(281, '染发膏', '', 157, '116|157|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(282, '蓬蓬粉', '', 157, '116|157|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(283, '发膜', '', 157, '116|157|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(284, '弹力素', '', 157, '116|157|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(285, '发蜡', '', 157, '116|157|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(286, '假发', '', 157, '116|157|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(287, '护手霜', '', 157, '116|157|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(288, '身体乳', '', 157, '116|157|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(289, '美颈霜', '', 157, '116|157|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(290, '沐浴露', '', 157, '116|157|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(291, '手工皂', '', 157, '116|157|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(292, '眼线膏', '', 159, '116|159|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(293, '唇彩', '', 159, '116|159|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(294, '眉笔', '', 159, '116|159|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(295, '眼影', '', 159, '116|159|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(296, '腮红', '', 159, '116|159|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(297, '口红', '', 159, '116|159|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(298, '蜜粉', '', 159, '116|159|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(299, '粉饼', '', 159, '116|159|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(300, 'BB霜', '', 159, '116|159|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(301, '睫毛膏', '', 159, '116|159|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(302, '指甲油', '', 159, '116|159|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(303, '香水', '', 159, '116|159|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(304, '药妆', '', 162, '116|162|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(305, '吸油面纸', '', 162, '116|162|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(306, '隔离霜', '', 162, '116|162|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(307, '精油', '', 162, '116|162|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(308, '爽肤水', '', 162, '116|162|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(309, '眼霜', '', 162, '116|162|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(310, '面膜', '', 162, '116|162|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(311, '洗面奶', '', 162, '116|162|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(312, '卸妆油', '', 162, '116|162|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(313, '喷雾', '', 162, '116|162|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(314, '防晒霜', '', 162, '116|162|', '', '', '', 0, 0, 0, 0, 255, 1, 0, 0, '', '', ''),
(320, '粉色', '', 315, '1|315|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(321, '紫色', '', 315, '1|315|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(322, '白色', '', 315, '1|315|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(323, '蓝色', '', 315, '1|315|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(324, '颜色', '', 102, '102|', '', '', '', 0, 0, 0, 1, 5, 1, 0, 0, '', '', ''),
(325, '红色', '', 324, '102|324|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(326, '黑色', '', 324, '102|324|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(327, '蓝色', '', 324, '102|324|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(328, '绿色', '', 324, '102|324|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(329, '紫色', '', 324, '102|324|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(330, '白色', '', 324, '102|324|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(331, '粉色', '', 324, '102|324|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(332, '黄色', '', 324, '102|324|', '', '', '', 0, 0, 0, 1, 255, 1, 0, 0, '', '', ''),
(333, '蔬果', '', 0, '0', '', '', '', 0, 0, 0, 0, 255, 1, 1, 0, '蔬果', '蔬果', '蔬果');

-- --------------------------------------------------------

--
-- 表的结构 `pin_item_cate_tag`
--

CREATE TABLE IF NOT EXISTS `pin_item_cate_tag` (
  `cate_id` smallint(4) unsigned NOT NULL,
  `tag_id` int(10) unsigned NOT NULL,
  `weight` tinyint(3) unsigned NOT NULL DEFAULT '0',
  UNIQUE KEY `cate_id` (`cate_id`,`tag_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `pin_item_cate_tag`
--

INSERT INTO `pin_item_cate_tag` (`cate_id`, `tag_id`, `weight`) VALUES
(3, 1, 0),
(4, 2, 0),
(5, 3, 0),
(6, 4, 0),
(7, 5, 0),
(8, 6, 0),
(9, 7, 0),
(10, 8, 0),
(11, 9, 0),
(12, 10, 0),
(17, 11, 0),
(18, 12, 0),
(21, 13, 0),
(23, 14, 0),
(22, 15, 0),
(24, 16, 0),
(25, 17, 0),
(26, 18, 0),
(27, 19, 0),
(28, 20, 0),
(29, 21, 0),
(30, 22, 0),
(32, 23, 0),
(33, 24, 0),
(34, 25, 0),
(35, 26, 0),
(36, 27, 0),
(37, 28, 0),
(38, 29, 0),
(39, 30, 0),
(41, 31, 0),
(42, 32, 0),
(43, 33, 0),
(44, 34, 0),
(45, 35, 0),
(46, 14, 0),
(47, 36, 0),
(48, 37, 0),
(49, 38, 0),
(319, 39, 0),
(318, 40, 0),
(317, 41, 0),
(316, 42, 0),
(320, 43, 0),
(321, 44, 0),
(322, 45, 0),
(323, 46, 0),
(91, 96, 0),
(92, 97, 0),
(93, 98, 0),
(94, 99, 0),
(281, 100, 0),
(95, 101, 0),
(282, 102, 0),
(283, 103, 0),
(96, 104, 0),
(284, 105, 0),
(97, 106, 0),
(285, 107, 0),
(98, 108, 0),
(99, 109, 0),
(286, 110, 0),
(100, 111, 0),
(287, 112, 0),
(101, 113, 0),
(288, 114, 0),
(289, 115, 0),
(290, 116, 0),
(291, 117, 0),
(292, 118, 0),
(293, 119, 0),
(294, 120, 0),
(295, 121, 0),
(296, 122, 0),
(297, 123, 0),
(298, 124, 0),
(299, 125, 0),
(300, 126, 0),
(301, 127, 0),
(302, 128, 0),
(303, 129, 0),
(304, 130, 0),
(305, 131, 0),
(306, 132, 0),
(307, 133, 0),
(308, 134, 0),
(309, 135, 0),
(310, 136, 0),
(219, 137, 0),
(311, 138, 0),
(312, 139, 0),
(313, 140, 0),
(314, 141, 0),
(260, 142, 0),
(261, 143, 0),
(262, 144, 0),
(263, 145, 0),
(264, 146, 0),
(265, 147, 0),
(266, 148, 0),
(267, 149, 0),
(268, 150, 0),
(269, 151, 0),
(270, 152, 0),
(271, 153, 0),
(272, 154, 0),
(273, 155, 0),
(274, 156, 0),
(275, 157, 0),
(276, 158, 0),
(277, 159, 0),
(278, 160, 0),
(279, 161, 0),
(280, 162, 0),
(237, 163, 0),
(238, 164, 0),
(239, 165, 0),
(240, 166, 0),
(241, 167, 0),
(242, 168, 0),
(243, 169, 0),
(244, 170, 0),
(245, 171, 0),
(246, 172, 0),
(247, 173, 0),
(248, 174, 0),
(249, 175, 0),
(250, 176, 0),
(251, 177, 0),
(206, 178, 0),
(207, 179, 0),
(208, 180, 0),
(209, 181, 0),
(210, 182, 0),
(211, 183, 0),
(212, 184, 0),
(213, 185, 0),
(214, 186, 0),
(215, 187, 0),
(216, 188, 0),
(217, 189, 0),
(218, 190, 0),
(220, 191, 0),
(221, 192, 0),
(222, 193, 0),
(223, 194, 0),
(224, 195, 0),
(225, 196, 0),
(226, 196, 0),
(226, 137, 0),
(227, 197, 0),
(228, 198, 0),
(229, 199, 0),
(230, 200, 0),
(231, 201, 0),
(232, 202, 0),
(233, 203, 0),
(234, 204, 0),
(236, 205, 0),
(235, 206, 0),
(252, 207, 0),
(253, 208, 0),
(254, 209, 0),
(255, 210, 0),
(256, 211, 0),
(257, 212, 0),
(258, 213, 0),
(259, 214, 0),
(178, 215, 0),
(179, 216, 0),
(180, 267, 0),
(181, 268, 0),
(182, 269, 0),
(183, 270, 0),
(184, 271, 0),
(185, 289, 0),
(186, 290, 0),
(187, 291, 0),
(188, 292, 0),
(189, 293, 0),
(190, 294, 0),
(191, 295, 0),
(192, 296, 0),
(193, 297, 0),
(194, 330, 0),
(195, 336, 0),
(196, 337, 0),
(197, 338, 0),
(198, 339, 0),
(199, 340, 0),
(200, 341, 0),
(201, 342, 0),
(202, 343, 0),
(203, 344, 0),
(204, 345, 0),
(205, 346, 0),
(170, 347, 0),
(171, 25, 0),
(172, 26, 0),
(173, 30, 0),
(174, 348, 0),
(175, 27, 0),
(176, 349, 0),
(177, 259, 0),
(177, 28, 0),
(163, 350, 0),
(164, 351, 0),
(165, 352, 0),
(166, 353, 0),
(167, 354, 0),
(168, 355, 0),
(169, 314, 0),
(127, 356, 0),
(128, 357, 0),
(130, 358, 0),
(132, 359, 0),
(81, 360, 0),
(82, 301, 0),
(83, 323, 0),
(84, 361, 0),
(85, 300, 0),
(86, 318, 0),
(87, 362, 0),
(88, 332, 0),
(89, 192, 0),
(74, 363, 0),
(75, 364, 0),
(76, 365, 0),
(77, 366, 0),
(78, 367, 0),
(79, 368, 0),
(61, 97, 0),
(61, 369, 0),
(62, 370, 0),
(63, 371, 0),
(64, 372, 0),
(316, 373, 0),
(316, 374, 0),
(316, 375, 0),
(65, 376, 0),
(65, 377, 0),
(66, 378, 0),
(67, 379, 0),
(68, 380, 0),
(69, 381, 0),
(70, 382, 0),
(71, 308, 0),
(72, 383, 0),
(52, 384, 0),
(53, 349, 0),
(54, 385, 0),
(55, 28, 0),
(56, 27, 0),
(57, 386, 0),
(58, 25, 0),
(59, 30, 0),
(133, 387, 0),
(135, 388, 0),
(137, 389, 0),
(139, 390, 0),
(140, 246, 0),
(141, 391, 0),
(143, 392, 0),
(145, 241, 0),
(148, 393, 0),
(150, 394, 0),
(151, 259, 0),
(152, 395, 0),
(154, 237, 0),
(156, 238, 0),
(158, 396, 0),
(160, 397, 0),
(161, 218, 0),
(113, 398, 0),
(117, 371, 0),
(118, 372, 0),
(119, 399, 0),
(119, 400, 0),
(120, 27, 0),
(121, 28, 0),
(122, 401, 0),
(123, 233, 0),
(104, 220, 0),
(105, 402, 0),
(106, 403, 0),
(107, 404, 0),
(108, 405, 0),
(109, 406, 0),
(110, 302, 0),
(111, 223, 0),
(325, 42, 0),
(325, 374, 0),
(325, 375, 0),
(326, 39, 0),
(326, 407, 0),
(327, 46, 0),
(327, 408, 0),
(327, 409, 0),
(327, 410, 0),
(327, 411, 0),
(328, 41, 0),
(328, 412, 0),
(328, 413, 0),
(328, 414, 0),
(329, 44, 0),
(329, 415, 0),
(330, 45, 0),
(330, 416, 0),
(331, 43, 0),
(331, 373, 0),
(332, 40, 0),
(332, 417, 0),
(332, 418, 0);

-- --------------------------------------------------------

--
-- 表的结构 `pin_item_comment`
--

CREATE TABLE IF NOT EXISTS `pin_item_comment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `item_id` int(10) unsigned NOT NULL,
  `uid` int(10) unsigned NOT NULL,
  `uname` varchar(20) NOT NULL,
  `info` text NOT NULL,
  `add_time` int(10) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `pin_item_img`
--

CREATE TABLE IF NOT EXISTS `pin_item_img` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL,
  `url` varchar(255) NOT NULL,
  `add_time` int(10) NOT NULL DEFAULT '0',
  `ordid` tinyint(3) unsigned NOT NULL DEFAULT '255',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=296 ;

--
-- 转存表中的数据 `pin_item_img`
--

INSERT INTO `pin_item_img` (`id`, `item_id`, `url`, `add_time`, `ordid`, `status`) VALUES
(1, 1, 'http://img03.taobaocdn.com/bao/uploaded/i3/T1o2R8XdRtXXcjNLgV_020417.jpg', 1353896347, 0, 1),
(2, 1, 'http://img02.taobaocdn.com/bao/uploaded/i2/708668350/T2NGFRXd0XXXXXXXXX_!!708668350.jpg', 1353896347, 1, 1),
(3, 1, 'http://img04.taobaocdn.com/bao/uploaded/i4/708668350/T2.GFRXcJXXXXXXXXX_!!708668350.jpg', 1353896347, 2, 1),
(4, 1, 'http://img02.taobaocdn.com/bao/uploaded/i2/708668350/T2dGJRXcpXXXXXXXXX_!!708668350.jpg', 1353896347, 3, 1),
(5, 1, 'http://img02.taobaocdn.com/bao/uploaded/i2/708668350/T2YGFRXdlXXXXXXXXX_!!708668350.jpg', 1353896347, 4, 1),
(6, 2, 'http://img03.taobaocdn.com/bao/uploaded/i3/T1L.urXiFJXXa2x2w2_043755.jpg', 1353896347, 0, 1),
(7, 2, 'http://img01.taobaocdn.com/bao/uploaded/i1/708668350/T2Vi02XfdbXXXXXXXX_!!708668350.jpg', 1353896347, 1, 1),
(8, 2, 'http://img01.taobaocdn.com/bao/uploaded/i1/708668350/T22502XeVbXXXXXXXX_!!708668350.jpg', 1353896347, 2, 1),
(9, 2, 'http://img02.taobaocdn.com/bao/uploaded/i2/708668350/T25502XeNbXXXXXXXX_!!708668350.jpg', 1353896347, 3, 1),
(10, 2, 'http://img01.taobaocdn.com/bao/uploaded/i1/708668350/T2a542XetbXXXXXXXX_!!708668350.jpg', 1353896347, 4, 1),
(11, 3, 'http://img01.taobaocdn.com/bao/uploaded/i1/T1FGLNXmJbXXbjSLvb_093718.jpg', 1353896347, 0, 1),
(12, 3, 'http://img03.taobaocdn.com/bao/uploaded/i3/708668350/T2pV88XapcXXXXXXXX_!!708668350.jpg', 1353896347, 1, 1),
(13, 3, 'http://img02.taobaocdn.com/bao/uploaded/i2/708668350/T2oFGMXb0XXXXXXXXX_!!708668350.jpg', 1353896347, 2, 1),
(14, 3, 'http://img02.taobaocdn.com/bao/uploaded/i2/708668350/T2IaidXXpcXXXXXXXX_!!708668350.jpg', 1353896347, 3, 1),
(15, 3, 'http://img03.taobaocdn.com/bao/uploaded/i3/708668350/T2lmh7XhFcXXXXXXXX_!!708668350.jpg', 1353896347, 4, 1),
(16, 4, 'http://img02.taobaocdn.com/bao/uploaded/i2/T1Fw5FXmxmXXc2RowZ_034012.jpg', 1353896347, 0, 1),
(17, 4, 'http://img04.taobaocdn.com/bao/uploaded/i4/708668350/T235WdXXlXXXXXXXXX_!!708668350.jpg', 1353896347, 1, 1),
(18, 4, 'http://img03.taobaocdn.com/bao/uploaded/i3/708668350/T2xMSdXnhaXXXXXXXX_!!708668350.jpg', 1353896347, 2, 1),
(19, 4, 'http://img04.taobaocdn.com/bao/uploaded/i4/708668350/T2nN1dXgRaXXXXXXXX_!!708668350.jpg', 1353896347, 3, 1),
(20, 4, 'http://img01.taobaocdn.com/bao/uploaded/i1/708668350/T2diadXcNaXXXXXXXX_!!708668350.jpg', 1353896347, 4, 1),
(21, 5, 'http://img04.taobaocdn.com/bao/uploaded/i4/T1tmvLXnhmXXXxzzQW_024228.jpg', 1353896347, 0, 1),
(22, 5, 'http://img04.taobaocdn.com/bao/uploaded/i4/708668350/T2XGqNXbJaXXXXXXXX_!!708668350.jpg', 1353896347, 1, 1),
(23, 5, 'http://img01.taobaocdn.com/bao/uploaded/i1/T1zHfLXndbXXbxB.kS_010346.jpg', 1353896347, 2, 1),
(24, 5, 'http://img04.taobaocdn.com/bao/uploaded/i4/708668350/T2DROXXeNcXXXXXXXX_!!708668350.jpg', 1353896347, 3, 1),
(25, 5, 'http://img01.taobaocdn.com/bao/uploaded/i1/708668350/T2LLKLXcxXXXXXXXXX_!!708668350.jpg', 1353896347, 4, 1),
(26, 6, 'http://img01.taobaocdn.com/bao/uploaded/i1/T1dmCzXaxgXXcNQv71_040909.jpg', 1353896348, 0, 1),
(27, 6, 'http://img02.taobaocdn.com/bao/uploaded/i2/708668350/T2zTN_XXpaXXXXXXXX_!!708668350.jpg', 1353896348, 1, 1),
(28, 6, 'http://img01.taobaocdn.com/bao/uploaded/i1/708668350/T2enV_XXpaXXXXXXXX_!!708668350.jpg', 1353896348, 2, 1),
(29, 6, 'http://img03.taobaocdn.com/bao/uploaded/i3/708668350/T2gnV_XXlaXXXXXXXX_!!708668350.jpg', 1353896348, 3, 1),
(30, 6, 'http://img03.taobaocdn.com/bao/uploaded/i3/708668350/T2hnV_XXhaXXXXXXXX_!!708668350.jpg', 1353896348, 4, 1),
(31, 7, 'http://img01.taobaocdn.com/bao/uploaded/i1/T1yhLQXnVqXXXEh_71_042519.jpg', 1353896348, 0, 1),
(32, 7, 'http://img04.taobaocdn.com/bao/uploaded/i4/708668350/T22wd7XgJdXXXXXXXX_!!708668350.jpg', 1353896348, 1, 1),
(33, 7, 'http://img02.taobaocdn.com/bao/uploaded/i2/708668350/T2UlyHXndbXXXXXXXX_!!708668350.jpg', 1353896348, 2, 1),
(34, 7, 'http://img01.taobaocdn.com/bao/uploaded/i1/708668350/T2imydXXxcXXXXXXXX_!!708668350.jpg', 1353896348, 3, 1),
(35, 7, 'http://img03.taobaocdn.com/bao/uploaded/i3/708668350/T2VvaVXkNXXXXXXXXX_!!708668350.jpg', 1353896348, 4, 1),
(36, 8, 'http://img03.taobaocdn.com/bao/uploaded/i3/T1ssGRXeVoXXXa7CQ5_060120.jpg', 1353896348, 0, 1),
(37, 8, 'http://img03.taobaocdn.com/bao/uploaded/i3/411678707/T2N_9lXkFXXXXXXXXX_!!411678707.jpg', 1353896348, 1, 1),
(38, 8, 'http://img01.taobaocdn.com/bao/uploaded/i1/411678707/T24EalXm4XXXXXXXXX_!!411678707.jpg', 1353896348, 2, 1),
(39, 8, 'http://img04.taobaocdn.com/bao/uploaded/i4/411678707/T2nEilXldXXXXXXXXX_!!411678707.jpg', 1353896348, 3, 1),
(40, 8, 'http://img02.taobaocdn.com/bao/uploaded/i2/411678707/T2IomlXjpXXXXXXXXX_!!411678707.jpg', 1353896348, 4, 1),
(41, 9, 'http://img01.taobaocdn.com/bao/uploaded/i1/T1hP1mXjRrXXcK2PU3_050554.jpg', 1353896348, 0, 1),
(42, 9, 'http://img04.taobaocdn.com/bao/uploaded/i4/708668350/T2mANVXktXXXXXXXXX_!!708668350.jpg', 1353896348, 1, 1),
(43, 9, 'http://img02.taobaocdn.com/bao/uploaded/i2/708668350/T2CANVXjRXXXXXXXXX_!!708668350.jpg', 1353896348, 2, 1),
(44, 9, 'http://img01.taobaocdn.com/bao/uploaded/i1/708668350/T2JQNVXjxXXXXXXXXX_!!708668350.jpg', 1353896348, 3, 1),
(45, 9, 'http://img02.taobaocdn.com/bao/uploaded/i2/708668350/T2tkNVXkhXXXXXXXXX_!!708668350.jpg', 1353896348, 4, 1),
(46, 10, 'http://img01.taobaocdn.com/bao/uploaded/i1/T1As6HXiBmXXcXtaPb_093121.jpg', 1353896348, 0, 1),
(47, 10, 'http://img04.taobaocdn.com/bao/uploaded/i4/708668350/T2nCV1XfldXXXXXXXX_!!708668350.jpg', 1353896348, 1, 1),
(48, 10, 'http://img04.taobaocdn.com/bao/uploaded/i4/708668350/T2w5yzXjFbXXXXXXXX_!!708668350.jpg', 1353896348, 2, 1),
(49, 10, 'http://img02.taobaocdn.com/bao/uploaded/i2/708668350/T2oGSKXmdXXXXXXXXX_!!708668350.jpg', 1353896348, 3, 1),
(50, 10, 'http://img03.taobaocdn.com/bao/uploaded/i3/708668350/T2lVGAXelbXXXXXXXX_!!708668350.jpg', 1353896348, 4, 1),
(51, 11, 'http://img01.taobaocdn.com/bao/uploaded/i1/T1_fvTXbdjXXc3i8E1_042214.jpg', 1353896348, 0, 1),
(52, 11, 'http://img03.taobaocdn.com/bao/uploaded/i3/708668350/T2t7OSXcFaXXXXXXXX_!!708668350.jpg', 1353896348, 1, 1),
(53, 11, 'http://img02.taobaocdn.com/bao/uploaded/i2/T1SuYPXmJiXXXyyFZ2_043048.jpg', 1353896348, 2, 1),
(54, 11, 'http://img01.taobaocdn.com/bao/uploaded/i1/708668350/T2ILWQXaNXXXXXXXXX_!!708668350.jpg', 1353896348, 3, 1),
(55, 11, 'http://img02.taobaocdn.com/bao/uploaded/i2/708668350/T2VaWQXcBaXXXXXXXX_!!708668350.jpg', 1353896348, 4, 1),
(56, 12, 'http://img04.taobaocdn.com/bao/uploaded/i4/T1vdvYXktiXXb1Opc__104853.jpg', 1353896348, 0, 1),
(57, 12, 'http://img02.taobaocdn.com/bao/uploaded/i2/708668350/T22U0sXaBOXXXXXXXX_!!708668350.jpg', 1353896348, 1, 1),
(58, 12, 'http://img04.taobaocdn.com/bao/uploaded/i4/708668350/T2Ug8iXe8OXXXXXXXX_!!708668350.jpg', 1353896348, 2, 1),
(59, 12, 'http://img04.taobaocdn.com/bao/uploaded/i4/708668350/T2F.eUXbtaXXXXXXXX_!!708668350.jpg', 1353896348, 3, 1),
(60, 12, 'http://img01.taobaocdn.com/bao/uploaded/i1/708668350/T2I6ykXoBbXXXXXXXX_!!708668350.jpg', 1353896348, 4, 1),
(61, 13, 'http://img02.taobaocdn.com/bao/uploaded/i2/T1h4F7XbdAXXce_eEZ_032143.jpg', 1353896348, 0, 1),
(62, 13, 'http://img01.taobaocdn.com/bao/uploaded/i1/708668350/T2W3BQXkVaXXXXXXXX_!!708668350.jpg', 1353896348, 1, 1),
(63, 13, 'http://img02.taobaocdn.com/bao/uploaded/i2/708668350/T22wBQXkFaXXXXXXXX_!!708668350.jpg', 1353896348, 2, 1),
(64, 13, 'http://img02.taobaocdn.com/bao/uploaded/i2/708668350/T2p3FQXjhaXXXXXXXX_!!708668350.jpg', 1353896348, 3, 1),
(65, 13, 'http://img03.taobaocdn.com/bao/uploaded/i3/708668350/T2L3pQXiVaXXXXXXXX_!!708668350.jpg', 1353896348, 4, 1),
(66, 14, 'http://img04.taobaocdn.com/bao/uploaded/i4/T1qdnCXlBhXXbCT873_051140.jpg', 1353896349, 0, 1),
(67, 14, 'http://img03.taobaocdn.com/bao/uploaded/i3/708668350/T2T0hLXhFcXXXXXXXX_!!708668350.jpg', 1353896349, 1, 1),
(68, 14, 'http://img03.taobaocdn.com/bao/uploaded/i3/708668350/T2tXp4XlpcXXXXXXXX_!!708668350.jpg', 1353896349, 2, 1),
(69, 14, 'http://img03.taobaocdn.com/bao/uploaded/i3/708668350/T2qvSDXfNbXXXXXXXX_!!708668350.jpg', 1353896349, 3, 1),
(70, 14, 'http://img03.taobaocdn.com/bao/uploaded/i3/708668350/T2qNywXdXbXXXXXXXX_!!708668350.jpg', 1353896349, 4, 1),
(71, 15, 'http://img01.taobaocdn.com/bao/uploaded/i1/T1QEO7XcBdXXXWXn.U_015911.jpg', 1353896349, 0, 1),
(72, 15, 'http://img02.taobaocdn.com/bao/uploaded/i2/708668350/T2TvWCXc8XXXXXXXXX_!!708668350.jpg', 1353896349, 1, 1),
(73, 15, 'http://img02.taobaocdn.com/bao/uploaded/i2/708668350/T29oWtXidXXXXXXXXX_!!708668350.jpg', 1353896349, 2, 1),
(74, 15, 'http://img04.taobaocdn.com/bao/uploaded/i4/708668350/T2eFauXdtXXXXXXXXX_!!708668350.jpg', 1353896349, 3, 1),
(75, 15, 'http://img03.taobaocdn.com/bao/uploaded/i3/708668350/T2cDStXbtbXXXXXXXX_!!708668350.jpg', 1353896349, 4, 1),
(76, 16, 'http://img02.taobaocdn.com/bao/uploaded/i2/T1DReVXjtbXXcISRE9_104415.jpg', 1353896349, 0, 1),
(77, 16, 'http://img02.taobaocdn.com/bao/uploaded/i2/708668350/T2TdaqXdNXXXXXXXXX_!!708668350.jpg', 1353896349, 1, 1),
(78, 16, 'http://img03.taobaocdn.com/bao/uploaded/i3/708668350/T2g95oXiFaXXXXXXXX_!!708668350.jpg', 1353896349, 2, 1),
(79, 16, 'http://img01.taobaocdn.com/bao/uploaded/i1/708668350/T2bneoXeBaXXXXXXXX_!!708668350.jpg', 1353896349, 3, 1),
(80, 16, 'http://img04.taobaocdn.com/bao/uploaded/i4/708668350/T2bDqoXaBaXXXXXXXX_!!708668350.jpg', 1353896349, 4, 1),
(81, 17, 'http://img03.taobaocdn.com/bao/uploaded/i3/T1Xo6dXhptXXb5KSA9_104530.jpg', 1353896349, 0, 1),
(82, 17, 'http://img02.taobaocdn.com/bao/uploaded/i2/708668350/T2EIpZXc4dXXXXXXXX_!!708668350.jpg', 1353896349, 1, 1),
(83, 17, 'http://img03.taobaocdn.com/bao/uploaded/i3/708668350/T2WDWoXaJXXXXXXXXX_!!708668350.jpg', 1353896349, 2, 1),
(84, 17, 'http://img03.taobaocdn.com/bao/uploaded/i3/708668350/T2b9CoXopaXXXXXXXX_!!708668350.jpg', 1353896349, 3, 1),
(85, 17, 'http://img03.taobaocdn.com/bao/uploaded/i3/708668350/T24mOoXi4aXXXXXXXX_!!708668350.jpg', 1353896349, 4, 1),
(86, 18, 'http://img03.taobaocdn.com/bao/uploaded/i3/T1ms_UXi0bXXb4juQ1_041036.jpg', 1353896349, 0, 1),
(87, 18, 'http://img02.taobaocdn.com/bao/uploaded/i2/708668350/T2LzKSXfxaXXXXXXXX_!!708668350.jpg', 1353896349, 1, 1),
(88, 18, 'http://img04.taobaocdn.com/bao/uploaded/i4/708668350/T2AfeTXjpXXXXXXXXX_!!708668350.jpg', 1353896349, 2, 1),
(89, 18, 'http://img02.taobaocdn.com/bao/uploaded/i2/708668350/T21.SSXcRXXXXXXXXX_!!708668350.jpg', 1353896349, 3, 1),
(90, 18, 'http://img04.taobaocdn.com/bao/uploaded/i4/708668350/T2RMOSXixaXXXXXXXX_!!708668350.jpg', 1353896349, 4, 1),
(91, 19, 'http://img02.taobaocdn.com/bao/uploaded/i2/T1V_KxXkXuXXX2Qls4_053710.jpg', 1353896349, 0, 1),
(92, 19, 'http://img02.taobaocdn.com/bao/uploaded/i2/708668350/T21vh9XbNXXXXXXXXX_!!708668350.jpg', 1353896349, 1, 1),
(93, 19, 'http://img03.taobaocdn.com/bao/uploaded/i3/708668350/T252h9XbFXXXXXXXXX_!!708668350.jpg', 1353896349, 2, 1),
(94, 19, 'http://img04.taobaocdn.com/bao/uploaded/i4/708668350/T2Xvl9XbxXXXXXXXXX_!!708668350.jpg', 1353896349, 3, 1),
(95, 19, 'http://img02.taobaocdn.com/bao/uploaded/i2/708668350/T2cLl9XbpXXXXXXXXX_!!708668350.jpg', 1353896349, 4, 1),
(96, 20, 'http://img01.taobaocdn.com/bao/uploaded/i1/T1vN18Xe8wXXabtx7U_014829.jpg', 1353896349, 0, 1),
(97, 20, 'http://img02.taobaocdn.com/bao/uploaded/i2/708668350/T2nzBwXcBNXXXXXXXX_!!708668350.jpg', 1353896349, 1, 1),
(98, 20, 'http://img01.taobaocdn.com/bao/uploaded/i1/708668350/T2nHGeXjFbXXXXXXXX_!!708668350.jpg', 1353896349, 2, 1),
(99, 20, 'http://img02.taobaocdn.com/bao/uploaded/i2/708668350/T2t4qDXk0XXXXXXXXX_!!708668350.jpg', 1353896349, 3, 1),
(100, 20, 'http://img03.taobaocdn.com/bao/uploaded/i3/708668350/T2_VBaXlFNXXXXXXXX_!!708668350.jpg', 1353896349, 4, 1),
(101, 21, 'http://img04.taobaocdn.com/bao/uploaded/i4/T1oAbZXkldXXcH5ug2_043616.jpg', 1353902316, 0, 1),
(102, 21, 'http://img02.taobaocdn.com/bao/uploaded/i2/832772565/T25jaXXjRcXXXXXXXX_!!832772565.jpg', 1353902316, 1, 1),
(103, 21, 'http://img03.taobaocdn.com/bao/uploaded/i3/832772565/T2.TaFXi4bXXXXXXXX_!!832772565.jpg', 1353902316, 2, 1),
(104, 21, 'http://img02.taobaocdn.com/bao/uploaded/i2/832772565/T2AEuWXhJaXXXXXXXX_!!832772565.jpg', 1353902316, 3, 1),
(105, 21, 'http://img04.taobaocdn.com/bao/uploaded/i4/832772565/T2HEWZXmBXXXXXXXXX_!!832772565.jpg', 1353902316, 4, 1),
(106, 22, 'http://img02.taobaocdn.com/bao/uploaded/i2/T1qrdqXXlwXXa_4U38_101909.jpg', 1353902316, 0, 1),
(107, 22, 'http://img01.taobaocdn.com/bao/uploaded/i1/T1ixD0Xm4jXXbLm8Lb_095114.jpg', 1353902316, 1, 1),
(108, 22, 'http://img04.taobaocdn.com/bao/uploaded/i4/832772565/T2jaCwXbdcXXXXXXXX_!!832772565.jpg', 1353902316, 2, 1),
(109, 22, 'http://img02.taobaocdn.com/bao/uploaded/i2/832772565/T2cqWPXkFXXXXXXXXX_!!832772565.jpg', 1353902316, 3, 1),
(110, 22, 'http://img01.taobaocdn.com/bao/uploaded/i1/832772565/T2mjyjXcBcXXXXXXXX_!!832772565.jpg', 1353902316, 4, 1),
(111, 23, 'http://img03.taobaocdn.com/bao/uploaded/i3/T1yj1xXg01XXX_.NQ8_100702.jpg', 1353902316, 0, 1),
(112, 23, 'http://img04.taobaocdn.com/bao/uploaded/i4/832772565/T2jd9dXdBcXXXXXXXX_!!832772565.jpg', 1353902316, 1, 1),
(113, 23, 'http://img04.taobaocdn.com/bao/uploaded/i4/832772565/T2V9GOXjNaXXXXXXXX_!!832772565.jpg', 1353902316, 2, 1),
(114, 23, 'http://img03.taobaocdn.com/bao/uploaded/i3/832772565/T23.uIXkVaXXXXXXXX_!!832772565.jpg', 1353902316, 3, 1),
(115, 23, 'http://img01.taobaocdn.com/bao/uploaded/i1/832772565/T21DiDXjtaXXXXXXXX_!!832772565.jpg', 1353902316, 4, 1),
(116, 24, 'http://img02.taobaocdn.com/bao/uploaded/i2/T1DsrnXbRkXXanw8_b_124847.jpg', 1353902316, 0, 1),
(117, 24, 'http://img02.taobaocdn.com/bao/uploaded/i2/832772565/T2SdVWXjtcXXXXXXXX_!!832772565.jpg', 1353902316, 1, 1),
(118, 24, 'http://img03.taobaocdn.com/bao/uploaded/i3/832772565/T2rL0TXi0cXXXXXXXX_!!832772565.jpg', 1353902316, 2, 1),
(119, 24, 'http://img02.taobaocdn.com/bao/uploaded/i2/832772565/T2wvB5XeNcXXXXXXXX_!!832772565.jpg', 1353902316, 3, 1),
(120, 24, 'http://img03.taobaocdn.com/bao/uploaded/i3/832772565/T20O0sXdNaXXXXXXXX_!!832772565.jpg', 1353902316, 4, 1),
(121, 25, 'http://img01.taobaocdn.com/bao/uploaded/i1/T18U_SXklkXXcPno7._084022.jpg', 1353902316, 0, 1),
(122, 25, 'http://img02.taobaocdn.com/bao/uploaded/i2/832772565/T2O6lyXmXNXXXXXXXX_!!832772565.jpg', 1353902316, 1, 1),
(123, 25, 'http://img02.taobaocdn.com/bao/uploaded/i2/832772565/T21t9rXe8cXXXXXXXX_!!832772565.jpg', 1353902316, 2, 1),
(124, 25, 'http://img01.taobaocdn.com/bao/uploaded/i1/832772565/T2J68HXhpNXXXXXXXX_!!832772565.jpg', 1353902316, 3, 1),
(125, 25, 'http://img01.taobaocdn.com/bao/uploaded/i1/832772565/T2glSKXcNbXXXXXXXX_!!832772565.jpg', 1353902316, 4, 1),
(126, 26, 'http://img04.taobaocdn.com/bao/uploaded/i4/T1_HC7XhlwXXbMVu7W_023330.jpg', 1353902316, 0, 1),
(127, 26, 'http://img01.taobaocdn.com/bao/uploaded/i1/832772565/T2ulR2XhddXXXXXXXX_!!832772565.jpg', 1353902316, 1, 1),
(128, 26, 'http://img01.taobaocdn.com/bao/uploaded/i1/832772565/T2YMyGXlxbXXXXXXXX_!!832772565.jpg', 1353902316, 2, 1),
(129, 26, 'http://img02.taobaocdn.com/bao/uploaded/i2/832772565/T2E3iLXiNaXXXXXXXX_!!832772565.jpg', 1353902316, 3, 1),
(130, 26, 'http://img01.taobaocdn.com/bao/uploaded/i1/832772565/T2y1aKXg4aXXXXXXXX_!!832772565.jpg', 1353902316, 4, 1),
(131, 27, 'http://img03.taobaocdn.com/bao/uploaded/i3/T1rnuWXbXwXXaT3dnb_093439.jpg', 1353902316, 0, 1),
(132, 27, 'http://img04.taobaocdn.com/bao/uploaded/i4/832772565/T2t45JXb8aXXXXXXXX_!!832772565.jpg', 1353902316, 1, 1),
(133, 27, 'http://img02.taobaocdn.com/bao/uploaded/i2/832772565/T2IiiJXhdXXXXXXXXX_!!832772565.jpg', 1353902316, 2, 1),
(134, 27, 'http://img02.taobaocdn.com/bao/uploaded/i2/832772565/T2A41JXetaXXXXXXXX_!!832772565.jpg', 1353902316, 3, 1),
(135, 27, 'http://img01.taobaocdn.com/bao/uploaded/i1/832772565/T2OOeJXj0XXXXXXXXX_!!832772565.jpg', 1353902316, 4, 1),
(136, 28, 'http://img01.taobaocdn.com/bao/uploaded/i1/T1sPfKXcxbXXXPQIYb_123402.jpg', 1353902317, 0, 1),
(137, 28, 'http://img01.taobaocdn.com/bao/uploaded/i1/832772565/T2ZgV2XaRdXXXXXXXX_!!832772565.jpg', 1353902317, 1, 1),
(138, 28, 'http://img01.taobaocdn.com/bao/uploaded/i1/832772565/T2axRRXiRdXXXXXXXX_!!832772565.jpg', 1353902317, 2, 1),
(139, 28, 'http://img02.taobaocdn.com/bao/uploaded/i2/832772565/T2GPyDXjxbXXXXXXXX_!!832772565.jpg', 1353902317, 3, 1),
(140, 28, 'http://img04.taobaocdn.com/bao/uploaded/i4/832772565/T265KKXjVXXXXXXXXX_!!832772565.jpg', 1353902317, 4, 1),
(141, 29, 'http://img04.taobaocdn.com/bao/uploaded/i4/T1gz6JXj8iXXblFxU8_100704.jpg', 1353902317, 0, 1),
(142, 29, 'http://img03.taobaocdn.com/bao/uploaded/i3/832772565/T28kCBXapXXXXXXXXX_!!832772565.jpg', 1353902317, 1, 1),
(143, 29, 'http://img04.taobaocdn.com/bao/uploaded/i4/832772565/T2rzSBXd0aXXXXXXXX_!!832772565.jpg', 1353902317, 2, 1),
(144, 29, 'http://img03.taobaocdn.com/bao/uploaded/i3/832772565/T2G6d7XcddXXXXXXXX_!!832772565.jpg', 1353902317, 3, 1),
(145, 29, 'http://img04.taobaocdn.com/bao/uploaded/i4/832772565/T2VjOBXeFaXXXXXXXX_!!832772565.jpg', 1353902317, 4, 1),
(146, 30, 'http://img02.taobaocdn.com/bao/uploaded/i2/T1m397XXJlXXaqnVg0_033805.jpg', 1353902317, 0, 1),
(147, 30, 'http://img04.taobaocdn.com/bao/uploaded/i4/832772565/T2pbtiXo8NXXXXXXXX_!!832772565.jpg', 1353902317, 1, 1),
(148, 30, 'http://img02.taobaocdn.com/bao/uploaded/i2/832772565/T20r8uXdBNXXXXXXXX_!!832772565.jpg', 1353902317, 2, 1),
(149, 30, 'http://img04.taobaocdn.com/bao/uploaded/i4/832772565/T2O3d2Xl0cXXXXXXXX_!!832772565.jpg', 1353902317, 3, 1),
(150, 30, 'http://img03.taobaocdn.com/bao/uploaded/i3/832772565/T2o_4TXiJdXXXXXXXX_!!832772565.jpg', 1353902317, 4, 1),
(151, 31, 'http://img02.taobaocdn.com/bao/uploaded/i2/T1X697XjXbXXcMnfM._112229.jpg', 1353902317, 0, 1),
(152, 31, 'http://img01.taobaocdn.com/bao/uploaded/i1/832772565/T2NuOCXXdbXXXXXXXX_!!832772565.jpg', 1353902317, 1, 1),
(153, 31, 'http://img04.taobaocdn.com/bao/uploaded/i4/832772565/T2gveCXfXaXXXXXXXX_!!832772565.jpg', 1353902317, 2, 1),
(154, 31, 'http://img02.taobaocdn.com/bao/uploaded/i2/832772565/T2AL1CXbtXXXXXXXXX_!!832772565.jpg', 1353902317, 3, 1),
(155, 31, 'http://img01.taobaocdn.com/bao/uploaded/i1/832772565/T2ye9CXhRaXXXXXXXX_!!832772565.jpg', 1353902317, 4, 1),
(156, 32, 'http://img04.taobaocdn.com/bao/uploaded/i4/T1DxC8Xi4eXXXO8ZZ5_054947.jpg', 1353902317, 0, 1),
(157, 32, 'http://img02.taobaocdn.com/bao/uploaded/i2/832772565/T2Vx1DXnlaXXXXXXXX_!!832772565.jpg', 1353902317, 1, 1),
(158, 32, 'http://img04.taobaocdn.com/bao/uploaded/i4/832772565/T2TQ8jXixNXXXXXXXX_!!832772565.jpg', 1353902317, 2, 1),
(159, 32, 'http://img01.taobaocdn.com/bao/uploaded/i1/832772565/T26p9jXedXXXXXXXXX_!!832772565.jpg', 1353902317, 3, 1),
(160, 32, 'http://img02.taobaocdn.com/bao/uploaded/i2/832772565/T2.XaJXclXXXXXXXXX_!!832772565.jpg', 1353902317, 4, 1),
(161, 33, 'http://img04.taobaocdn.com/bao/uploaded/i4/T1wBy7XflaXXX6UvwV_020442.jpg', 1353902317, 0, 1),
(162, 33, 'http://img04.taobaocdn.com/bao/uploaded/i4/832772565/T2GVuCXntaXXXXXXXX_!!832772565.jpg', 1353902317, 1, 1),
(163, 33, 'http://img01.taobaocdn.com/bao/uploaded/i1/832772565/T2xaaCXm8XXXXXXXXX_!!832772565.jpg', 1353902317, 2, 1),
(164, 33, 'http://img01.taobaocdn.com/bao/uploaded/i1/832772565/T2cGyCXdRXXXXXXXXX_!!832772565.jpg', 1353902317, 3, 1),
(165, 33, 'http://img01.taobaocdn.com/bao/uploaded/i1/832772565/T2DYGBXoRaXXXXXXXX_!!832772565.jpg', 1353902317, 4, 1),
(166, 34, 'http://img01.taobaocdn.com/bao/uploaded/i1/T1tWOuXmFTXXXbvKDb_093608.jpg', 1353902317, 0, 1),
(167, 34, 'http://img02.taobaocdn.com/bao/uploaded/i2/832772565/T2jx5DXgBaXXXXXXXX_!!832772565.jpg', 1353902317, 1, 1),
(168, 34, 'http://img03.taobaocdn.com/bao/uploaded/i3/832772565/T2YzeIXklXXXXXXXXX_!!832772565.jpg', 1353902317, 2, 1),
(169, 34, 'http://img04.taobaocdn.com/bao/uploaded/i4/832772565/T2Z6xvXmBMXXXXXXXX_!!832772565.jpg', 1353902317, 3, 1),
(170, 34, 'http://img01.taobaocdn.com/bao/uploaded/i1/832772565/T2eo5IXd0aXXXXXXXX_!!832772565.jpg', 1353902317, 4, 1),
(171, 35, 'http://img01.taobaocdn.com/bao/uploaded/i1/T1xtK1XnlkXXaGp4E6_062100.jpg', 1353902318, 0, 1),
(172, 35, 'http://img02.taobaocdn.com/bao/uploaded/i2/832772565/T23kdrXeJNXXXXXXXX_!!832772565.jpg', 1353902318, 1, 1),
(173, 35, 'http://img04.taobaocdn.com/bao/uploaded/i4/832772565/T2VqGjXX4aXXXXXXXX_!!832772565.jpg', 1353902318, 2, 1),
(174, 35, 'http://img04.taobaocdn.com/bao/uploaded/i4/832772565/T2bvVqXetNXXXXXXXX_!!832772565.jpg', 1353902318, 3, 1),
(175, 35, 'http://img02.taobaocdn.com/bao/uploaded/i2/832772565/T2g.NcXadNXXXXXXXX_!!832772565.jpg', 1353902318, 4, 1),
(176, 36, 'http://img02.taobaocdn.com/bao/uploaded/i2/T1Ad58XctiXXcyC0s8_100130.jpg', 1353902318, 0, 1),
(177, 36, 'http://img02.taobaocdn.com/bao/uploaded/i2/832772565/T2n61tXXxcXXXXXXXX_!!832772565.jpg', 1353902318, 1, 1),
(178, 36, 'http://img02.taobaocdn.com/bao/uploaded/i2/832772565/T2YBeLXc0aXXXXXXXX_!!832772565.jpg', 1353902318, 2, 1),
(179, 36, 'http://img01.taobaocdn.com/bao/uploaded/i1/832772565/T2ZhyAXeNbXXXXXXXX_!!832772565.jpg', 1353902318, 3, 1),
(180, 36, 'http://img02.taobaocdn.com/bao/uploaded/i2/832772565/T2MHWMXapXXXXXXXXX_!!832772565.jpg', 1353902318, 4, 1),
(181, 37, 'http://img02.taobaocdn.com/bao/uploaded/i2/T1O9mQXndwXXXD_O.0_035651.jpg', 1353902318, 0, 1),
(182, 37, 'http://img04.taobaocdn.com/bao/uploaded/i4/832772565/T2vaiJXntaXXXXXXXX_!!832772565.jpg', 1353902318, 1, 1),
(183, 37, 'http://img03.taobaocdn.com/bao/uploaded/i3/832772565/T2oWGJXkxXXXXXXXXX_!!832772565.jpg', 1353902318, 2, 1),
(184, 37, 'http://img03.taobaocdn.com/bao/uploaded/i3/832772565/T22amJXiBaXXXXXXXX_!!832772565.jpg', 1353902318, 3, 1),
(185, 37, 'http://img02.taobaocdn.com/bao/uploaded/i2/832772565/T22aOJXbBXXXXXXXXX_!!832772565.jpg', 1353902318, 4, 1),
(186, 38, 'http://img01.taobaocdn.com/bao/uploaded/i1/T17FtRXaBGXXa3dJs6_061244.jpg', 1353902318, 0, 1),
(187, 38, 'http://img03.taobaocdn.com/bao/uploaded/i3/832772565/T2KKlqXiRNXXXXXXXX_!!832772565.jpg', 1353902318, 1, 1),
(188, 38, 'http://img04.taobaocdn.com/bao/uploaded/i4/832772565/T2E9aIXXBaXXXXXXXX_!!832772565.jpg', 1353902318, 2, 1),
(189, 38, 'http://img01.taobaocdn.com/bao/uploaded/i1/832772565/T2L64jXmdNXXXXXXXX_!!832772565.jpg', 1353902318, 3, 1),
(190, 38, 'http://img04.taobaocdn.com/bao/uploaded/i4/832772565/T2DLRGXXJNXXXXXXXX_!!832772565.jpg', 1353902318, 4, 1),
(191, 39, 'http://img01.taobaocdn.com/bao/uploaded/i1/T1h8HdXXXkXXcz7r.4_051921.jpg', 1353902318, 0, 1),
(192, 39, 'http://img03.taobaocdn.com/bao/uploaded/i3/832772565/T2pwXCXdFNXXXXXXXX_!!832772565.jpg', 1353902318, 1, 1),
(193, 39, 'http://img04.taobaocdn.com/bao/uploaded/i4/832772565/T2H4pBXehNXXXXXXXX_!!832772565.jpg', 1353902318, 2, 1),
(194, 39, 'http://img04.taobaocdn.com/bao/uploaded/i4/832772565/T2N3teXjlNXXXXXXXX_!!832772565.jpg', 1353902318, 3, 1),
(195, 40, 'http://img04.taobaocdn.com/bao/uploaded/i4/T1.Ly7XmhmXXcoBArb_124637.jpg', 1353902318, 0, 1),
(196, 40, 'http://img03.taobaocdn.com/bao/uploaded/i3/832772565/T2iF5CXjVXXXXXXXXX_!!832772565.jpg', 1353902318, 1, 1),
(197, 40, 'http://img02.taobaocdn.com/bao/uploaded/i2/832772565/T2caqCXaxXXXXXXXXX_!!832772565.jpg', 1353902318, 2, 1),
(198, 40, 'http://img02.taobaocdn.com/bao/uploaded/i2/832772565/T2PUqIXlRaXXXXXXXX_!!832772565.jpg', 1353902318, 3, 1),
(199, 40, 'http://img01.taobaocdn.com/bao/uploaded/i1/832772565/T21UyIXdtaXXXXXXXX_!!832772565.jpg', 1353902318, 4, 1),
(200, 41, 'http://img04.taobaocdn.com/bao/uploaded/i4/T1srf5Xm8XXXXV8lI__110350.jpg', 1353902490, 255, 1),
(201, 42, 'http://img02.taobaocdn.com/bao/uploaded/i2/T1x7C0XhxqXXbW6xwT_012127.jpg', 1353902490, 255, 1),
(202, 43, 'http://img02.taobaocdn.com/bao/uploaded/i2/T1Ag54XbtuXXXfz.I5_060343.jpg', 1353902490, 0, 1),
(203, 43, 'http://img02.taobaocdn.com/bao/uploaded/i2/748204604/T2BLypXchaXXXXXXXX_!!748204604.jpg', 1353902490, 1, 1),
(204, 43, 'http://img04.taobaocdn.com/bao/uploaded/i4/748204604/T2RLOpXlRXXXXXXXXX_!!748204604.jpg', 1353902490, 2, 1),
(205, 44, 'http://img04.taobaocdn.com/bao/uploaded/i4/T1ugbYXkpdXXa56jsZ_033049.jpg', 1353902490, 255, 1),
(206, 45, 'http://img03.taobaocdn.com/bao/uploaded/i3/T1M463XeBdXXb0fkM9_074304.jpg', 1353902490, 0, 1),
(207, 45, 'http://img04.taobaocdn.com/bao/uploaded/i4/748204604/T2cedIXXBdXXXXXXXX_!!748204604.jpg', 1353902490, 1, 1),
(208, 45, 'http://img01.taobaocdn.com/bao/uploaded/i1/748204604/T2FGK1XaXaXXXXXXXX_!!748204604.jpg', 1353902490, 2, 1),
(209, 46, 'http://img04.taobaocdn.com/bao/uploaded/i4/T1ZArWXkllXXX.ujTX_085705.jpg', 1353902641, 0, 1),
(210, 46, 'http://img03.taobaocdn.com/bao/uploaded/i3/T15On4Xi0aXXb6czI._082729.jpg', 1353902641, 1, 1),
(211, 46, 'http://img03.taobaocdn.com/bao/uploaded/i3/748267543/T2Fea1XfpaXXXXXXXX_!!748267543.jpg', 1353902641, 2, 1),
(212, 46, 'http://img01.taobaocdn.com/bao/uploaded/i1/748267543/T2DWB0XcRbXXXXXXXX_!!748267543.jpg', 1353902641, 3, 1),
(213, 46, 'http://img01.taobaocdn.com/bao/uploaded/i1/748267543/T2xG40XbJaXXXXXXXX_!!748267543.jpg', 1353902641, 4, 1),
(214, 47, 'http://img01.taobaocdn.com/bao/uploaded/i1/T1EzLEXaFlXXcpN3g3_050111.jpg', 1353902641, 0, 1),
(215, 47, 'http://img01.taobaocdn.com/bao/uploaded/i1/748267543/T2mC47XeXcXXXXXXXX_!!748267543.jpg', 1353902641, 1, 1),
(216, 47, 'http://img03.taobaocdn.com/bao/uploaded/i3/748267543/T2WwSOXdJaXXXXXXXX_!!748267543.jpg', 1353902641, 2, 1),
(217, 47, 'http://img01.taobaocdn.com/bao/uploaded/i1/748267543/T2IQOOXhxXXXXXXXXX_!!748267543.jpg', 1353902641, 3, 1),
(218, 48, 'http://img01.taobaocdn.com/bao/uploaded/i1/T16.j3XdlbXXa8hGnb_123051.jpg', 1353902641, 0, 1),
(219, 48, 'http://img04.taobaocdn.com/bao/uploaded/i4/748267543/T2iC8zXhlNXXXXXXXX_!!748267543.jpg', 1353902641, 1, 1),
(220, 48, 'http://img02.taobaocdn.com/bao/uploaded/i2/748267543/T2WqV0XXFXXXXXXXXX_!!748267543.jpg', 1353902641, 2, 1),
(221, 48, 'http://img04.taobaocdn.com/bao/uploaded/i4/748267543/T2yKtPXohdXXXXXXXX_!!748267543.jpg', 1353902641, 3, 1),
(222, 48, 'http://img03.taobaocdn.com/bao/uploaded/i3/748267543/T2OPXPXo4dXXXXXXXX_!!748267543.jpg', 1353902641, 4, 1),
(223, 49, 'http://img03.taobaocdn.com/bao/uploaded/i3/T1qYjFXbXfXXXvyygU_015147.jpg', 1353902641, 0, 1),
(224, 49, 'http://img01.taobaocdn.com/bao/uploaded/i1/748267543/T2Lad0XXRbXXXXXXXX_!!748267543.jpg', 1353902641, 1, 1),
(225, 49, 'http://img03.taobaocdn.com/bao/uploaded/i3/748267543/T2HGt0Xe0aXXXXXXXX_!!748267543.jpg', 1353902641, 2, 1),
(226, 49, 'http://img01.taobaocdn.com/bao/uploaded/i1/748267543/T2HaJ0XktXXXXXXXXX_!!748267543.jpg', 1353902641, 3, 1),
(227, 49, 'http://img01.taobaocdn.com/bao/uploaded/i1/748267543/T2TXN0Xc4cXXXXXXXX_!!748267543.jpg', 1353902641, 4, 1),
(228, 50, 'http://img01.taobaocdn.com/bao/uploaded/i1/T1K_vfXlJaXXakVJ37_064254.jpg', 1353902641, 0, 1),
(229, 50, 'http://img02.taobaocdn.com/bao/uploaded/i2/T14WzfXaXnXXbT1tA7_064215.jpg', 1353902641, 1, 1),
(230, 50, 'http://img02.taobaocdn.com/bao/uploaded/i2/748267543/T2i6dfXeVNXXXXXXXX_!!748267543.jpg', 1353902641, 2, 1),
(231, 50, 'http://img04.taobaocdn.com/bao/uploaded/i4/748267543/T2EANKXeJcXXXXXXXX_!!748267543.jpg', 1353902641, 3, 1),
(232, 50, 'http://img01.taobaocdn.com/bao/uploaded/i1/748267543/T2d88FXdxNXXXXXXXX_!!748267543.jpg', 1353902641, 4, 1),
(233, 51, 'http://img02.taobaocdn.com/bao/uploaded/i2/T1RR2RXkNcXXceltU7_063938.jpg', 1353902642, 0, 1),
(234, 51, 'http://img03.taobaocdn.com/bao/uploaded/i3/748267543/T2GxVoXb4OXXXXXXXX_!!748267543.jpg', 1353902642, 1, 1),
(235, 51, 'http://img02.taobaocdn.com/bao/uploaded/i2/748267543/T2I_SRXa0XXXXXXXXX_!!748267543.jpg', 1353902642, 2, 1),
(236, 51, 'http://img03.taobaocdn.com/bao/uploaded/i3/748267543/T2boeQXiXaXXXXXXXX_!!748267543.jpg', 1353902642, 3, 1),
(237, 51, 'http://img04.taobaocdn.com/bao/uploaded/i4/748267543/T2bSKwXkdbXXXXXXXX_!!748267543.jpg', 1353902642, 4, 1),
(238, 52, 'http://img01.taobaocdn.com/bao/uploaded/i1/T1wnqyXXNfXXa2j1I0_034801.jpg', 1353902642, 0, 1),
(239, 52, 'http://img04.taobaocdn.com/bao/uploaded/i4/748267543/T23qx0Xm0aXXXXXXXX_!!748267543.jpg', 1353902642, 1, 1),
(240, 52, 'http://img04.taobaocdn.com/bao/uploaded/i4/748267543/T2Ubd0XaVXXXXXXXXX_!!748267543.jpg', 1353902642, 2, 1),
(241, 52, 'http://img02.taobaocdn.com/bao/uploaded/i2/748267543/T2YGF0Xh8aXXXXXXXX_!!748267543.jpg', 1353902642, 3, 1),
(242, 52, 'http://img03.taobaocdn.com/bao/uploaded/i3/748267543/T2LGX0XfXbXXXXXXXX_!!748267543.jpg', 1353902642, 4, 1),
(243, 53, 'http://img03.taobaocdn.com/bao/uploaded/i3/T197PPXgVoXXcy8OM._112623.jpg', 1353902642, 0, 1),
(244, 53, 'http://img01.taobaocdn.com/bao/uploaded/i1/748267543/T2ONy2XgRXXXXXXXXX_!!748267543.jpg', 1353902642, 1, 1),
(245, 53, 'http://img04.taobaocdn.com/bao/uploaded/i4/748267543/T2XEe1XaxaXXXXXXXX_!!748267543.jpg', 1353902642, 2, 1),
(246, 53, 'http://img04.taobaocdn.com/bao/uploaded/i4/748267543/T2Thm1Xm4aXXXXXXXX_!!748267543.jpg', 1353902642, 3, 1),
(247, 53, 'http://img02.taobaocdn.com/bao/uploaded/i2/748267543/T22x4xXmlMXXXXXXXX_!!748267543.jpg', 1353902642, 4, 1),
(248, 54, 'http://img04.taobaocdn.com/bao/uploaded/i4/T1ac2vXcRvXXXE1hsU_014747.jpg', 1353902642, 0, 1),
(249, 54, 'http://img03.taobaocdn.com/bao/uploaded/i3/748267543/T21qR0Xc8aXXXXXXXX_!!748267543.jpg', 1353902642, 1, 1),
(250, 54, 'http://img01.taobaocdn.com/bao/uploaded/i1/748267543/T2JWh0XlJbXXXXXXXX_!!748267543.jpg', 1353902642, 2, 1),
(251, 54, 'http://img02.taobaocdn.com/bao/uploaded/i2/748267543/T2pbd0XbRXXXXXXXXX_!!748267543.jpg', 1353902642, 3, 1),
(252, 54, 'http://img01.taobaocdn.com/bao/uploaded/i1/748267543/T2pbh0Xb0XXXXXXXXX_!!748267543.jpg', 1353902642, 4, 1),
(253, 55, 'http://img02.taobaocdn.com/bao/uploaded/i2/T1E2O9XhFvXXbOmjZW_024241.jpg', 1353902642, 0, 1),
(254, 55, 'http://img04.taobaocdn.com/bao/uploaded/i4/748267543/T2Wje0XjFXXXXXXXXX_!!748267543.jpg', 1353902642, 1, 1),
(255, 55, 'http://img02.taobaocdn.com/bao/uploaded/i2/748267543/T2Pz1YXbXaXXXXXXXX_!!748267543.jpg', 1353902642, 2, 1),
(256, 55, 'http://img03.taobaocdn.com/bao/uploaded/i3/748267543/T2Hzi0XcVaXXXXXXXX_!!748267543.jpg', 1353902642, 3, 1),
(257, 55, 'http://img02.taobaocdn.com/bao/uploaded/i2/748267543/T24be1XgJXXXXXXXXX_!!748267543.jpg', 1353902642, 4, 1),
(258, 56, 'http://img04.taobaocdn.com/bao/uploaded/i4/T1l3fIXkFgXXc53Jk9_102745.jpg', 1353902642, 0, 1),
(259, 56, 'http://img03.taobaocdn.com/bao/uploaded/i3/748267543/T24saOXh0aXXXXXXXX_!!748267543.jpg', 1353902642, 1, 1),
(260, 56, 'http://img01.taobaocdn.com/bao/uploaded/i1/748267543/T2g0NgXdhOXXXXXXXX_!!748267543.jpg', 1353902642, 2, 1),
(261, 56, 'http://img02.taobaocdn.com/bao/uploaded/i2/748267543/T2BymGXhhbXXXXXXXX_!!748267543.jpg', 1353902642, 3, 1),
(262, 56, 'http://img03.taobaocdn.com/bao/uploaded/i3/748267543/T2ITKOXgxXXXXXXXXX_!!748267543.jpg', 1353902642, 4, 1),
(263, 57, 'http://img01.taobaocdn.com/bao/uploaded/i1/T1msjzXfFmXXbavIAU_013829.jpg', 1353902642, 0, 1),
(264, 57, 'http://img03.taobaocdn.com/bao/uploaded/i3/T1A79pXnxnXXbwUwbb_094112.jpg', 1353902642, 1, 1),
(265, 57, 'http://img04.taobaocdn.com/bao/uploaded/i4/748267543/T23Hd0XbBXXXXXXXXX_!!748267543.jpg', 1353902642, 2, 1),
(266, 57, 'http://img03.taobaocdn.com/bao/uploaded/i3/748267543/T29YX0XedXXXXXXXXX_!!748267543.jpg', 1353902642, 3, 1),
(267, 57, 'http://img01.taobaocdn.com/bao/uploaded/i1/748267543/T2IWF0Xj0aXXXXXXXX_!!748267543.jpg', 1353902642, 4, 1),
(268, 58, 'http://img01.taobaocdn.com/bao/uploaded/i1/T1RKfEXkxkXXc.bh3U_014824.jpg', 1353902643, 0, 1),
(269, 58, 'http://img02.taobaocdn.com/bao/uploaded/i2/748267543/T2BwX6XatXXXXXXXXX_!!748267543.jpg', 1353902643, 1, 1),
(270, 59, 'http://img02.taobaocdn.com/bao/uploaded/i2/T1_tHLXn4fXXXLjDMT_013219.jpg', 1353902643, 0, 1),
(271, 59, 'http://img01.taobaocdn.com/bao/uploaded/i1/748267543/T2STKOXdxXXXXXXXXX_!!748267543.jpg', 1353902643, 1, 1),
(272, 59, 'http://img03.taobaocdn.com/bao/uploaded/i3/748267543/T2CQaLXdtaXXXXXXXX_!!748267543.jpg', 1353902643, 2, 1),
(273, 59, 'http://img01.taobaocdn.com/bao/uploaded/i1/748267543/T2V0qOXbtaXXXXXXXX_!!748267543.jpg', 1353902643, 3, 1),
(274, 59, 'http://img04.taobaocdn.com/bao/uploaded/i4/748267543/T2A7luXhlNXXXXXXXX_!!748267543.jpg', 1353902643, 4, 1),
(275, 60, 'http://img03.taobaocdn.com/bao/uploaded/i3/T1A4n_XglcXXcUv5g0_035537.jpg', 1353902643, 0, 1),
(276, 60, 'http://img03.taobaocdn.com/bao/uploaded/i3/748267543/T2kOa4XctaXXXXXXXX_!!748267543.jpg', 1353902643, 1, 1),
(277, 60, 'http://img02.taobaocdn.com/bao/uploaded/i2/748267543/T2CnVcXeVOXXXXXXXX_!!748267543.jpg', 1353902643, 2, 1),
(278, 60, 'http://img02.taobaocdn.com/bao/uploaded/i2/748267543/T2Ma5WXXtbXXXXXXXX_!!748267543.jpg', 1353902643, 3, 1),
(279, 60, 'http://img04.taobaocdn.com/bao/uploaded/i4/748267543/T2BE14XaXXXXXXXXXX_!!748267543.jpg', 1353902643, 4, 1),
(280, 61, 'http://img02.taobaocdn.com/bao/uploaded/i2/T1MDaHXc0rXXaonAs9_104246.jpg', 1353902643, 255, 1),
(281, 62, 'http://img03.taobaocdn.com/bao/uploaded/i3/T1hG1IXelfXXcX4o.9_105150.jpg', 1353902643, 0, 1),
(282, 62, 'http://img01.taobaocdn.com/bao/uploaded/i1/T1mlqHXkNwXXbzeRrb_095055.jpg', 1353902643, 1, 1),
(283, 62, 'http://img02.taobaocdn.com/bao/uploaded/i2/748267543/T2vNGfXaFaXXXXXXXX_!!748267543.jpg', 1353902643, 2, 1),
(284, 63, '1709/04/59ad10fab7bf9.jpg', 1504514298, 255, 1),
(285, 63, '1709/04/59ad10fad5ae7.jpg', 1504514298, 255, 1),
(286, 64, '1709/04/59ad1128d930c.jpg', 1504514345, 255, 1),
(287, 64, '1709/04/59ad1129000c0.jpg', 1504514345, 255, 1),
(288, 65, '1709/04/59ad116696dfb.jpg', 1504514406, 255, 1),
(289, 65, '1709/04/59ad1166b4777.jpg', 1504514406, 255, 1),
(290, 66, '1709/04/59ad119657ec3.jpg', 1504514454, 255, 1),
(291, 66, '1709/04/59ad11966e4b8.jpg', 1504514454, 255, 1),
(292, 67, '1709/04/59ad11bb8a1eb.jpg', 1504514491, 255, 1),
(293, 67, '1709/04/59ad11bba8fc3.jpg', 1504514491, 255, 1),
(294, 68, '1709/04/59ad12a82ee26.jpg', 1504514728, 255, 1),
(295, 68, '1709/04/59ad12a851337.jpg', 1504514728, 255, 1);

-- --------------------------------------------------------

--
-- 表的结构 `pin_item_like`
--

CREATE TABLE IF NOT EXISTS `pin_item_like` (
  `item_id` int(10) unsigned NOT NULL,
  `uid` int(10) unsigned NOT NULL,
  `add_time` int(10) NOT NULL,
  PRIMARY KEY (`item_id`,`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `pin_item_orig`
--

CREATE TABLE IF NOT EXISTS `pin_item_orig` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `img` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `ordid` tinyint(3) unsigned NOT NULL DEFAULT '255',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `pin_item_orig`
--

INSERT INTO `pin_item_orig` (`id`, `img`, `name`, `url`, `ordid`) VALUES
(1, '50b2e721a6c1e_thumb.jpg', '淘宝', 'taobao.com', 0),
(2, '50b2e726d4ade_thumb.jpg', '天猫', 'tmall.com', 0);

-- --------------------------------------------------------

--
-- 表的结构 `pin_item_site`
--

CREATE TABLE IF NOT EXISTS `pin_item_site` (
  `id` smallint(4) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `domain` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `desc` varchar(255) NOT NULL,
  `config` text NOT NULL,
  `author` varchar(50) NOT NULL,
  `ordid` tinyint(3) unsigned NOT NULL DEFAULT '255',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- 转存表中的数据 `pin_item_site`
--

INSERT INTO `pin_item_site` (`id`, `code`, `name`, `domain`, `url`, `desc`, `config`, `author`, `ordid`, `status`) VALUES
(5, 'taobao', '淘宝', 'taobao.com,tianmao.com,tmall.com', 'http://www.taobao.com', '通过淘宝开放平台获取商品数据，可到 http://open.taobao.com/ 查看详细', 'a:3:{s:7:"app_key";s:8:"12504724";s:10:"app_secret";s:32:"9d6877190386092d4288dcae32811081";s:9:"taoke_pid";s:8:"16185888";}', 'PinPHP TEAM', 255, 1);

-- --------------------------------------------------------

--
-- 表的结构 `pin_item_tag`
--

CREATE TABLE IF NOT EXISTS `pin_item_tag` (
  `item_id` int(10) unsigned NOT NULL,
  `tag_id` int(10) unsigned NOT NULL,
  UNIQUE KEY `item_id` (`item_id`,`tag_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `pin_item_tag`
--

INSERT INTO `pin_item_tag` (`item_id`, `tag_id`) VALUES
(1, 1),
(1, 47),
(1, 48),
(1, 49),
(1, 50),
(1, 51),
(1, 52),
(1, 53),
(1, 54),
(1, 55),
(2, 25),
(2, 49),
(2, 50),
(2, 51),
(2, 52),
(2, 53),
(2, 54),
(2, 56),
(2, 57),
(2, 58),
(3, 1),
(3, 50),
(3, 51),
(3, 52),
(3, 53),
(3, 59),
(3, 60),
(3, 61),
(3, 62),
(3, 63),
(4, 25),
(4, 47),
(4, 49),
(4, 52),
(4, 53),
(4, 57),
(4, 62),
(4, 63),
(4, 64),
(4, 65),
(5, 1),
(5, 7),
(5, 52),
(5, 53),
(5, 54),
(5, 59),
(5, 63),
(5, 66),
(5, 67),
(5, 68),
(6, 1),
(6, 53),
(6, 54),
(6, 68),
(6, 69),
(6, 70),
(7, 17),
(7, 52),
(7, 53),
(7, 57),
(7, 59),
(7, 62),
(7, 69),
(7, 71),
(7, 72),
(7, 73),
(8, 52),
(8, 54),
(8, 57),
(8, 62),
(8, 63),
(8, 74),
(8, 75),
(8, 76),
(8, 77),
(9, 1),
(9, 4),
(9, 36),
(9, 50),
(9, 51),
(9, 52),
(9, 53),
(9, 59),
(9, 67),
(9, 78),
(10, 1),
(10, 52),
(10, 53),
(10, 56),
(10, 59),
(10, 61),
(10, 63),
(10, 72),
(10, 79),
(10, 80),
(11, 1),
(11, 2),
(11, 23),
(11, 52),
(11, 53),
(11, 54),
(11, 59),
(11, 65),
(11, 72),
(11, 80),
(12, 17),
(12, 29),
(12, 49),
(12, 50),
(12, 51),
(12, 52),
(12, 53),
(12, 54),
(12, 57),
(12, 81),
(13, 1),
(13, 19),
(13, 50),
(13, 51),
(13, 52),
(13, 53),
(13, 59),
(13, 63),
(13, 69),
(13, 82),
(14, 1),
(14, 52),
(14, 53),
(14, 54),
(14, 56),
(14, 59),
(14, 63),
(14, 78),
(14, 81),
(14, 83),
(15, 4),
(15, 50),
(15, 51),
(15, 53),
(15, 54),
(15, 57),
(15, 79),
(15, 84),
(15, 85),
(15, 86),
(16, 1),
(16, 5),
(16, 47),
(16, 50),
(16, 51),
(16, 63),
(16, 85),
(16, 86),
(16, 87),
(16, 88),
(17, 1),
(17, 5),
(17, 50),
(17, 51),
(17, 52),
(17, 53),
(17, 54),
(17, 59),
(17, 85),
(17, 89),
(18, 47),
(18, 52),
(18, 53),
(18, 54),
(18, 57),
(18, 59),
(18, 63),
(18, 81),
(18, 90),
(18, 91),
(19, 1),
(19, 35),
(19, 49),
(19, 50),
(19, 51),
(19, 53),
(19, 57),
(19, 58),
(19, 63),
(19, 74),
(20, 50),
(20, 51),
(20, 53),
(20, 54),
(20, 57),
(20, 88),
(20, 92),
(20, 93),
(20, 94),
(20, 95),
(21, 52),
(21, 217),
(21, 218),
(21, 219),
(21, 220),
(21, 221),
(21, 222),
(21, 223),
(21, 224),
(21, 225),
(22, 28),
(22, 30),
(22, 83),
(22, 217),
(22, 223),
(22, 226),
(22, 227),
(22, 228),
(22, 229),
(22, 230),
(23, 28),
(23, 30),
(23, 83),
(23, 218),
(23, 219),
(23, 222),
(23, 223),
(23, 229),
(23, 231),
(23, 232),
(24, 52),
(24, 218),
(24, 219),
(24, 220),
(24, 223),
(24, 230),
(24, 233),
(24, 234),
(24, 235),
(24, 236),
(25, 25),
(25, 28),
(25, 52),
(25, 83),
(25, 217),
(25, 223),
(25, 226),
(25, 235),
(25, 237),
(25, 238),
(26, 28),
(26, 30),
(26, 52),
(26, 81),
(26, 223),
(26, 226),
(26, 227),
(26, 235),
(26, 239),
(26, 240),
(27, 29),
(27, 81),
(27, 219),
(27, 223),
(27, 226),
(27, 238),
(27, 241),
(27, 242),
(27, 243),
(27, 244),
(28, 52),
(28, 217),
(28, 218),
(28, 219),
(28, 227),
(28, 235),
(28, 239),
(28, 241),
(28, 245),
(28, 246),
(29, 25),
(29, 28),
(29, 217),
(29, 218),
(29, 219),
(29, 220),
(29, 223),
(29, 230),
(29, 247),
(29, 248),
(30, 28),
(30, 217),
(30, 222),
(30, 223),
(30, 229),
(30, 232),
(30, 239),
(30, 240),
(30, 249),
(30, 250),
(31, 42),
(31, 52),
(31, 219),
(31, 223),
(31, 226),
(31, 239),
(31, 251),
(31, 252),
(31, 253),
(31, 254),
(32, 28),
(32, 30),
(32, 52),
(32, 217),
(32, 218),
(32, 219),
(32, 222),
(32, 223),
(32, 255),
(32, 256),
(33, 52),
(33, 218),
(33, 219),
(33, 223),
(33, 239),
(33, 243),
(33, 257),
(33, 258),
(33, 259),
(33, 260),
(34, 52),
(34, 81),
(34, 218),
(34, 219),
(34, 220),
(34, 223),
(34, 235),
(34, 239),
(34, 241),
(34, 261),
(35, 25),
(35, 42),
(35, 52),
(35, 68),
(35, 83),
(35, 222),
(35, 223),
(35, 226),
(35, 239),
(35, 253),
(36, 52),
(36, 81),
(36, 219),
(36, 220),
(36, 226),
(36, 227),
(36, 239),
(36, 246),
(36, 261),
(36, 262),
(37, 25),
(37, 52),
(37, 81),
(37, 219),
(37, 220),
(37, 223),
(37, 226),
(37, 235),
(37, 237),
(37, 239),
(38, 28),
(38, 52),
(38, 218),
(38, 223),
(38, 232),
(38, 238),
(38, 239),
(38, 247),
(38, 263),
(38, 264),
(39, 218),
(39, 219),
(39, 223),
(39, 225),
(39, 230),
(39, 233),
(39, 243),
(39, 252),
(39, 258),
(39, 265),
(40, 28),
(40, 68),
(40, 217),
(40, 219),
(40, 223),
(40, 226),
(40, 232),
(40, 237),
(40, 239),
(40, 266),
(41, 1),
(41, 52),
(41, 89),
(41, 272),
(41, 273),
(41, 274),
(41, 275),
(41, 276),
(41, 277),
(42, 1),
(42, 5),
(42, 52),
(42, 69),
(42, 91),
(42, 235),
(42, 236),
(42, 273),
(42, 278),
(42, 279),
(43, 1),
(43, 4),
(43, 62),
(43, 68),
(43, 74),
(43, 90),
(43, 273),
(43, 280),
(43, 281),
(43, 282),
(44, 1),
(44, 52),
(44, 235),
(44, 236),
(44, 273),
(44, 275),
(44, 283),
(44, 284),
(44, 285),
(45, 30),
(45, 35),
(45, 58),
(45, 89),
(45, 272),
(45, 273),
(45, 275),
(45, 286),
(45, 287),
(45, 288),
(46, 51),
(46, 298),
(46, 299),
(46, 300),
(46, 301),
(46, 302),
(46, 303),
(46, 304),
(46, 305),
(46, 306),
(47, 51),
(47, 232),
(47, 262),
(47, 300),
(47, 307),
(47, 308),
(47, 309),
(47, 310),
(47, 311),
(48, 232),
(48, 262),
(48, 300),
(48, 307),
(48, 308),
(48, 310),
(48, 311),
(49, 51),
(49, 262),
(49, 298),
(49, 300),
(49, 305),
(49, 310),
(49, 312),
(50, 51),
(50, 52),
(50, 235),
(50, 236),
(50, 300),
(50, 303),
(50, 313),
(50, 314),
(50, 315),
(51, 51),
(51, 300),
(51, 307),
(51, 310),
(51, 316),
(52, 25),
(52, 51),
(52, 300),
(52, 316),
(52, 317),
(52, 318),
(52, 319),
(52, 320),
(53, 51),
(53, 52),
(53, 236),
(53, 300),
(53, 304),
(53, 309),
(53, 310),
(53, 312),
(53, 321),
(53, 322),
(54, 30),
(54, 51),
(54, 52),
(54, 235),
(54, 236),
(54, 299),
(54, 307),
(54, 314),
(54, 318),
(54, 323),
(55, 51),
(55, 52),
(55, 235),
(55, 236),
(55, 262),
(55, 300),
(55, 303),
(55, 313),
(55, 314),
(55, 315),
(56, 51),
(56, 52),
(56, 235),
(56, 236),
(56, 262),
(56, 298),
(56, 300),
(56, 305),
(56, 310),
(56, 312),
(57, 51),
(57, 52),
(57, 235),
(57, 236),
(57, 262),
(57, 298),
(57, 300),
(57, 305),
(57, 314),
(57, 324),
(58, 51),
(58, 65),
(58, 68),
(58, 300),
(58, 318),
(58, 325),
(58, 326),
(59, 51),
(59, 236),
(59, 262),
(59, 298),
(59, 300),
(59, 305),
(59, 314),
(59, 324),
(59, 327),
(60, 51),
(60, 298),
(60, 300),
(60, 301),
(60, 306),
(60, 318),
(60, 324),
(60, 328),
(60, 329),
(61, 51),
(61, 52),
(61, 83),
(61, 225),
(61, 228),
(61, 235),
(61, 236),
(61, 331),
(61, 332),
(62, 51),
(62, 83),
(62, 228),
(62, 331),
(62, 332),
(62, 333),
(62, 334),
(62, 335),
(63, 420),
(63, 421),
(63, 422),
(64, 422),
(64, 423),
(64, 424),
(64, 425),
(65, 123),
(65, 426),
(66, 422),
(66, 426),
(66, 427),
(66, 428),
(66, 429),
(67, 430),
(67, 431),
(68, 432),
(68, 433),
(68, 434),
(68, 435),
(68, 436);

-- --------------------------------------------------------

--
-- 表的结构 `pin_mail_queue`
--

CREATE TABLE IF NOT EXISTS `pin_mail_queue` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `mail_to` varchar(120) NOT NULL,
  `mail_subject` varchar(255) NOT NULL,
  `mail_body` text NOT NULL,
  `priority` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `err_num` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `add_time` int(10) unsigned NOT NULL,
  `lock_expiry` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `pin_menu`
--

CREATE TABLE IF NOT EXISTS `pin_menu` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `pid` smallint(6) NOT NULL,
  `module_name` varchar(20) NOT NULL,
  `action_name` varchar(20) NOT NULL,
  `data` varchar(120) NOT NULL,
  `remark` varchar(255) NOT NULL,
  `often` tinyint(1) NOT NULL DEFAULT '0',
  `ordid` tinyint(3) unsigned NOT NULL DEFAULT '255',
  `display` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=287 ;

--
-- 转存表中的数据 `pin_menu`
--

INSERT INTO `pin_menu` (`id`, `name`, `pid`, `module_name`, `action_name`, `data`, `remark`, `often`, `ordid`, `display`) VALUES
(1, '全局', 0, 'setting', 'index', '', '', 0, 7, 1),
(2, '核心设置', 1, 'setting', 'index', '', '', 0, 0, 1),
(3, '全局参数', 148, 'setting', 'index', '&type=site', '', 0, 2, 1),
(4, '邮件设置', 148, 'setting', 'index', '&type=mail', '', 0, 5, 1),
(172, '专辑管理', 285, 'album', 'index', '', '', 0, 4, 1),
(6, '菜单管理', 2, 'menu', 'index', '', '', 0, 7, 1),
(7, '新增', 6, 'menu', 'add', '', '', 0, 0, 0),
(8, '编辑', 6, 'menu', 'edit', '', '', 0, 0, 0),
(9, '删除', 6, 'menu', 'delete', '', '', 0, 0, 0),
(10, '运营', 0, 'operate', 'index', '', '', 0, 4, 1),
(11, '广告管理', 10, 'advert', 'index', '', '', 0, 2, 1),
(12, '广告管理', 11, 'ad', 'index', '', '', 0, 0, 1),
(13, '广告位管理', 11, 'adboard', 'index', '', '', 0, 0, 1),
(14, '友情链接', 10, 'flink', 'index', '', '', 0, 3, 1),
(15, '友情链接', 14, 'flink', 'index', '', '', 0, 0, 1),
(16, '链接分类', 14, 'flink_cate', 'index', '', '', 0, 0, 1),
(17, '新增', 15, 'flink', 'add', '', '', 0, 0, 0),
(18, '编辑', 15, 'flink', 'edit', '', '', 0, 0, 0),
(19, '删除', 15, 'flink', 'delete', '', '', 0, 0, 0),
(20, '新增', 16, 'flink_cate', 'add', '', '', 0, 0, 0),
(21, '编辑', 16, 'flink_cate', 'edit', '', '', 0, 0, 0),
(22, '删除', 16, 'flink_cate', 'del', '', '', 0, 0, 0),
(23, '新增', 12, 'ad', 'add', '', '', 0, 0, 0),
(24, '编辑', 12, 'ad', 'edit', '', '', 0, 0, 0),
(25, '删除', 12, 'ad', 'delete', '', '', 0, 0, 0),
(26, '新增', 13, 'adboard', 'add', '', '', 0, 0, 0),
(27, '编辑', 13, 'adboard', 'edit', '', '', 0, 0, 0),
(28, '删除', 13, 'adboard', 'delete', '', '', 0, 0, 0),
(29, '数据', 0, 'data', 'index', '', '', 0, 5, 1),
(258, '商品分类', 256, 'score_item_cate', 'index', '', '', 0, 255, 1),
(31, '数据库管理', 29, 'backup', 'index', '', '', 0, 2, 1),
(32, '数据备份', 31, 'backup', 'index', '', '', 0, 0, 1),
(33, '数据恢复', 31, 'backup', 'restore', '', '', 0, 0, 1),
(34, '缓存管理', 254, 'cache', 'index', '', '', 0, 0, 1),
(195, '登陆接口', 245, 'oauth', 'index', '', '', 0, 2, 1),
(36, '黑名单管理', 117, 'ipban', 'index', '', '', 0, 3, 1),
(37, '新增', 36, 'ipban', 'add', '', '', 0, 0, 0),
(38, '编辑', 36, 'ipban', 'edit', '', '', 0, 0, 0),
(50, '商品', 0, 'content', 'index', '', '', 0, 1, 1),
(51, '商品管理', 50, 'article', 'index', '', '', 0, 1, 1),
(52, '商品管理', 51, 'item', 'index', '', '', 1, 1, 1),
(54, '编辑', 52, 'article', 'edit', '', '', 0, 3, 0),
(190, '删除', 52, 'item', 'delete', '', '', 0, 4, 0),
(56, '商品分类', 51, 'item_cate', 'index', '', '', 1, 6, 1),
(57, '新增', 56, 'article_cate', 'add', '', '', 0, 0, 0),
(58, '编辑', 56, 'article_cate', 'edit', '', '', 0, 0, 0),
(59, '删除', 56, 'article_cate', 'delete', '', '', 0, 0, 0),
(60, '管理员管理', 1, 'admin', 'index', '', '', 0, 4, 1),
(61, '管理员管理', 60, 'admin', 'index', '', '', 0, 0, 1),
(62, '新增', 61, 'admin', 'add', '', '', 0, 0, 0),
(63, '编辑', 61, 'admin', 'edit', '', '', 0, 0, 0),
(64, '删除', 61, 'admin', 'delete', '', '', 0, 0, 0),
(65, '角色管理', 60, 'admin_role', 'index', '', '', 0, 0, 1),
(66, '新增', 65, 'admin_role', 'add', '', '', 0, 0, 0),
(192, '淘宝采集', 164, 'collect_alimama', 'index', '', '', 0, 0, 1),
(70, '用户', 0, 'user', 'index', '', '', 0, 3, 1),
(119, '新增', 149, 'user', 'add', '', '', 0, 3, 0),
(118, '编辑', 149, 'user', 'edit', '', '', 0, 4, 0),
(117, '会员管理', 70, 'user', 'index', '', '', 0, 0, 1),
(156, '文章分类', 154, 'article_cate', 'index', '', '', 0, 3, 1),
(151, '导航设置', 216, 'nav', 'index', '', '', 0, 1, 1),
(149, '会员管理', 117, 'user', 'index', '', '', 0, 1, 1),
(150, '删除', 149, 'user', 'delete', '', '', 0, 5, 0),
(152, '主导航', 151, 'nav', 'index', '&type=main', '', 0, 1, 1),
(153, '底部导航', 151, 'nav', 'index', '&type=bottom', '', 0, 2, 1),
(154, '文章管理', 10, 'article', 'index', '', '', 0, 1, 1),
(155, '文章管理', 154, 'article', 'index', '', '', 0, 1, 1),
(148, '站点设置', 2, 'setting', 'index', '', '', 0, 0, 1),
(157, '添加文章', 155, 'article', 'add', '', '', 0, 2, 1),
(158, '编辑', 155, 'article', 'edit', '', '', 0, 3, 0),
(159, '删除', 155, 'article', 'delete', '', '', 0, 4, 0),
(160, '新增', 156, 'article_cate', 'add', '', '', 0, 0, 0),
(161, '编辑', 156, 'article_cate', '编辑', '', '', 0, 0, 0),
(162, '删除', 156, 'article_cate', 'delete', '', '', 0, 0, 0),
(164, '商品采集', 50, 'item_collect', 'index', '', '', 0, 2, 1),
(173, '专辑管理', 172, 'album', 'index', '', '', 0, 1, 1),
(174, '专辑分类', 172, 'album_cate', 'index', '', '', 0, 3, 1),
(175, '新增', 174, 'album_cate', 'add', '', '', 0, 0, 0),
(176, '编辑', 174, 'album_cate', 'edit', '', '', 0, 0, 0),
(177, '删除', 174, 'album_cate', 'delete', '', '', 0, 0, 0),
(178, '敏感词管理', 254, 'badword', 'index', '', '', 0, 4, 1),
(179, '新增', 178, 'badword', 'add', '', '', 0, 0, 0),
(180, '编辑', 178, 'badword', 'edit', '', '', 0, 0, 0),
(181, '删除', 36, 'ipban', 'delete', '', '', 0, 0, 0),
(182, '删除', 178, 'badword', 'delete', '', '', 0, 0, 0),
(255, '采集马甲', 117, 'auto_user', 'index', '', '', 0, 2, 1),
(184, '标签管理', 254, 'tag', 'index', '', '', 0, 3, 1),
(185, '商品接口', 245, 'item_site', 'index', '', '', 0, 1, 1),
(186, '商品评论', 51, 'item_comment', 'index', '', '', 0, 7, 1),
(187, '删除', 186, 'item_comment', 'delete', '', '', 0, 0, 0),
(265, '删除', 257, 'score_item', 'edit', '', '', 0, 4, 0),
(250, '一键删除', 51, 'item', 'delete_search', '', '', 0, 5, 1),
(198, '新增', 196, 'message', 'add', '', '', 0, 0, 0),
(199, '商品来源', 51, 'item_orig', 'index', '', '', 0, 6, 1),
(200, '新增', 199, 'item_orig', 'add', '', '', 0, 0, 0),
(201, '编辑', 199, 'item_orig', 'edit', '', '', 0, 0, 0),
(202, '删除', 199, 'item_orig', 'delete', '', '', 0, 0, 0),
(203, '商品审核', 51, 'item', 'check', '', '', 0, 5, 1),
(249, '添加商品', 51, 'item', 'add', '', '', 0, 3, 1),
(259, '新增', 258, 'score_item_cate', 'add', '', '', 0, 255, 0),
(268, '批量添加', 164, 'collect_batch', 'index', '', '', 0, 255, 1),
(269, '积分设置', 2, 'score', 'setting', '', '', 0, 3, 1),
(210, '专辑审核', 172, 'album', 'check', '', '', 0, 2, 1),
(257, '积分商品', 256, 'score_item', 'index', '', '', 0, 255, 1),
(212, '日志管理', 29, 'log', 'index', '', '', 0, 3, 0),
(213, '管理员日志', 212, 'log', 'index', '', '', 0, 0, 0),
(214, '用户日志', 212, 'log', 'user', '', '', 0, 0, 1),
(215, '积分日志', 212, 'log', 'score', '', '', 0, 0, 0),
(216, '界面设置', 1, 'setting', 'index', '&type=show', '', 0, 2, 1),
(256, '积分商城', 70, 'score_item', 'index', '', '', 0, 255, 1),
(254, '系统数据', 29, 'tag', 'index', '', '', 0, 1, 1),
(264, '编辑', 257, 'score_item', 'edit', '', '', 0, 3, 0),
(263, '添加商品', 257, 'score_item', 'add', '', '', 0, 2, 1),
(262, '积分订单', 256, 'score_order', 'index', '', '', 0, 255, 1),
(261, '删除', 258, 'score_item_cate', 'delete', '', '', 0, 255, 0),
(260, '编辑', 258, 'score_item_cate', 'edit', '', '', 0, 255, 0),
(232, '站内信管理', 70, 'message', 'index', '', '', 0, 0, 1),
(233, '系统通知', 232, 'message', 'index', '&type=1', '', 0, 0, 1),
(234, '用户私信', 232, 'message', 'index', '&type=2', '', 0, 0, 1),
(235, '通知模版', 2, 'message_tpl', 'index', '&type=msg', '', 0, 4, 1),
(236, '添加模版', 235, 'message_tpl', 'add', '', '', 0, 7, 1),
(237, '编辑', 235, 'message_tpl', 'edit', '', '', 0, 255, 0),
(238, '删除', 235, 'message_tpl', 'delete', '', '', 0, 255, 0),
(240, '单页管理', 154, 'article', 'page', '', '', 0, 2, 1),
(242, '积分记录', 269, 'score', 'logs', '', '', 0, 2, 1),
(244, '应用', 0, 'plugin', 'index', '', '', 0, 6, 1),
(245, '系统接口', 244, 'apis', 'index', '', '', 0, 1, 1),
(246, '应用管理', 244, 'plugin', 'index', '', '', 0, 3, 0),
(247, '应用中心', 246, 'plugin', 'index', '', '', 0, 0, 1),
(248, '已安装应用', 246, 'plugin', 'list', '', '', 0, 0, 1),
(252, '用户整合', 245, 'integrate', 'index', '', '', 0, 255, 1),
(253, '图片模式', 52, 'item', 'index', '&sm=image', '', 0, 2, 1),
(267, '批量注册', 149, 'user', 'add_users', '', '', 0, 2, 1),
(270, '邮件模板', 235, 'message_tpl', 'index', '&type=mail', '', 0, 6, 1),
(271, '短消息模板', 235, 'message_tpl', 'index', '&type=msg', '', 0, 5, 1),
(272, '附件设置', 148, 'setting', 'index', '&type=attachment', '', 0, 4, 1),
(273, '显示设置', 216, 'setting', 'index', '&type=style', '', 0, 2, 1),
(274, '模板管理', 216, 'template', 'index', '', '', 0, 3, 1),
(275, '站点设置', 148, 'setting', 'index', '', '', 0, 1, 1),
(276, '积分设置', 269, 'score', 'setting', '', '', 0, 1, 1),
(277, '商品管理', 52, 'item', 'index', '', '', 0, 1, 1),
(278, '文章管理', 155, 'article', 'index', '', '', 0, 1, 1),
(279, '会员管理', 149, 'user', 'index', '', '', 0, 1, 1),
(280, '积分商品', 257, 'score_item', 'index', '', '', 0, 1, 1),
(281, '淘宝评论', 164, 'cmt_taobao', 'index', '', '', 0, 255, 1),
(282, 'SEO设置', 2, 'seo', 'url', '', '', 0, 5, 1),
(283, 'UR静态化', 282, 'seo', 'url', '', '', 0, 255, 1),
(284, '页面SEO', 282, 'seo', 'page', '', '', 0, 255, 1),
(285, '专辑', 0, 'album', 'index', '', '', 0, 2, 1),
(286, '注册登陆', 2, 'setting', 'user', '', '', 0, 2, 1);

-- --------------------------------------------------------

--
-- 表的结构 `pin_message`
--

CREATE TABLE IF NOT EXISTS `pin_message` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `ftid` int(10) unsigned NOT NULL,
  `from_id` int(10) NOT NULL,
  `from_name` varchar(50) NOT NULL,
  `to_id` int(10) NOT NULL,
  `to_name` varchar(50) NOT NULL,
  `add_time` int(10) NOT NULL,
  `info` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `pin_message_tpl`
--

CREATE TABLE IF NOT EXISTS `pin_message_tpl` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(20) NOT NULL,
  `is_sys` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `name` varchar(50) NOT NULL,
  `alias` varchar(50) NOT NULL COMMENT '别名',
  `content` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- 转存表中的数据 `pin_message_tpl`
--

INSERT INTO `pin_message_tpl` (`id`, `type`, `is_sys`, `name`, `alias`, `content`) VALUES
(1, 'msg', 1, '登录', 'login', '<p>\r\n	欢迎\r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<div>\r\n	<p>\r\n		<span style="font-size:10.5000pt;font-family:''宋体'';">拼品网是一个集购物与分享与一体的网站，它会带给你惊喜，它让你与心仪的宝贝不期而遇，同时和朋友一起逛，分享每一次的购物乐趣，惊喜不断<span>~</span></span><span style="font-size:10.5000pt;font-family:''宋体'';"></span> \r\n	</p>\r\n	<p>\r\n		<span style="font-size:10.5000pt;font-family:''宋体'';"></span> \r\n	</p>\r\n	<p>\r\n		<span style="font-size:10.5000pt;font-family:''宋体'';">为了更好地开始专属于你的购物之旅，你可以：</span><span style="font-size:10.5000pt;font-family:''宋体'';"></span> \r\n	</p>\r\n	<p>\r\n		<span style="font-size:10.5000pt;font-family:''宋体'';"></span> \r\n	</p>\r\n	<p>\r\n		<span style="font-size:10.5000pt;font-family:''宋体'';">1<span>、发现更多美好</span></span><span style="font-size:10.5000pt;font-family:''宋体'';"></span> \r\n	</p>\r\n	<p>\r\n		<span style="font-size:10.5000pt;font-family:''宋体'';"></span> \r\n	</p>\r\n	<p>\r\n		<span style="font-size:10.5000pt;font-family:''宋体'';">2<span>、寻找喜好相投的好友</span></span><span style="font-size:10.5000pt;font-family:''宋体'';"></span> \r\n	</p>\r\n	<p>\r\n		<span style="font-size:10.5000pt;font-family:''宋体'';"></span> \r\n	</p>\r\n	<p>\r\n		<span style="font-size:10.5000pt;font-family:''宋体'';">4<span>、创建属于自己的专辑</span></span><span style="font-size:10.5000pt;font-family:''宋体'';"></span> \r\n	</p>\r\n	<p>\r\n		<span style="font-size:10.5000pt;font-family:''宋体'';"></span> \r\n	</p>\r\n	<p>\r\n		<span style="font-size:10.5000pt;font-family:''宋体'';">5<span>、邀请你的好友一起发现美丽</span></span><span style="font-size:10.5000pt;font-family:''宋体'';"></span> \r\n	</p>\r\n	<p>\r\n		<span style="font-size:10.5000pt;font-family:''宋体'';"></span> \r\n	</p>\r\n	<p>\r\n		<span style="font-size:10.5000pt;font-family:''宋体'';">6<span>、分享更多好东西</span></span><span style="font-size:10.5000pt;font-family:''宋体'';"></span> \r\n	</p>\r\n	<p>\r\n		<span style="font-size:10.5000pt;font-family:''宋体'';"></span> \r\n	</p>\r\n	<p>\r\n		<span style="font-size:10.5000pt;font-family:''宋体'';"></span> \r\n	</p>\r\n	<p>\r\n		<span style="font-size:10.5000pt;font-family:''宋体'';">欢迎联系使用拼品网，我们随时恭候你的提问和建议。</span><span style="font-size:10.5000pt;font-family:''宋体'';"></span> \r\n	</p>\r\n	<p>\r\n		<span style="font-size:10.5000pt;font-family:''宋体'';">祝您玩的愉快<span>^^</span></span> \r\n	</p>\r\n</div>\r\n<p>\r\n	<br />\r\n</p>'),
(3, 'mail', 1, '找回密码', 'findpwd', '<p>\r\n	尊敬的{$username}:\r\n</p>\r\n<p style="padding-left:30px;">\r\n	您好, 您刚才在 {$site_name} 申请了重置密码，请点击下面的链接进行重置：\r\n</p>\r\n<p style="padding-left:30px;">\r\n	<a href="{$reset_url}">{$reset_url}</a> \r\n</p>\r\n<p style="padding-left:30px;">\r\n	此链接只能使用一次, 如果失效请重新申请. 如果以上链接无法点击，请将它拷贝到浏览器(例如IE)的地址栏中。\r\n</p>\r\n<p style="text-align:right;">\r\n	{$site_name}\r\n</p>\r\n<p style="text-align:right;">\r\n	{$send_time}\r\n</p>');

-- --------------------------------------------------------

--
-- 表的结构 `pin_nav`
--

CREATE TABLE IF NOT EXISTS `pin_nav` (
  `id` smallint(4) unsigned NOT NULL AUTO_INCREMENT,
  `type` varchar(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `alias` varchar(20) NOT NULL,
  `link` varchar(255) NOT NULL,
  `target` tinyint(1) NOT NULL DEFAULT '1',
  `ordid` tinyint(3) unsigned NOT NULL DEFAULT '255',
  `mod` varchar(20) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- 转存表中的数据 `pin_nav`
--

INSERT INTO `pin_nav` (`id`, `type`, `name`, `alias`, `link`, `target`, `ordid`, `mod`, `status`) VALUES
(1, 'main', '发现', 'book', '', 0, 255, 'sys', 1),
(2, 'main', '专辑', 'album', '', 0, 255, 'sys', 1),
(3, 'main', '集市', 'cate', '?m=book&a=cate&cid=1', 0, 255, '', 1),
(4, 'bottom', '发现', 'book', '', 0, 255, 'sys', 1),
(5, 'main', '兑换', 'exchange', '', 0, 255, 'sys', 1),
(6, 'bottom', '专辑', 'album', '', 0, 255, 'sys', 1),
(7, 'bottom', '集市', 'cate', '?m=book&a=cate&cid=1', 0, 255, '', 1),
(8, 'bottom', '兑换', 'exchange', '', 0, 255, 'sys', 1);

-- --------------------------------------------------------

--
-- 表的结构 `pin_oauth`
--

CREATE TABLE IF NOT EXISTS `pin_oauth` (
  `id` smallint(4) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `config` text NOT NULL,
  `desc` text NOT NULL,
  `author` varchar(50) NOT NULL,
  `ordid` tinyint(3) unsigned NOT NULL DEFAULT '255',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- 转存表中的数据 `pin_oauth`
--

INSERT INTO `pin_oauth` (`id`, `code`, `name`, `config`, `desc`, `author`, `ordid`, `status`) VALUES
(4, 'qq', 'QQ登录', 'a:2:{s:7:"app_key";s:9:"100330010";s:10:"app_secret";s:32:"098381fd5d6a89f44127d61f0f2645da";}', '申请地址：http://connect.opensns.qq.com/', 'PinPHP TEAM', 2, 1),
(7, 'sina', '微博登陆', 'a:2:{s:7:"app_key";s:10:"3115666660";s:10:"app_secret";s:32:"e59677c031210b6d063a2661b6a895cf";}', '申请地址：http://open.weibo.com/', 'PinPHP TEAM', 1, 1),
(8, 'taobao', '淘宝登录', 'a:2:{s:7:"app_key";s:8:"21270789";s:10:"app_secret";s:32:"0c28536510e0b0b429750f478222d549";}', '申请地址：http://open.taobao.com/', 'PinPHP TEAM', 3, 1);

-- --------------------------------------------------------

--
-- 表的结构 `pin_score_item`
--

CREATE TABLE IF NOT EXISTS `pin_score_item` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cate_id` smallint(4) unsigned NOT NULL,
  `title` varchar(120) NOT NULL,
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0：实物；1：虚拟',
  `img` varchar(255) NOT NULL,
  `score` int(10) unsigned NOT NULL DEFAULT '0',
  `stock` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `user_num` mediumint(8) unsigned NOT NULL DEFAULT '1',
  `buy_num` mediumint(8) NOT NULL DEFAULT '0',
  `desc` text NOT NULL,
  `ordid` tinyint(3) unsigned NOT NULL DEFAULT '255',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `pin_score_item_cate`
--

CREATE TABLE IF NOT EXISTS `pin_score_item_cate` (
  `id` smallint(4) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `ordid` tinyint(3) unsigned NOT NULL DEFAULT '255',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- 转存表中的数据 `pin_score_item_cate`
--

INSERT INTO `pin_score_item_cate` (`id`, `name`, `status`, `ordid`) VALUES
(1, '数码', 1, 0),
(2, '美容', 1, 0),
(3, '虚拟', 1, 0),
(4, '生活', 1, 0),
(5, '运动', 1, 0),
(6, '吃完', 1, 0);

-- --------------------------------------------------------

--
-- 表的结构 `pin_score_log`
--

CREATE TABLE IF NOT EXISTS `pin_score_log` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL,
  `uname` varchar(50) NOT NULL,
  `action` varchar(50) NOT NULL,
  `score` int(10) NOT NULL,
  `add_time` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

--
-- 转存表中的数据 `pin_score_log`
--

INSERT INTO `pin_score_log` (`id`, `uid`, `uname`, `action`, `score`, `add_time`) VALUES
(1, 9, 'wingsa区', 'login', 10, 1353909837),
(2, 13, '想太多妹子', 'login', 10, 1353909897),
(3, 16, 'Eudora_寻寻', 'login', 10, 1353909964),
(4, 15, 'Prickleman', 'login', 10, 1353910012),
(5, 11, '彩色淘', 'login', 10, 1353910069),
(6, 7, '咕咕是一只猫', 'login', 10, 1353910109),
(7, 12, '跳房子123', 'login', 10, 1353910146),
(8, 17, 'V小莲小莲V', 'login', 10, 1353910177),
(9, 20, '熊小熊zz', 'login', 10, 1353910221),
(10, 6, '起个名字太累', 'login', 10, 1353910265),
(11, 18, '晨雪熙', 'login', 10, 1353910348),
(12, 8, '枕水而眠', 'login', 10, 1353910407),
(13, 19, '安土桃山', 'login', 10, 1353910445),
(14, 10, '设计系小女生', 'login', 10, 1353910499),
(15, 14, '泡芙小米粒', 'login', 10, 1353910539);

-- --------------------------------------------------------

--
-- 表的结构 `pin_score_order`
--

CREATE TABLE IF NOT EXISTS `pin_score_order` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_sn` varchar(100) NOT NULL,
  `uid` int(10) unsigned NOT NULL,
  `uname` varchar(20) NOT NULL,
  `item_id` int(10) unsigned NOT NULL,
  `item_name` varchar(120) NOT NULL,
  `item_num` mediumint(8) NOT NULL,
  `consignee` varchar(20) NOT NULL,
  `address` varchar(255) NOT NULL,
  `zip` varchar(10) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `order_score` int(10) NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `add_time` int(10) unsigned NOT NULL,
  `remark` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `pin_setting`
--

CREATE TABLE IF NOT EXISTS `pin_setting` (
  `name` varchar(100) NOT NULL,
  `data` text NOT NULL,
  `remark` varchar(255) NOT NULL,
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `pin_setting`
--

INSERT INTO `pin_setting` (`name`, `data`, `remark`) VALUES
('site_name', '拼品网', ''),
('site_title', 'pinphp', ''),
('site_keyword', 'pinphp', ''),
('site_description', 'pinphp', ''),
('site_status', '1', ''),
('closed_reason', '网站升级中。。', ''),
('site_icp', '浙ICP备10202542号', ''),
('statistics_code', '', ''),
('statics_url', '', ''),
('mail_server', '', ''),
('item_check', '0', ''),
('score_rule', 'a:16:{s:8:"register";s:2:"20";s:13:"register_nums";s:1:"1";s:5:"login";s:2:"10";s:10:"login_nums";s:1:"5";s:7:"pubitem";s:2:"20";s:12:"pubitem_nums";s:2:"10";s:8:"likeitem";s:1:"1";s:13:"likeitem_nums";s:2:"20";s:9:"joinalbum";s:1:"2";s:14:"joinalbum_nums";s:2:"10";s:6:"fwitem";s:1:"2";s:11:"fwitem_nums";s:2:"10";s:6:"pubcmt";s:1:"1";s:11:"pubcmt_nums";s:1:"5";s:7:"delitem";s:3:"-20";s:12:"delitem_nums";s:3:"100";}', ''),
('album_cover_items', '5', '专辑封面显示图片数量'),
('integrate_code', 'default', ''),
('integrate_config', '', ''),
('hot_tags', '家居,花园,美食,旅行,创意,建筑,户外,飘窗,卧室,城堡,DIY,萌宠,门厅,衣帽间,婚礼,书房,厨房,客厅,浴室,阳台,工作台,收纳,餐厅,阁楼,儿童房,小空间,性感', ''),
('wall_spage_max', '3', ''),
('wall_spage_size', '10', ''),
('book_page_max', '100', ''),
('default_keyword', '懒得逛了，我搜~', ''),
('album_default_title', '默认专辑', ''),
('avatar_size', '24,32,48,64,100,200', ''),
('attr_allow_exts', 'jpg,gif,png,jpeg,swf', ''),
('attr_allow_size', '2048', ''),
('itemcate_img', 'a:2:{s:5:"width";s:3:"150";s:6:"height";s:3:"170";}', ''),
('reg_protocol', '一、总则\r\n1．1　用户应当同意本协议的条款并按照页面上的提示完成全部的注册程序。用户在进行注册程序过程中点击"立即注册"按钮即表示用户与拼品网公司达成协议，完全接受本协议项下的全部条款。\r\n1．2　用户注册成功后，拼品网将给予每个用户一个用户帐号及相应的密码，该用户帐号和密码由用户负责保管；用户应当对以其用户帐号进行的所有活动和事件负法律责任。\r\n1．3　用户可以使用拼品网各个频道单项服务，当用户使用拼品网各单项服务时，用户的使用行为视为其对该单项服务的服务条款以及拼品网在该单项服务中发出的各类公告的同意。\r\n1．4　拼品网会员服务协议以及各个频道单项服务条款和公告可由拼品网公司随时更新，且无需另行通知。您在使用相关服务时,应关注并遵守其所适用的相关条款。\r\n您在使用拼品网提供的各项服务之前，应仔细阅读本服务协议。如您不同意本服务协议及/或随时对其的修改，您可以主动取消拼品网提供的服务；您一旦使用拼品网产品，即视为您已了解并完全同意本服务协议各项内容，包括拼品网对服务协议随时所做的任何修改，并成为拼品网用户。\r\n二、注册信息和隐私保护\r\n2．1　 拼品网帐号（即拼品网用户ID）的所有权归拼品网，用户完成注册申请手续后，获得拼品网帐号的使用权。用户应提供及时、详尽及准确的个人资料，并不断更新注册资料，符合及时、详尽准确的要求。所有原始键入的资料将引用为注册资料。如果因注册信息不真实而引起的问题，并对问题发生所带来的后果，拼品网概不负任何责任。\r\n2．2　用户不应将其帐号、密码转让或出借予他人使用。如用户发现其帐号遭他人非法使用，应立即通知拼品网。因黑客行为或用户的保管疏忽导致帐号、密码遭他人非法使用，拼品网不承担任何责任。\r\n2．3　拼品网不对外公开或向第三方提供单个用户的注册资料，除非：\r\n（1）事先获得用户的明确授权；\r\n（2）只有透露你的个人资料，才能提供你所要求的产品和服务；\r\n（3）根据有关的法律法规要求；\r\n（4）按照相关政府主管部门的要求；\r\n（5）为维护拼品网的合法权益。\r\n2．4　在你注册拼品网帐户，使用其他拼品网产品或服务，访问拼品网网页, 或参加促销和有奖游戏时，拼品网会收集你的个人身份识别资料，并会将这些资料用于：改进为你提供的服务及网页内容。\r\n三、使用规则\r\n3．1　用户在使用拼品网服务时，必须遵守中华人民共和国相关法律法规的规定，用户应同意将不会利用本服务进行任何违法或不正当的活动，包括但不限于下列行为∶\r\n（1）上载、展示、张贴、传播或以其它方式传送含有下列内容之一的信息：\r\n1） 反对宪法所确定的基本原则的； 2） 危害国家安全，泄露国家秘密，颠覆国家政权，破坏国家统一的； 3） 损害国家荣誉和利益的； 4） 煽动民族仇恨、民族歧视、破坏民族团结的； 5） 破坏国家宗教政策，宣扬邪教和封建迷信的； 6） 散布谣言，扰乱社会秩序，破坏社会稳定的； 7） 散布淫秽、色情、赌博、暴力、凶杀、恐怖或者教唆犯罪的； 8） 侮辱或者诽谤他人，侵害他人合法权利的； 9） 含有虚假、有害、胁迫、侵害他人隐私、骚扰、侵害、中伤、粗俗、猥亵、或其它道德上令人反感的内容； 10） 含有中国法律、法规、规章、条例以及任何具有法律效力之规范所限制或禁止的其它内容的；\r\n（2）不得为任何非法目的而使用网络服务系统；\r\n（3）不利用拼品网服务从事以下活动：\r\n1) 未经允许，进入计算机信息网络或者使用计算机信息网络资源的；\r\n2) 未经允许，对计算机信息网络功能进行删除、修改或者增加的；\r\n3) 未经允许，对进入计算机信息网络中存储、处理或者传输的数据和应用程序进行删除、修改或者增加的；\r\n4) 故意制作、传播计算机病毒等破坏性程序的；\r\n5) 其他危害计算机信息网络安全的行为。\r\n3．2　 用户违反本协议或相关的服务条款的规定，导致或产生的任何第三方主张的任何索赔、要求或损失，包括合理的律师费，您同意赔偿拼品网与合作公司、关联公司，并使之免受损害。对此，拼品网有权视用户的行为性质，采取包括但不限于删除用户发布信息内容、暂停使用许可、终止服务、限制使用、回收拼品网帐号、追 究法律责任等措施。对恶意注册拼品网帐号或利用拼品网帐号进行违法活动、捣乱、骚扰、欺骗、其他用户以及其他违反本协议的行为，拼品网有权回收其帐号。同 时，拼品网公司会视司法部门的要求，协助调查。\r\n3．3　用户不得对本服务任何部分或本服务之使用或获得，进行复制、拷贝、出售、转售或用于任何其它商业目的。\r\n3．4　用户须对自己在使用拼品网服务过程中的行为承担法律责任。用户承担法律责任的形式包括但不限于：对受到侵害者进行赔偿，以及在拼品网公司首先承担了因用户行为导致的行政处罚或侵权损害赔偿责任后，用户应给予拼品网公司等额的赔偿。\r\n四、服务内容\r\n4．1　拼品网网络服务的具体内容由拼品网根据实际情况提供。\r\n4．2　除非本服务协议另有其它明示规定，拼品网所推出的新产品、新功能、新服务，均受到本服务协议之规范。\r\n4．3　为使用本服务，您必须能够自行经有法律资格对您提供互联网接入服务的第三方，进入国际互联网，并应自行支付相关服务费用。此外，您必须自行配备及负责与国际联网连线所需之一切必要装备，包括计算机、数据机或其它存取装置。\r\n4．4　鉴于网络服务的特殊性，用户同意拼品网有权不经事先通知，随时变更、中断或终止部分或全部的网络服务（包括收费网络服务）。拼品网不担保网络服务不会中断，对网络服务的及时性、安全性、准确性也都不作担保。\r\n4．5　拼品网需要定期或不定期地对提供网络服务的平台或相关的设备进行检修或者维护，如因此类情况而造成网络服务（包括收费网络服务）在合理时间内的中断，拼品网无需为此承担任何责任。拼品网保留不经事先通知为维修保养、升级或其它目的暂停本服务任何部分的权利。\r\n4．6　 本服务或第三人可提供与其它国际互联网上之网站或资源之链接。由于拼品网无法控制这些网站及资源，您了解并同意，此类网站或资源是否可供利用，拼品网不予负责，存在或源于此类网站或资源之任何内容、广告、产品或其它资料，拼品网亦不予保证或负责。因使用或依赖任何此类网站或资源发布的或经由此类网站或资 源获得的任何内容、商品或服务所产生的任何损害或损失，拼品网不承担任何责任。\r\n4．7　用户明确同意其使用拼品网网络服务所存在的风险将完全由其 自己承担。用户	理解并接受下载或通过拼品网服务取得的任何信息资料取决于用户自己，并由其承担系统受损、资料丢失以及其它任何风险。拼品网对在服务网上得 到的任何商品购物服	务、交易进程、招聘信息，都不作担保。\r\n4．8　3个月未登录的帐号，拼品网保留关闭的权利。\r\n4．9　拼品网有权于任何时间暂时或永久修改或终止本服务（或其任何部分），而无论其通知与否，拼品网对用户和任何第三人均无需承担任何责任。\r\n4．10　终止服务\r\n您同意拼品网得基于其自行之考虑，因任何理由，包含但不限于长时间未使用，或拼品网认为您已经违反本服务协议的文字及精神，终止您的密码、帐号或本服务之使 用（或服务之任何部分），并将您在本服务内任何内容加以移除并删除。您同意依本服务协议任何规定提供之本服务，无需进行事先通知即可中断或终止，您承认并 同意，拼品网可立即关闭或删除您的帐号及您帐号中所有相关信息及文件，及/或禁止继续使用前述文件或本服务。此外，您同意若本服务之使用被中断或终止或您 的帐号及相关信息和文件被关闭或删除，拼品网对您或任何第三人均不承担任何责任。\r\n五、知识产权和其他合法权益（包括但不限于名誉权、商誉权）\r\n5．1　用户专属权利\r\n拼品网尊重他人知识产权和合法权益，呼吁用户也要同样尊重知识产权和他人合法权益。若您认为您的知识产权或其他合法权益被侵犯，请按照以下说明向拼品网提供资料∶\r\n请注意：如果权利通知的陈述失实，权利通知提交者将承担对由此造成的全部法律责任（包括但不限于赔偿各种费用及律师费）。如果上述个人或单位不确定网络上可获取的资料是否侵犯了其知识产权和其他合法权益，拼品网建议该个人或单位首先咨询专业人士。\r\n为了拼品网有效处理上述个人或单位的权利通知，请使用以下格式（包括各条款的序号）：\r\n1. 权利人对涉嫌侵权内容拥有知识产权或其他合法权益和/或依法可以行使知识产权或其他合法权益的权属证明；\r\n2. 请充分、明确地描述被侵犯了知识产权或其他合法权益的情况并请提供涉嫌侵权的第三方网址（如果有）。\r\n3. 请指明涉嫌侵权网页的哪些内容侵犯了第2项中列明的权利。\r\n4. 请提供权利人具体的联络信息，包括姓名、身份证或护照复印件（对自然人）、单位登记证明复印件（对单位）、通信地址、电话号码、传真和电子邮件。\r\n5. 请提供涉嫌侵权内容在信息网络上的位置（如指明您举报的含有侵权内容的出处，即：指网页地址或网页内的位置）以便我们与您举报的含有侵权内容的网页的所有权人/管理人联系。\r\n5．1　 对于用户通过拼品网服务上传到拼品网网站上可公开获取区域的任何内容，用户同意拼品网在全世界范围内具有免费的、永久性的、不可撤销的、非独家的和完全再许可的权利和许可，以使用、复制、修改、改编、出版、翻译、据以创作衍生作品、传播、表演和展示此等内容（整体或部分），和/或将此等内容编入当前已知 的或以后开发的其他任何形式的作品、媒体或技术中。\r\n5．2　拼品网拥有本网站内所有资料的版权。任何被授权的浏览、复制、打印和传播属于本网站内的资料必须符合以下条件：所有的资料和图象均以获得信息为目的；\r\n所有的资料和图象均不得用于商业目的；\r\n所有的资料、图象及其任何部分都必须包括此版权声明；\r\n本网站（www.pinphp.com）所有的产品、技术与所有程序均属于拼品网知识产权，在此并未授权。\r\n“www.pinphp.com”, “拼品网”及相关图形等为拼品网的注册商标。\r\n未经拼品网许可，任何人不得擅自（包括但不限于：以非法的方式复制、传播、展示、镜像、上载、下载）使用。否则，拼品网将依法追究法律责任。\r\n六、青少年用户特别提示\r\n青少年用户必须遵守全国青少年网络文明公约：\r\n要善于网上学习，不浏览不良信息；要诚实友好交流，不侮辱欺诈他人；要增强自护意识，不随意约会网友；要维护网络安全，不破坏网络秩序；要有益身心健康，不沉溺虚拟时空。\r\n七、其他\r\n7．1　本协议的订立、执行和解释及争议的解决均应适用中华人民共和国法律。\r\n7．2　如双方就本协议内容或其执行发生任何争议，双方应尽量友好协商解决；协商不成时，任何一方均可向拼品网所在地的人民法院提起诉讼。\r\n7．3　拼品网未行使或执行本服务协议任何权利或规定，不构成对前述权利或权利之放弃。\r\n7．4　如本协议中的任何条款无论因何种原因完全或部分无效或不具有执行力，本协议的其余条款仍应有效并且有约束力。\r\n拼品网对本使用协议享有最终解释权。', ''),
('item_cover_comments', '2', ''),
('user_intro_default', '这个家伙太懒，什么都木留下~', ''),
('ipban_switch', '1', ''),
('score_item_img', 'a:4:{s:6:"swidth";s:3:"210";s:7:"sheight";s:3:"210";s:6:"bwidth";s:3:"350";s:7:"bheight";s:3:"350";}', ''),
('seo_config', 'a:6:{s:4:"book";a:3:{s:5:"title";s:23:"{tag_name}-{site_title}";s:8:"keywords";s:23:"逛宝贝，{site_name}";s:11:"description";s:18:"{site_description}";}s:4:"cate";a:3:{s:5:"title";s:23:"{cate_name}-{seo_title}";s:8:"keywords";s:14:"{seo_keywords}";s:11:"description";s:17:"{seo_description}";}s:5:"album";a:3:{s:5:"title";s:6:"专辑";s:8:"keywords";s:47:"{site_name},购物分享,淘宝网购物,专辑";s:11:"description";s:18:"{site_description}";}s:10:"album_cate";a:3:{s:5:"title";s:11:"{seo_title}";s:8:"keywords";s:14:"{seo_keywords}";s:11:"description";s:17:"{seo_description}";}s:12:"album_detail";a:3:{s:5:"title";s:13:"{album_title}";s:8:"keywords";s:13:"{album_intro}";s:11:"description";s:23:"杂志详细Description";}s:4:"item";a:3:{s:5:"title";s:12:"{item_title}";s:8:"keywords";s:10:"{item_tag}";s:11:"description";s:12:"{item_intro}";}}', ''),
('item_img', 'a:2:{s:5:"width";s:3:"210";s:6:"height";s:4:"1000";}', ''),
('item_simg', 'a:2:{s:5:"width";s:3:"100";s:6:"height";s:3:"100";}', ''),
('item_bimg', 'a:2:{s:5:"width";s:3:"468";s:6:"height";s:4:"1000";}', ''),
('attach_path', 'data/upload/', ''),
('wall_distance', '500', ''),
('reg_status', '1', ''),
('reg_closed_reason', '<h1>暂时关闭注册</h1>', ''),
('index_wall', '1', '');

-- --------------------------------------------------------

--
-- 表的结构 `pin_tag`
--

CREATE TABLE IF NOT EXISTS `pin_tag` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=437 ;

--
-- 转存表中的数据 `pin_tag`
--

INSERT INTO `pin_tag` (`id`, `name`) VALUES
(1, '外套'),
(2, '毛衣'),
(3, 'T恤'),
(4, '西装'),
(5, '风衣'),
(6, '卫衣'),
(7, '马甲'),
(8, '牛仔裤'),
(9, '小脚裤'),
(10, '哈伦裤'),
(11, '打底裤'),
(12, '五分裤'),
(13, '蕾丝'),
(14, '牛仔'),
(15, '打底'),
(16, '镂空'),
(17, '拼接'),
(18, '紧身'),
(19, '格子'),
(20, '水洗'),
(21, '高腰'),
(22, '磨旧'),
(23, '宽松'),
(24, '清新'),
(25, '欧美'),
(26, '韩系'),
(27, '甜美'),
(28, '复古'),
(29, '简约'),
(30, '英伦'),
(31, '珊瑚绒'),
(32, '莫代尔'),
(33, '纯棉'),
(34, '全棉'),
(35, '毛呢'),
(36, '针织'),
(37, '毛绒'),
(38, '雪纺'),
(39, '黑色'),
(40, '黄色'),
(41, '绿色'),
(42, '红色'),
(43, '粉色'),
(44, '紫色'),
(45, '白色'),
(46, '蓝色'),
(47, '翻领'),
(48, '毛呢大衣'),
(49, '冬装'),
(50, '专柜'),
(51, '正品'),
(52, '新款'),
(53, '一身'),
(54, '浪漫'),
(55, '韩版大'),
(56, '纯色'),
(57, '短外套'),
(58, '羊毛'),
(59, '秋装'),
(60, '球衫'),
(61, '立领'),
(62, '修身'),
(63, '长袖'),
(64, '麂皮'),
(65, '加厚'),
(66, '棉质'),
(67, '蝙蝠'),
(68, '休闲'),
(69, '带帽'),
(70, '棉衣'),
(71, '袋鼠'),
(72, '拉链'),
(73, '街头'),
(74, '女装'),
(75, '春秋'),
(76, '宣言'),
(77, '1016111'),
(78, '开衫'),
(79, '短款'),
(80, '运动休闲'),
(81, '通勤'),
(82, '亮色'),
(83, '时尚'),
(84, '胸花'),
(85, '线下'),
(86, '春装'),
(87, '夹克'),
(88, '中长'),
(89, '双排'),
(90, '小西装'),
(91, '帅气'),
(92, '无袖'),
(93, '皱褶'),
(94, '品牌女装'),
(95, '夏装'),
(96, '低跟鞋'),
(97, '细跟鞋'),
(98, '牛津鞋'),
(99, '中跟鞋'),
(100, '染发膏'),
(101, '单鞋'),
(102, '蓬蓬粉'),
(103, '发膜'),
(104, '粗跟鞋'),
(105, '弹力素'),
(106, '坡跟鞋'),
(107, '发蜡'),
(108, '平底鞋'),
(109, '马丁靴'),
(110, '假发'),
(111, '高跟鞋'),
(112, '护手霜'),
(113, '短靴'),
(114, '身体乳'),
(115, '美颈霜'),
(116, '沐浴露'),
(117, '手工皂'),
(118, '眼线膏'),
(119, '唇彩'),
(120, '眉笔'),
(121, '眼影'),
(122, '腮红'),
(123, '口红'),
(124, '蜜粉'),
(125, '粉饼'),
(126, 'BB霜'),
(127, '睫毛膏'),
(128, '指甲油'),
(129, '香水'),
(130, '药妆'),
(131, '吸油面纸'),
(132, '隔离霜'),
(133, '精油'),
(134, '爽肤水'),
(135, '眼霜'),
(136, '面膜'),
(137, '床上用品'),
(138, '洗面奶'),
(139, '卸妆油'),
(140, '喷雾'),
(141, '防晒霜'),
(142, '补水'),
(143, '控油'),
(144, '美白'),
(145, '遮瑕'),
(146, '去角质'),
(147, '祛痘'),
(148, '保湿'),
(149, '洁面'),
(150, '去黑头'),
(151, '收毛孔'),
(152, '去眼袋'),
(153, '倩碧'),
(154, '雅漾'),
(155, '资生堂'),
(156, '娇韵诗'),
(157, '欧舒丹'),
(158, '兰蔻'),
(159, '水宝宝'),
(160, '雅诗兰黛'),
(161, '丝芙兰'),
(162, '露得清'),
(163, '收纳'),
(164, '台灯'),
(165, '时钟'),
(166, '吊灯'),
(167, '吸顶灯'),
(168, '杯子'),
(169, '置物架'),
(170, '香薰'),
(171, '地毯'),
(172, '落地灯'),
(173, '桌布'),
(174, '摆件'),
(175, '墙贴'),
(176, '烛台'),
(177, '书柜'),
(178, '储物罐'),
(179, '烹饪'),
(180, '烘焙'),
(181, '锅具'),
(182, '饭盒'),
(183, '筷子'),
(184, '勺'),
(185, '茶具'),
(186, '水壶'),
(187, '盘碟'),
(188, '调味瓶'),
(189, '餐巾'),
(190, '餐垫'),
(191, '梳妆'),
(192, '家居鞋'),
(193, '窗帘'),
(194, '斗柜'),
(195, '衣柜'),
(196, '床头柜'),
(197, '茶几'),
(198, '搁板'),
(199, '电视柜'),
(200, '椅子'),
(201, '桌子'),
(202, '坐垫'),
(203, '沙发垫'),
(204, '照片墙'),
(205, '相框'),
(206, '沙发'),
(207, '挂钩'),
(208, '马桶刷'),
(209, '衣架'),
(210, '皂盒'),
(211, '浴室垫'),
(212, '浴室套件'),
(213, '浴帘'),
(214, '毛巾'),
(215, '袜套'),
(216, '电子表'),
(217, '邮差'),
(218, '单肩包'),
(219, '女包'),
(220, '真皮'),
(221, '英国'),
(222, '小包'),
(223, '牛皮'),
(224, '信封'),
(225, '包邮'),
(226, '单肩'),
(227, '斜挎'),
(228, '女士'),
(229, '学院'),
(230, 'MIYI'),
(231, '剑桥'),
(232, '糖果'),
(233, '链条'),
(234, '宴会'),
(235, '秋冬'),
(236, '2012'),
(237, '斜挎包'),
(238, '大包'),
(239, '包包'),
(240, '特价'),
(241, '手提包'),
(242, '挎包'),
(243, '清仓'),
(244, '购物'),
(245, '古风'),
(246, '机车包'),
(247, '手提'),
(248, '鸵鸟'),
(249, '单肩斜跨'),
(250, '可爱'),
(251, '斜纹'),
(252, '晚宴'),
(253, '新娘'),
(254, '结婚'),
(255, '卡其色'),
(256, '米逸'),
(257, '手包'),
(258, '鳄鱼纹'),
(259, '复古包'),
(260, '翻盖'),
(261, '水桶'),
(262, '韩版'),
(263, '简约主义'),
(264, 'MIYI2012'),
(265, '漆皮'),
(266, '磨砂'),
(267, '发带'),
(268, '礼帽'),
(269, '锁骨链'),
(270, '鸭舌帽'),
(271, '贝雷帽'),
(272, '呢大衣'),
(273, '榴莲'),
(274, '秋冬装'),
(275, '预售'),
(276, '气质'),
(277, '20281'),
(278, '特卖'),
(279, 'LLS1009'),
(280, '秋季'),
(281, '20072'),
(282, '韩版波'),
(283, 'RENEEVON'),
(284, '公主'),
(285, '20398'),
(286, '肩章'),
(287, '牛角'),
(288, '定金'),
(289, '假领'),
(290, '发饰'),
(291, '脚链'),
(292, '腰链'),
(293, '手镯'),
(294, '手链'),
(295, '耳环'),
(296, '戒指'),
(297, '耳钉'),
(298, '高帮'),
(299, '松糕'),
(300, '帆布鞋'),
(301, '休闲鞋'),
(302, '帆布'),
(303, '女式'),
(304, '鞋子'),
(305, '学生'),
(306, '韩版潮'),
(307, '女款'),
(308, '系带'),
(309, '金币'),
(310, '情侣'),
(311, '经典'),
(312, '男女'),
(313, '学生鞋'),
(314, '印花'),
(315, '星星'),
(316, '越狱'),
(317, '米勒'),
(318, '松糕鞋'),
(319, '系列'),
(320, 'ca276'),
(321, '星旗'),
(322, '条纹'),
(323, '高帮鞋'),
(324, '女鞋'),
(325, '高鞋'),
(326, '韩版厚'),
(327, '秋冬季'),
(328, '子学'),
(329, '布鞋'),
(330, '项链'),
(331, '平底'),
(332, '雪地靴'),
(333, '棉鞋'),
(334, '冬季'),
(335, '2011'),
(336, '墨镜'),
(337, '钥匙链'),
(338, '腰带'),
(339, '手套'),
(340, '头花'),
(341, '毛衣链'),
(342, '瘦腿袜'),
(343, '发箍'),
(344, '手表'),
(345, '帽子'),
(346, '围巾'),
(347, '哥特'),
(348, '个性'),
(349, '朋克'),
(350, '花朵'),
(351, '玉'),
(352, '24K金'),
(353, '水晶'),
(354, '玫瑰金'),
(355, '银饰'),
(356, '马鞍包'),
(357, '相机包'),
(358, '信封包'),
(359, '剑桥包'),
(360, '豆豆鞋'),
(361, '运动鞋'),
(362, '厚底鞋'),
(363, '工装鞋'),
(364, '长靴'),
(365, '复古鞋'),
(366, '马靴'),
(367, '布洛克鞋'),
(368, '及裸靴'),
(369, '细跟'),
(370, '圆头'),
(371, '铆钉'),
(372, '豹纹'),
(373, '粉红'),
(374, '玫红'),
(375, '深红'),
(376, '防水台'),
(377, '防水'),
(378, '流苏'),
(379, '粗跟'),
(380, '尖头'),
(381, '坡跟'),
(382, '厚底'),
(383, '撞色'),
(384, '优雅'),
(385, '名媛'),
(386, '百搭'),
(387, '医生包'),
(388, '笑脸包'),
(389, '波士顿包'),
(390, '邮差包'),
(391, '行李箱'),
(392, '水桶包'),
(393, '帆布包'),
(394, '链条包'),
(395, '手拿包'),
(396, '钱包'),
(397, '双肩包'),
(398, '代购'),
(399, '菱形格'),
(400, '菱形'),
(401, '外贸'),
(402, '金属'),
(403, '透明'),
(404, '棉麻'),
(405, '羊皮'),
(406, 'PU'),
(407, '灰黑'),
(408, '兰色'),
(409, '浅蓝'),
(410, '深蓝'),
(411, '淡蓝'),
(412, '果绿'),
(413, '浅绿'),
(414, '深绿'),
(415, '深紫'),
(416, '灰白'),
(417, '浅黄'),
(418, '米黄'),
(419, '跟鞋'),
(420, '南非'),
(421, '柠檬'),
(422, '进口'),
(423, '智利'),
(424, '蓝莓'),
(425, '新鲜'),
(426, '美国'),
(427, '红提'),
(428, '无籽'),
(429, '1kg'),
(430, '奇异'),
(431, '国产'),
(432, '蜜桔'),
(433, '无核'),
(434, '涌泉'),
(435, '桔子'),
(436, '浙江');

-- --------------------------------------------------------

--
-- 表的结构 `pin_topic`
--

CREATE TABLE IF NOT EXISTS `pin_topic` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `uname` varchar(20) NOT NULL,
  `content` varchar(255) NOT NULL,
  `extra` text NOT NULL,
  `src_type` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '引用内容类型',
  `src_id` int(10) unsigned NOT NULL COMMENT '引用内容ID',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '0，原创；1，转发；',
  `comments` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '评论数量',
  `forwards` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '转发数量',
  `add_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=69 ;

--
-- 转存表中的数据 `pin_topic`
--

INSERT INTO `pin_topic` (`id`, `uid`, `uname`, `content`, `extra`, `src_type`, `src_id`, `type`, `comments`, `forwards`, `add_time`) VALUES
(1, 14, '泡芙小米粒', '浪漫一身 2012冬装新款 专柜正品 韩版大翻领格纹毛呢大衣外套', 'http://img03.taobaocdn.com/bao/uploaded/i3/T1o2R8XdRtXXcjNLgV_020417.jpg', 0, 1, 0, 0, 0, 1353896347),
(2, 10, '设计系小女生', '浪漫一身 2012冬装新款 专柜正品 欧美范 羊毛毛纯色呢短外套', 'http://img03.taobaocdn.com/bao/uploaded/i3/T1L.urXiFJXXa2x2w2_043755.jpg', 0, 2, 0, 0, 0, 1353896347),
(3, 19, '安土桃山', '浪漫一身 2012秋装新款 专柜正品 休闲长袖薄外套修身立领棒球衫', 'http://img01.taobaocdn.com/bao/uploaded/i1/T1FGLNXmJbXXbjSLvb_093718.jpg', 0, 3, 0, 0, 0, 1353896347),
(4, 8, '枕水而眠', '浪漫一身 2012冬装新款 欧美仿麂皮翻领长袖 修身加厚短外套', 'http://img02.taobaocdn.com/bao/uploaded/i2/T1Fw5FXmxmXXc2RowZ_034012.jpg', 0, 4, 0, 0, 0, 1353896347),
(5, 8, '枕水而眠', '浪漫一身 2012秋装新款 韩版蝙蝠袖长袖 假两件休闲棉质马甲外套', 'http://img04.taobaocdn.com/bao/uploaded/i4/T1tmvLXnhmXXXxzzQW_024228.jpg', 0, 5, 0, 0, 0, 1353896347),
(6, 18, '晨雪熙', '浪漫一身  直筒带帽休闲加薄长款棉衣外套', 'http://img01.taobaocdn.com/bao/uploaded/i1/T1dmCzXaxgXXcNQv71_040909.jpg', 0, 6, 0, 0, 0, 1353896348),
(7, 6, '起个名字太累', '浪漫一身 2012秋装新款 修身街头运动 拉链带帽拼接袋鼠兜短外套', 'http://img01.taobaocdn.com/bao/uploaded/i1/T1yhLQXnVqXXXEh_71_042519.jpg', 0, 7, 0, 0, 0, 1353896348),
(8, 18, '晨雪熙', '浪漫宣言新款春秋修身单扣长袖女装短外套1016111', 'http://img03.taobaocdn.com/bao/uploaded/i3/T1ssGRXeVoXXXa7CQ5_060120.jpg', 0, 8, 0, 0, 0, 1353896348),
(9, 20, '熊小熊zz', '浪漫一身 2012秋装新款 专柜正品 韩版蝙蝠袖西装式针织开衫外套', 'http://img01.taobaocdn.com/bao/uploaded/i1/T1hP1mXjRrXXcK2PU3_050554.jpg', 0, 9, 0, 0, 0, 1353896348),
(10, 8, '枕水而眠', '浪漫一身 2012秋装新款 直筒运动休闲长袖 短款立领拉链纯色外套', 'http://img01.taobaocdn.com/bao/uploaded/i1/T1As6HXiBmXXcXtaPb_093121.jpg', 0, 10, 0, 0, 0, 1353896348),
(11, 18, '晨雪熙', '浪漫一身 2012秋装新款 宽松加厚运动休闲 带拉链连帽毛衣外套', 'http://img01.taobaocdn.com/bao/uploaded/i1/T1_fvTXbdjXXc3i8E1_042214.jpg', 0, 11, 0, 0, 0, 1353896348),
(12, 20, '熊小熊zz', '浪漫一身 2012冬装新款 专柜正品 通勤简约 柳钉拼接时尚短外套', 'http://img04.taobaocdn.com/bao/uploaded/i4/T1vdvYXktiXXb1Opc__104853.jpg', 0, 12, 0, 0, 0, 1353896348),
(13, 14, '泡芙小米粒', '浪漫一身 2012秋装新款 专柜正品 亮色带帽长袖休闲格子外套', 'http://img02.taobaocdn.com/bao/uploaded/i2/T1h4F7XbdAXXce_eEZ_032143.jpg', 0, 13, 0, 0, 0, 1353896348),
(14, 14, '泡芙小米粒', '浪漫一身 2012秋装新款 通勤OL开衫V领长袖 纯色百搭时尚小外套', 'http://img04.taobaocdn.com/bao/uploaded/i4/T1qdnCXlBhXXbCT873_051140.jpg', 0, 14, 0, 0, 0, 1353896349),
(15, 8, '枕水而眠', '浪漫一身 线下专柜正品 2012春装一粒扣短款西装 韩版胸花短外套', 'http://img01.taobaocdn.com/bao/uploaded/i1/T1QEO7XcBdXXXWXn.U_015911.jpg', 0, 15, 0, 0, 0, 1353896349),
(16, 18, '晨雪熙', '浪漫一身 线下 专柜正品 2012春装翻领长袖中长款 夹克风衣外套女', 'http://img02.taobaocdn.com/bao/uploaded/i2/T1DReVXjtbXXcISRE9_104415.jpg', 0, 16, 0, 0, 0, 1353896349),
(17, 10, '设计系小女生', '浪漫一身 2012秋装新款 线下 专柜正品 韩版双排扣风衣外套', 'http://img03.taobaocdn.com/bao/uploaded/i3/T1Xo6dXhptXXb5KSA9_104530.jpg', 0, 17, 0, 0, 0, 1353896349),
(18, 17, 'V小莲小莲V', '浪漫一身 2012秋装新款 通勤长袖翻领  OL时尚帅气小西装式短外套', 'http://img03.taobaocdn.com/bao/uploaded/i3/T1ms_UXi0bXXb4juQ1_041036.jpg', 0, 18, 0, 0, 0, 1353896349),
(19, 6, '起个名字太累', '浪漫一身 冬装 专柜正品 羊毛毛呢短外套  外套 女装长袖', 'http://img02.taobaocdn.com/bao/uploaded/i2/T1V_KxXkXuXXX2Qls4_053710.jpg', 0, 19, 0, 0, 0, 1353896349),
(20, 18, '晨雪熙', '浪漫一身 品牌女装 专柜正品 春夏装中长款抽皱褶无袖短外套', 'http://img01.taobaocdn.com/bao/uploaded/i1/T1vN18Xe8wXXabtx7U_014829.jpg', 0, 20, 0, 0, 0, 1353896349),
(21, 12, '跳房子123', 'MIYI 英国2013新款头层牛皮撞色真皮女包小包单肩包信封邮差包邮', 'http://img04.taobaocdn.com/bao/uploaded/i4/T1oAbZXkldXXcH5ug2_043616.jpg', 0, 21, 0, 0, 0, 1353902316),
(22, 7, '咕咕是一只猫', 'MIYI 2012英伦复古学院风牛皮撞色邮差包 时尚单肩斜挎潮包女士包', 'http://img02.taobaocdn.com/bao/uploaded/i2/T1qrdqXXlwXXa_4U38_101909.jpg', 0, 22, 0, 0, 0, 1353902316),
(23, 11, '彩色淘', 'MIYI 英伦学院风复古糖果色牛皮剑桥包 单肩包时尚女包 小包潮包', 'http://img03.taobaocdn.com/bao/uploaded/i3/T1yj1xXg01XXX_.NQ8_100702.jpg', 0, 23, 0, 0, 0, 1353902316),
(24, 11, '彩色淘', 'MIYI 2012新款秋冬头层牛皮女包菱格链条包单肩包 真皮女包宴会包', 'http://img02.taobaocdn.com/bao/uploaded/i2/T1DsrnXbRkXXanw8_b_124847.jpg', 0, 24, 0, 0, 0, 1353902316),
(25, 7, '咕咕是一只猫', 'MIYI 2012秋冬新款欧美时尚牛皮邮差包单肩斜挎包 复古百搭女大包', 'http://img01.taobaocdn.com/bao/uploaded/i1/T18U_SXklkXXcPno7._084022.jpg', 0, 25, 0, 0, 0, 1353902316),
(26, 15, 'Prickleman', 'MIYI秋冬新款牛皮复古OL通勤单肩斜挎女包包英伦潮款特价包邮', 'http://img04.taobaocdn.com/bao/uploaded/i4/T1_HC7XhlwXXbMVu7W_023330.jpg', 0, 26, 0, 0, 0, 1353902316),
(27, 11, '彩色淘', '【清仓】MIYI 简约手提包女包 单肩牛皮大包通勤包 购物包肩挎包', 'http://img03.taobaocdn.com/bao/uploaded/i3/T1rnuWXbXwXXaT3dnb_093439.jpg', 0, 27, 0, 0, 0, 1353902316),
(28, 8, '枕水而眠', 'MIYI 秋冬新款复古风撞色手提包单肩包斜挎包包 机车包邮差包女包', 'http://img01.taobaocdn.com/bao/uploaded/i1/T1sPfKXcxbXXXPQIYb_123402.jpg', 0, 28, 0, 0, 0, 1353902317),
(29, 16, 'Eudora_寻寻', 'MIYI 欧美鸵鸟纹头层牛皮单肩包斜跨复古女包邮差包 手提真皮女包', 'http://img04.taobaocdn.com/bao/uploaded/i4/T1gz6JXj8iXXblFxU8_100704.jpg', 0, 29, 0, 0, 0, 1353902317),
(30, 20, '熊小熊zz', 'MIYI时尚可爱复古学院风糖果色单肩斜跨女包包小包牛皮邮差包特价', 'http://img02.taobaocdn.com/bao/uploaded/i2/T1m397XXJlXXaqnVg0_033805.jpg', 0, 30, 0, 0, 0, 1353902317),
(31, 12, '跳房子123', 'MIYI 红色斜纹牛皮单肩包包女包 2012新款潮包结婚包新娘包晚宴包', 'http://img02.taobaocdn.com/bao/uploaded/i2/T1X697XjXbXXcMnfM._112229.jpg', 0, 31, 0, 0, 0, 1353902317),
(32, 12, '跳房子123', 'MIYI米逸 新款英伦小包卡其色单肩包复古牛皮撞色复古女包邮差包', 'http://img04.taobaocdn.com/bao/uploaded/i4/T1DxC8Xi4eXXXO8ZZ5_054947.jpg', 0, 32, 0, 0, 0, 1353902317),
(33, 14, '泡芙小米粒', 'MIYI新款鳄鱼纹翻盖潮手包牛皮女包单肩包复古包小包包 清仓包邮', 'http://img04.taobaocdn.com/bao/uploaded/i4/T1wBy7XflaXXX6UvwV_020442.jpg', 0, 33, 0, 0, 0, 1353902317),
(34, 10, '设计系小女生', 'MIYI 2012秋冬新款头层牛皮手提包单肩包水桶真皮女包通勤包包邮', 'http://img01.taobaocdn.com/bao/uploaded/i1/T1tWOuXmFTXXXbvKDb_093608.jpg', 0, 34, 0, 0, 0, 1353902317),
(35, 20, '熊小熊zz', 'MIYI单肩小包2012新款潮时尚韩版休闲牛皮欧美红色新娘手拿女包包', 'http://img01.taobaocdn.com/bao/uploaded/i1/T1xtK1XnlkXXaGp4E6_062100.jpg', 0, 35, 0, 0, 0, 1353902318),
(36, 6, '起个名字太累', 'MIYI韩版新款真皮女包包2012新款潮女包水桶通勤斜挎单肩机车包邮', 'http://img02.taobaocdn.com/bao/uploaded/i2/T1Ad58XctiXXcyC0s8_100130.jpg', 0, 36, 0, 0, 0, 1353902318),
(37, 13, '想太多妹子', 'MIYI 2012秋冬新款欧美头层牛皮单肩斜挎包 韩版真皮女包通勤包包', 'http://img02.taobaocdn.com/bao/uploaded/i2/T1O9mQXndwXXXD_O.0_035651.jpg', 0, 37, 0, 0, 0, 1353902318),
(38, 6, '起个名字太累', 'MIYI2012新款全牛皮简约主义韩版糖果女包包复古手提大包单肩包', 'http://img01.taobaocdn.com/bao/uploaded/i1/T17FtRXaBGXXa3dJs6_061244.jpg', 0, 38, 0, 0, 0, 1353902318),
(39, 17, 'V小莲小莲V', 'MIYI 鳄鱼纹晚宴包链条包单肩包 牛皮潮女包漆皮菱格包 清仓包邮', 'http://img01.taobaocdn.com/bao/uploaded/i1/T1h8HdXXXkXXcz7r.4_051921.jpg', 0, 39, 0, 0, 0, 1353902318),
(40, 20, '熊小熊zz', 'MIYI休闲糖果色邮差包韩版撞色单肩斜挎包磨砂牛皮复古包包女包', 'http://img04.taobaocdn.com/bao/uploaded/i4/T1.Ly7XmhmXXcoBArb_124637.jpg', 0, 40, 0, 0, 0, 1353902318),
(41, 13, '想太多妹子', '预售款 榴莲家秋冬装新款呢大衣女 双排扣气质呢大衣外套20281', 'http://img04.taobaocdn.com/bao/uploaded/i4/T1srf5Xm8XXXXV8lI__110350.jpg', 0, 41, 0, 0, 0, 1353902490),
(42, 8, '枕水而眠', '特卖款2012秋冬新款榴莲家 风衣帅气外套 带帽风衣外套LLS1009', 'http://img02.taobaocdn.com/bao/uploaded/i2/T1x7C0XhxqXXbW6xwT_012127.jpg', 0, 42, 0, 0, 0, 1353902490),
(43, 20, '熊小熊zz', '榴莲家2012秋季女装 韩版波点翻袖小西装外套 修身休闲西装 20072', 'http://img02.taobaocdn.com/bao/uploaded/i2/T1Ag54XbtuXXXfz.I5_060343.jpg', 0, 43, 0, 0, 0, 1353902490),
(44, 18, '晨雪熙', '预售款 榴莲家2012秋冬新款 RENEEVON★秋款绝美公主外套20398', 'http://img04.taobaocdn.com/bao/uploaded/i4/T1ugbYXkpdXXa56jsZ_033049.jpg', 0, 44, 0, 0, 0, 1353902490),
(45, 13, '想太多妹子', '预售定金 榴莲家 英伦双排扣毛呢外套牛角扣肩章羊毛呢大衣20459', 'http://img03.taobaocdn.com/bao/uploaded/i3/T1M463XeBdXXb0fkM9_074304.jpg', 0, 45, 0, 0, 0, 1353902490),
(46, 6, '起个名字太累', '远步正品 韩版潮 厚底松糕高帮帆布鞋子 学生休闲鞋 女式帆布鞋', 'http://img04.taobaocdn.com/bao/uploaded/i4/T1ZArWXkllXXX.ujTX_085705.jpg', 0, 46, 0, 0, 0, 1353902641),
(47, 11, '彩色淘', '淘金币 【远步正品】 经典糖果低帮系带韩版帆布鞋 潮 男女款情侣', 'http://img01.taobaocdn.com/bao/uploaded/i1/T1EzLEXaFlXXcpN3g3_050111.jpg', 0, 47, 0, 0, 0, 1353902641),
(48, 11, '彩色淘', '【一淘专享价】远步经典糖果低帮系带韩版帆布鞋 潮 男女款情侣鞋', 'http://img01.taobaocdn.com/bao/uploaded/i1/T16.j3XdlbXXa8hGnb_123051.jpg', 0, 48, 0, 0, 0, 1353902641),
(49, 13, '想太多妹子', '【远步正品】 男女帆布鞋韩版 高帮 学生情侣鞋', 'http://img03.taobaocdn.com/bao/uploaded/i3/T1qYjFXbXfXXXvyygU_015147.jpg', 0, 49, 0, 0, 0, 1353902641),
(50, 13, '想太多妹子', '【远步正品】2012秋冬新款 星星印花女式低帮帆布鞋学生鞋', 'http://img01.taobaocdn.com/bao/uploaded/i1/T1K_vfXlJaXXakVJ37_064254.jpg', 0, 50, 0, 0, 0, 1353902642),
(51, 12, '跳房子123', '【远步正品】男女款 越狱 低帮帆布鞋 情侣鞋', 'http://img02.taobaocdn.com/bao/uploaded/i2/T1RR2RXkNcXXceltU7_063938.jpg', 0, 51, 0, 0, 0, 1353902642),
(52, 6, '起个名字太累', '【远步正品】 越狱米勒系列厚底帆布鞋松糕鞋 欧美ca276', 'http://img01.taobaocdn.com/bao/uploaded/i1/T1wnqyXXNfXXa2j1I0_034801.jpg', 0, 52, 0, 0, 0, 1353902642),
(53, 14, '泡芙小米粒', '淘金币 【远步正品】 2012新款 星旗条纹男女帆布鞋情侣鞋子', 'http://img03.taobaocdn.com/bao/uploaded/i3/T197PPXgVoXXcy8OM._112623.jpg', 0, 53, 0, 0, 0, 1353902642),
(54, 8, '枕水而眠', '【远步正品】2012秋冬新款 英伦印花松糕厚底高帮鞋 松糕鞋女款', 'http://img04.taobaocdn.com/bao/uploaded/i4/T1ac2vXcRvXXXE1hsU_014747.jpg', 0, 54, 0, 0, 0, 1353902642),
(55, 17, 'V小莲小莲V', '【远步正品】2012秋冬新款 韩版星星印花女式低帮帆布鞋学生鞋', 'http://img02.taobaocdn.com/bao/uploaded/i2/T1E2O9XhFvXXbOmjZW_024241.jpg', 0, 55, 0, 0, 0, 1353902642),
(56, 9, 'wingsa区', '【远步正品】2012秋冬新款男女帆布鞋韩版 女 潮 高帮 学生情侣鞋', 'http://img04.taobaocdn.com/bao/uploaded/i4/T1l3fIXkFgXXc53Jk9_102745.jpg', 0, 56, 0, 0, 0, 1353902642),
(57, 16, 'Eudora_寻寻', '【远步正品】2012秋冬新款 印花高帮帆布鞋 韩版 学生女鞋', 'http://img01.taobaocdn.com/bao/uploaded/i1/T1msjzXfFmXXbavIAU_013829.jpg', 0, 57, 0, 0, 0, 1353902642),
(58, 19, '安土桃山', '【远步正品】 加厚松高鞋休闲棉帆布鞋 韩版厚底帆松糕鞋', 'http://img01.taobaocdn.com/bao/uploaded/i1/T1RKfEXkxkXXc.bh3U_014824.jpg', 0, 58, 0, 0, 0, 1353902643),
(59, 6, '起个名字太累', '【远步正品】2012秋冬季印花高帮帆布鞋 韩版 学生女鞋', 'http://img02.taobaocdn.com/bao/uploaded/i2/T1_tHLXn4fXXXLjDMT_013219.jpg', 0, 59, 0, 0, 0, 1353902643),
(60, 18, '晨雪熙', '远步正品 韩版潮 厚底松糕鞋 高帮布鞋子学生休闲鞋 女鞋帆布鞋', 'http://img03.taobaocdn.com/bao/uploaded/i3/T1A4n_XglcXXcUv5g0_035537.jpg', 0, 60, 0, 0, 0, 1353902643),
(61, 9, 'wingsa区', '【远步正品】2012秋冬新款时尚女士平底加绒中筒雪地靴 包邮', 'http://img02.taobaocdn.com/bao/uploaded/i2/T1MDaHXc0rXXaonAs9_104246.jpg', 0, 61, 0, 0, 0, 1353902643),
(62, 10, '设计系小女生', '【远步正品】  2011冬季时尚女士平底雪地靴 棉鞋', 'http://img03.taobaocdn.com/bao/uploaded/i3/T1hG1IXelfXXcX4o.9_105150.jpg', 0, 62, 0, 0, 0, 1353902643),
(63, 18, '晨雪熙', '南非进口黄柠檬 6个装 ', '1709/04/59ad10fab7bf9.jpg', 0, 63, 0, 0, 0, 1504514299),
(64, 19, '安土桃山', '智利进口新鲜蓝莓 4盒', '1709/04/59ad1128d930c.jpg', 0, 64, 0, 0, 0, 1504514345),
(65, 8, '枕水而眠', '美国进口红啤梨 6个', '1709/04/59ad116696dfb.jpg', 0, 65, 0, 0, 0, 1504514406),
(66, 20, '熊小熊zz', '美国进口无籽红提 1kg ', '1709/04/59ad119657ec3.jpg', 0, 66, 0, 0, 0, 1504514454),
(67, 8, '枕水而眠', '国产绿奇异果 16颗 ', '1709/04/59ad11bb8a1eb.jpg', 0, 67, 0, 0, 0, 1504514491),
(68, 18, '晨雪熙', '浙江涌泉蜜桔无核桔子5斤', '1709/04/59ad12a82ee26.jpg', 0, 68, 0, 0, 0, 1504514728);

-- --------------------------------------------------------

--
-- 表的结构 `pin_topic_at`
--

CREATE TABLE IF NOT EXISTS `pin_topic_at` (
  `uid` int(10) unsigned NOT NULL,
  `tid` int(10) unsigned NOT NULL,
  PRIMARY KEY (`uid`,`tid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `pin_topic_comment`
--

CREATE TABLE IF NOT EXISTS `pin_topic_comment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `uname` varchar(20) NOT NULL,
  `tid` int(10) unsigned NOT NULL,
  `author_uid` int(10) unsigned NOT NULL,
  `content` varchar(255) NOT NULL,
  `add_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `pin_topic_index`
--

CREATE TABLE IF NOT EXISTS `pin_topic_index` (
  `uid` int(10) unsigned NOT NULL COMMENT '用户ID',
  `tid` int(10) unsigned NOT NULL COMMENT '信息ID',
  `author_id` int(10) unsigned NOT NULL COMMENT '发布者ID',
  `add_time` int(10) unsigned NOT NULL,
  KEY `uid` (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `pin_topic_relation`
--

CREATE TABLE IF NOT EXISTS `pin_topic_relation` (
  `tid` int(10) unsigned NOT NULL COMMENT '信息ID',
  `src_tid` int(10) unsigned NOT NULL COMMENT '被引用信息ID',
  `author_uid` int(10) unsigned NOT NULL,
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '操作类型(1,转发)',
  PRIMARY KEY (`tid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `pin_user`
--

CREATE TABLE IF NOT EXISTS `pin_user` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uc_uid` int(10) unsigned NOT NULL DEFAULT '0',
  `username` varchar(20) NOT NULL DEFAULT '0',
  `password` varchar(32) NOT NULL DEFAULT '0',
  `email` varchar(50) NOT NULL,
  `gender` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1男，0女',
  `tags` varchar(50) NOT NULL COMMENT '个人标签',
  `intro` varchar(500) NOT NULL,
  `byear` smallint(4) unsigned NOT NULL,
  `bmonth` tinyint(2) unsigned NOT NULL,
  `bday` tinyint(2) unsigned NOT NULL,
  `province` varchar(20) NOT NULL,
  `city` varchar(20) NOT NULL,
  `score` int(10) unsigned NOT NULL DEFAULT '0',
  `score_level` int(10) unsigned NOT NULL DEFAULT '0',
  `cover` varchar(255) NOT NULL,
  `reg_ip` varchar(15) NOT NULL,
  `reg_time` int(10) unsigned NOT NULL DEFAULT '0',
  `last_time` int(10) unsigned NOT NULL DEFAULT '0',
  `last_ip` varchar(15) DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `shares` int(10) unsigned DEFAULT '0',
  `likes` int(10) unsigned DEFAULT '0',
  `follows` int(10) unsigned DEFAULT '0',
  `fans` int(10) unsigned DEFAULT '0',
  `albums` int(10) unsigned DEFAULT '0',
  `daren` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=22 ;

--
-- 转存表中的数据 `pin_user`
--

INSERT INTO `pin_user` (`id`, `uc_uid`, `username`, `password`, `email`, `gender`, `tags`, `intro`, `byear`, `bmonth`, `bday`, `province`, `city`, `score`, `score_level`, `cover`, `reg_ip`, `reg_time`, `last_time`, `last_ip`, `status`, `shares`, `likes`, `follows`, `fans`, `albums`, `daren`) VALUES
(1, 0, '安小然07', '96e79218965eb72c92a549dd5a330112', '', 1, '', '', 0, 0, 0, '', '', 0, 0, '', '192.168.1.111', 1353895892, 0, '0', 1, 0, 0, 0, 0, 0, 0),
(2, 0, 'D暖暖的色调D', '96e79218965eb72c92a549dd5a330112', '', 0, '', '', 0, 0, 0, '', '', 0, 0, '', '192.168.1.111', 1353895892, 0, '0', 1, 0, 0, 0, 0, 0, 0),
(3, 0, '洗耍耍洗耍', '96e79218965eb72c92a549dd5a330112', '', 0, '', '', 0, 0, 0, '', '', 0, 0, '', '192.168.1.111', 1353895892, 0, '0', 1, 0, 0, 0, 0, 0, 0),
(4, 0, '农家小雪', '96e79218965eb72c92a549dd5a330112', '', 0, '', '', 0, 0, 0, '', '', 0, 0, '', '192.168.1.111', 1353895892, 0, '0', 1, 0, 0, 0, 0, 0, 0),
(5, 0, '熊霹雳', '96e79218965eb72c92a549dd5a330112', '', 0, '', '', 0, 0, 0, '', '', 0, 0, '', '192.168.1.111', 1353895892, 0, '0', 1, 0, 0, 0, 0, 0, 0),
(6, 0, '起个名字太累', '96e79218965eb72c92a549dd5a330112', '', 1, '', '', 0, 0, 0, '', '', 10, 10, '', '192.168.1.111', 1353895892, 1353910265, '192.168.1.111', 1, 7, 0, 0, 0, 1, 0),
(7, 0, '咕咕是一只猫', '96e79218965eb72c92a549dd5a330112', '', 1, '', '', 0, 0, 0, '', '', 10, 10, '', '192.168.1.111', 1353895892, 1353910109, '192.168.1.111', 1, 2, 0, 0, 0, 1, 0),
(8, 0, '枕水而眠', '96e79218965eb72c92a549dd5a330112', '', 1, '', '', 0, 0, 0, '', '', 10, 10, '', '192.168.1.111', 1353895892, 1353910407, '192.168.1.111', 1, 9, 0, 0, 0, 1, 0),
(9, 0, 'wingsa区', '96e79218965eb72c92a549dd5a330112', '', 1, '', '', 0, 0, 0, '', '', 10, 10, '', '192.168.1.111', 1353895892, 1353909837, '192.168.1.111', 1, 2, 0, 0, 0, 1, 0),
(10, 0, '设计系小女生', '96e79218965eb72c92a549dd5a330112', '', 1, '', '', 0, 0, 0, '', '', 10, 10, '', '192.168.1.111', 1353895892, 1353910499, '192.168.1.111', 1, 4, 0, 0, 0, 1, 0),
(11, 0, '彩色淘', '96e79218965eb72c92a549dd5a330112', '', 0, '', '', 0, 0, 0, '', '', 10, 10, '', '192.168.1.111', 1353895892, 1353910069, '192.168.1.111', 1, 5, 0, 0, 0, 1, 0),
(12, 0, '跳房子123', '96e79218965eb72c92a549dd5a330112', '', 1, '', '', 0, 0, 0, '', '', 10, 10, '', '192.168.1.111', 1353895892, 1353910146, '192.168.1.111', 1, 4, 0, 0, 0, 1, 0),
(13, 0, '想太多妹子', '96e79218965eb72c92a549dd5a330112', '', 0, '', '', 0, 0, 0, '', '', 10, 10, '', '192.168.1.111', 1353895892, 1353909897, '192.168.1.111', 1, 5, 0, 0, 0, 1, 0),
(14, 0, '泡芙小米粒', '96e79218965eb72c92a549dd5a330112', '', 0, '', '', 0, 0, 0, '', '', 10, 10, '', '192.168.1.111', 1353895892, 1353910539, '192.168.1.111', 1, 5, 0, 0, 0, 1, 0),
(15, 0, 'Prickleman', '96e79218965eb72c92a549dd5a330112', '', 0, '', '', 0, 0, 0, '', '', 10, 10, '', '192.168.1.111', 1353895892, 1353910012, '192.168.1.111', 1, 1, 0, 0, 0, 1, 0),
(16, 0, 'Eudora_寻寻', '96e79218965eb72c92a549dd5a330112', '', 1, '', '', 0, 0, 0, '', '', 10, 10, '', '192.168.1.111', 1353895892, 1353909964, '192.168.1.111', 1, 2, 0, 0, 0, 1, 0),
(17, 0, 'V小莲小莲V', '96e79218965eb72c92a549dd5a330112', '2455009233@qq.com', 0, '', '', 0, 0, 0, '', '', 10, 10, '', '192.168.1.111', 1353895892, 1353910177, '192.168.1.111', 1, 3, 0, 0, 0, 1, 1),
(18, 0, '晨雪熙', '96e79218965eb72c92a549dd5a330112', '28d6c5@yk.com', 0, '', '', 0, 0, 0, '', '', 10, 10, '', '192.168.1.111', 1353895892, 1353910348, '192.168.1.111', 1, 9, 0, 0, 0, 1, 1),
(19, 0, '安土桃山', '96e79218965eb72c92a549dd5a330112', 'andery@qq.com', 0, '', '', 0, 0, 0, '', '', 10, 10, '', '192.168.1.111', 1353895892, 1353910445, '192.168.1.111', 1, 3, 0, 0, 0, 1, 1),
(20, 0, '熊小熊zz', '96e79218965eb72c92a549dd5a330112', '1@qq.com', 0, '', '', 0, 0, 0, '', '', 10, 10, '', '192.168.1.111', 1353895892, 1353910221, '192.168.1.111', 1, 7, 0, 0, 0, 1, 1),
(21, 0, 'wenhao2017', '870e0fb560ac33d462b2789c447d4259', '2082425285@qq.com', 1, '', '', 0, 0, 0, '', '', 0, 0, '', '127.0.0.1', 1486514665, 0, '0', 1, 0, 0, 0, 0, 0, 1);

-- --------------------------------------------------------

--
-- 表的结构 `pin_user_address`
--

CREATE TABLE IF NOT EXISTS `pin_user_address` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `consignee` varchar(20) NOT NULL,
  `address` varchar(255) NOT NULL,
  `zip` varchar(10) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `pin_user_bind`
--

CREATE TABLE IF NOT EXISTS `pin_user_bind` (
  `uid` int(10) unsigned NOT NULL,
  `type` varchar(60) NOT NULL,
  `keyid` varchar(100) NOT NULL,
  `info` text NOT NULL,
  KEY `uid` (`uid`),
  KEY `uid_type` (`uid`,`type`),
  KEY `type_keyid` (`type`,`keyid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `pin_user_follow`
--

CREATE TABLE IF NOT EXISTS `pin_user_follow` (
  `uid` int(10) unsigned NOT NULL COMMENT '用户ID',
  `follow_uid` int(10) unsigned NOT NULL COMMENT '被关注者ID',
  `add_time` int(10) unsigned NOT NULL,
  `mutually` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`uid`,`follow_uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `pin_user_msgtip`
--

CREATE TABLE IF NOT EXISTS `pin_user_msgtip` (
  `uid` int(10) unsigned NOT NULL,
  `type` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '1:关注，2:提到，3:私信，4:通知',
  `num` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`uid`,`type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `pin_user_stat`
--

CREATE TABLE IF NOT EXISTS `pin_user_stat` (
  `uid` int(10) unsigned NOT NULL,
  `action` varchar(20) NOT NULL,
  `num` int(10) unsigned NOT NULL,
  `last_time` int(10) unsigned NOT NULL,
  UNIQUE KEY `uid_type` (`uid`,`action`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `pin_user_stat`
--

INSERT INTO `pin_user_stat` (`uid`, `action`, `num`, `last_time`) VALUES
(9, 'login', 1, 1353909837),
(13, 'login', 1, 1353909897),
(16, 'login', 1, 1353909964),
(15, 'login', 1, 1353910012),
(11, 'login', 1, 1353910069),
(7, 'login', 1, 1353910109),
(12, 'login', 1, 1353910146),
(17, 'login', 1, 1353910177),
(20, 'login', 1, 1353910221),
(6, 'login', 1, 1353910265),
(18, 'login', 1, 1353910348),
(8, 'login', 1, 1353910407),
(19, 'login', 1, 1353910445),
(10, 'login', 1, 1353910499),
(14, 'login', 1, 1353910539);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
