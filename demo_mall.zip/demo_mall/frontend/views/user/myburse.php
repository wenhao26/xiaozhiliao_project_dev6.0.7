﻿<?php
use yii\helpers\Html;
use yii\widgets\LinkPager;
use yii\bootstrap\ActiveForm;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title><?=$title?></title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
<meta name="description" content="<?=$title?>">
<link rel="stylesheet" href="static/lib/weui.min.css">
<link rel="stylesheet" href="static/css/jquery-weui.css">
<link rel="stylesheet" href="static/css/style.css">
</head>
<body ontouchstart>
<!--主体-->
<header class="wy-header">
  <div class="wy-header-icon-back"><span></span></div>
  <div class="wy-header-title">小金库</div>
</header>
<div class="weui-content">
  <div class="weui-panel">
    <div class="weui-panel__hd">账户余额</div>
    <div class="weui-panel__bd">
      <div class="weui-media-box weui-media-box_text">
        <h4 class="weui-media-box__title">￥<em class="num">800.0</em></h4>
        <p class="weui-media-box__desc">账户余额由银行卡充值或者伟义商城发售的充值，可以购买商品和提现。</p>
        <ul class="weui-media-box__info">
          <li class="weui-media-box__info__meta">可提现金额：￥<em class="num">300.0</em></li>
          <li class="weui-media-box__info__meta weui-media-box__info__meta_extra">返现金额：￥<em class="num">500.0</em></li>
        </ul>
      </div>
    </div>
    <div class="weui-panel__ft">
      <a href="./?r=user/recharge" class="weui-cell weui-cell_access weui-cell_link">
        <div class="weui-cell__bd">余额充值</div>
        <span class="weui-cell__ft"></span>
      </a>    
    </div>
    <div class="weui-panel__ft">
      <a href="./?r=user/withdrawals" class="weui-cell weui-cell_access weui-cell_link">
        <div class="weui-cell__bd">余额提现</div>
        <span class="weui-cell__ft"></span>
      </a>    
    </div>
  </div>
  <div class="weui-panel">
    <div class="weui-panel__hd">待返还金额</div>
    <div class="weui-panel__bd">
      <div class="weui-media-box weui-media-box_text">
        <h4 class="weui-media-box__title">￥<em class="num">500.0</em></h4>
        <p class="weui-media-box__desc">待返还金额为伟义商城发布的充值返现活动所产生，可购买商品不能提现。</p>
        <ul class="weui-media-box__info">
          <li class="weui-media-box__info__meta">每月返现￥<em class="num">100.0</em></li>
          <li class="weui-media-box__info__meta weui-media-box__info__meta_extra">共<em class="num">5</em>个月</li>
        </ul>
      </div>
    </div>
  </div>
  <div class="weui-panel">
    <div class="weui-panel__hd">蓝豆</div>
    <div class="weui-panel__bd">
      <div class="weui-media-box weui-media-box_text">
        <h4 class="weui-media-box__title"><em class="num">165</em>个</h4>
        <p class="weui-media-box__desc">购买商品，评价订单以及参加商城的活动可获得，蓝豆可以直接购买商品。</p>
      </div>
    </div>
  </div>
  
</div>

<script src="static/lib/jquery-2.1.4.js"></script> 
<script src="static/lib/fastclick.js"></script> 
<script type="text/javascript" src="static/js/jquery.Spinner.js"></script>
<script>
  $(function() {
    FastClick.attach(document.body);
  });
</script>

<script src="static/js/jquery-weui.js"></script>
</body>
</html>

