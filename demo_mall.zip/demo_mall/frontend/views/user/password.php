﻿<?php
use yii\helpers\Html;
use yii\widgets\LinkPager;
use yii\bootstrap\ActiveForm;
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title><?=$title?></title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
<meta name="description" content="<?=$title?>">
<link rel="stylesheet" href="static/lib/weui.min.css">
<link rel="stylesheet" href="static/css/jquery-weui.css">
<link rel="stylesheet" href="static/css/style.css">
</head>
<body ontouchstart>
<!--主体-->
<header class="wy-header">
  <div class="wy-header-icon-back"><span></span></div>
  <div class="wy-header-title">密码修改</div>
</header>
<div class="weui-content">
  <div class="weui-cells cardlist">
    <a class="weui-cell weui-cell_access" href="./?r=user/modifyloginpsw">
      <div class="weui-cell__bd"><p>登陆密码修改</p></div>
      <div class="weui-cell__ft"></div>
    </a>
    <a class="weui-cell weui-cell_access" href="./?r=user/modifytradepsw">
      <div class="weui-cell__bd"><p>交易密码修改</p></div>
      <div class="weui-cell__ft"></div>
    </a>
  </div>
</div>

<script src="static/lib/jquery-2.1.4.js"></script> 
<script src="static/lib/fastclick.js"></script> 
<script type="text/javascript" src="static/js/jquery.Spinner.js"></script>
<script>
  $(function() {
    FastClick.attach(document.body);
  });
</script>

<script src="static/js/jquery-weui.js"></script>
</body>
</html>

