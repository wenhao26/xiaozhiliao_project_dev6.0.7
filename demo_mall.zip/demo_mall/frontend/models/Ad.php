<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "pin_ad".
 *
 * @property integer $id
 * @property integer $board_id
 * @property string $type
 * @property string $name
 * @property string $url
 * @property string $content
 * @property string $extimg
 * @property string $extval
 * @property string $desc
 * @property integer $start_time
 * @property integer $end_time
 * @property integer $clicks
 * @property integer $add_time
 * @property integer $ordid
 * @property integer $status
 */
class Ad extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'pin_ad';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['board_id', 'type', 'name', 'url', 'content', 'extimg', 'extval', 'desc', 'start_time', 'end_time'], 'required'],
            [['board_id', 'start_time', 'end_time', 'clicks', 'add_time', 'ordid', 'status'], 'integer'],
            [['content'], 'string'],
            [['type'], 'string', 'max' => 20],
            [['name'], 'string', 'max' => 50],
            [['url', 'extimg', 'desc'], 'string', 'max' => 255],
            [['extval'], 'string', 'max' => 200]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'board_id' => 'Board ID',
            'type' => 'Type',
            'name' => 'Name',
            'url' => 'Url',
            'content' => 'Content',
            'extimg' => 'Extimg',
            'extval' => 'Extval',
            'desc' => 'Desc',
            'start_time' => 'Start Time',
            'end_time' => 'End Time',
            'clicks' => 'Clicks',
            'add_time' => 'Add Time',
            'ordid' => 'Ordid',
            'status' => 'Status',
        ];
    }
}
