<?php

namespace frontend\models;

use Yii;

/**
 * This is the model class for table "pin_item".
 *
 * @property string $id
 * @property integer $cate_id
 * @property integer $orig_id
 * @property string $uid
 * @property string $uname
 * @property string $key_id
 * @property string $title
 * @property string $intro
 * @property string $img
 * @property string $price
 * @property double $rates
 * @property string $url
 * @property integer $type
 * @property string $hits
 * @property string $likes
 * @property string $comments
 * @property string $cmt_taobao_time
 * @property integer $add_time
 * @property string $tag_cache
 * @property string $comments_cache
 * @property string $seo_title
 * @property string $seo_keys
 * @property string $seo_desc
 * @property integer $ordid
 * @property integer $status
 */
class Item extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'pin_item';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['cate_id', 'orig_id', 'uid', 'type', 'hits', 'likes', 'comments', 'cmt_taobao_time', 'add_time', 'ordid', 'status'], 'integer'],
            [['orig_id', 'uname', 'intro', 'rates', 'add_time', 'tag_cache', 'comments_cache'], 'required'],
            [['price', 'rates'], 'number'],
            [['url', 'tag_cache', 'comments_cache', 'seo_desc'], 'string'],
            [['uname'], 'string', 'max' => 20],
            [['key_id'], 'string', 'max' => 50],
            [['title', 'intro', 'img', 'seo_title', 'seo_keys'], 'string', 'max' => 255],
            [['key_id'], 'unique']
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'cate_id' => 'Cate ID',
            'orig_id' => 'Orig ID',
            'uid' => 'Uid',
            'uname' => 'Uname',
            'key_id' => 'Key ID',
            'title' => 'Title',
            'intro' => 'Intro',
            'img' => 'Img',
            'price' => 'Price',
            'rates' => 'Rates',
            'url' => 'Url',
            'type' => 'Type',
            'hits' => 'Hits',
            'likes' => 'Likes',
            'comments' => 'Comments',
            'cmt_taobao_time' => 'Cmt Taobao Time',
            'add_time' => 'Add Time',
            'tag_cache' => 'Tag Cache',
            'comments_cache' => 'Comments Cache',
            'seo_title' => 'Seo Title',
            'seo_keys' => 'Seo Keys',
            'seo_desc' => 'Seo Desc',
            'ordid' => 'Ordid',
            'status' => 'Status',
        ];
    }
}
