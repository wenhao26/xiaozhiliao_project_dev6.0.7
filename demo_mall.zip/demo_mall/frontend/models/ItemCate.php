<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "pin_item_cate".
 *
 * @property integer $id
 * @property string $name
 * @property string $tags
 * @property integer $pid
 * @property string $spid
 * @property string $img
 * @property string $fcolor
 * @property string $remark
 * @property integer $add_time
 * @property string $items
 * @property integer $likes
 * @property integer $type
 * @property integer $ordid
 * @property integer $status
 * @property integer $is_index
 * @property integer $is_default
 * @property string $seo_title
 * @property string $seo_keys
 * @property string $seo_desc
 */
class ItemCate extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'pin_item_cate';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['name', 'tags', 'pid', 'spid', 'img', 'fcolor', 'remark', 'add_time', 'likes', 'status', 'seo_title', 'seo_keys', 'seo_desc'], 'required'],
            [['pid', 'add_time', 'items', 'likes', 'type', 'ordid', 'status', 'is_index', 'is_default'], 'integer'],
            [['remark', 'seo_desc'], 'string'],
            [['name', 'tags', 'spid'], 'string', 'max' => 50],
            [['img', 'seo_title', 'seo_keys'], 'string', 'max' => 255],
            [['fcolor'], 'string', 'max' => 10]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => 'Name',
            'tags' => 'Tags',
            'pid' => 'Pid',
            'spid' => 'Spid',
            'img' => 'Img',
            'fcolor' => 'Fcolor',
            'remark' => 'Remark',
            'add_time' => 'Add Time',
            'items' => 'Items',
            'likes' => 'Likes',
            'type' => 'Type',
            'ordid' => 'Ordid',
            'status' => 'Status',
            'is_index' => 'Is Index',
            'is_default' => 'Is Default',
            'seo_title' => 'Seo Title',
            'seo_keys' => 'Seo Keys',
            'seo_desc' => 'Seo Desc',
        ];
    }
}
