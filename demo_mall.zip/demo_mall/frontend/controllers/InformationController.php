<?php
namespace frontend\controllers;

use Yii;
use frontend\models\PasswordResetRequestForm;
use yii\base\InvalidParamException;
use yii\web\BadRequestHttpException;
use yii\web\Controller;
use yii\filters\VerbFilter;
use yii\filters\AccessControl;
// use frontend\models\Ad;
// use frontend\models\Item;

/**
 * Site controller
 */
class InformationController extends Controller
{
    /**
     * 商城资讯列表
     *
     * @return mixed
     */
    public function actionIndex()
    {
        // return $this->renderPartial('index', [
        //     'title' => '资讯-demo_mall是一家提供优质、实惠、正品的跨境购物商城'
        // ]);
        echo '暂无内容列表';
    }

    /**
     * 商城资讯列表
     *
     * @return mixed
     */
     public function actionDetail()
     {
        if (Yii::$app->request->get('id')) {
            return $this->renderPartial('detail', [
                'title' => '资讯详情-demo_mall是一家提供优质、实惠、正品的跨境购物商城'
            ]);
         }
        else {
            echo 'Request Errors！';
        } 
     }
}
