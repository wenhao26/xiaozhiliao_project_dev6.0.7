<?php
namespace frontend\controllers;

use Yii;
use frontend\models\PasswordResetRequestForm;
use yii\base\InvalidParamException;
use yii\web\BadRequestHttpException;
use yii\web\Controller;
use yii\filters\VerbFilter;
use yii\filters\AccessControl;
// use frontend\models\Ad;
// use frontend\models\Item;

/**
 * Site controller
 */
class CategoryController extends Controller
{
    /**
     * 分类管理列表
     *
     * @return mixed
     */
    public function actionIndex()
    {
        return $this->renderPartial('index', [
            'title' => '全部分类-demo_mall是一家提供优质、实惠、正品的跨境购物商城'
        ]);
    }
}
