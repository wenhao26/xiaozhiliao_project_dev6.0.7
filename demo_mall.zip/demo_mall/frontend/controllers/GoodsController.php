<?php
namespace frontend\controllers;

use Yii;
use frontend\models\PasswordResetRequestForm;
use yii\base\InvalidParamException;
use yii\web\BadRequestHttpException;
use yii\web\Controller;
use yii\filters\VerbFilter;
use yii\filters\AccessControl;
// use frontend\models\Ad;
// use frontend\models\Item;

/**
 * Site controller
 */
class GoodsController extends Controller
{
    /**
     * 产品列表
     *
     * @return mixed
     */
    public function actionIndex()
    {
        // $item_list = Item::find()
        // ->orderBy('id')
        // ->where(['status'=>1])
        // ->limit(10)
        // ->all();

        // var_dump($item_list);
  
        return $this->renderPartial('index', [
            'title' => '产品列表-demo_mall是一家提供优质、实惠、正品的跨境购物商城'
        ]);
    }

    /**
     * 产品详情
     *
     * @return mixed
     */
    public function actionDetail()
    {
        if (Yii::$app->request->get('id')) {
            return $this->renderPartial('detail', [
                'title' => '产品详情-demo_mall是一家提供优质、实惠、正品的跨境购物商城'
            ]);
        }
        else {
            echo 'Request Errors！';
        }
        
    }
}
