<?php
namespace frontend\controllers;

use Yii;
use frontend\models\PasswordResetRequestForm;
use yii\base\InvalidParamException;
use yii\web\BadRequestHttpException;
use yii\web\Controller;
use yii\filters\VerbFilter;
use yii\filters\AccessControl;
// use frontend\models\Ad;
// use frontend\models\Item;

/**
 * Site controller
 */
class PlaceorderController extends Controller
{
    /**
     * 提交订单
     *
     * @return mixed
     */
    public function actionIndex()
    {
        return $this->renderPartial('index', [
            'title' => '订单结算-demo_mall是一家提供优质、实惠、正品的跨境购物商城'
        ]);
    }

    /**
     * 提交订单-立即购买
     *
     * @return mixed
     */
     public function actionBuynow()
     {
         return $this->renderPartial('buynow', [
             'title' => '立即购买-demo_mall是一家提供优质、实惠、正品的跨境购物商城'
         ]);
     }
}
