<?php
namespace frontend\controllers;

use Yii;
use frontend\models\PasswordResetRequestForm;
use yii\base\InvalidParamException;
use yii\web\BadRequestHttpException;
use yii\web\Controller;
use yii\filters\VerbFilter;
use yii\filters\AccessControl;
use frontend\models\Ad;
use frontend\models\Item;

/**
 * Site controller
 */
class IndexController extends Controller
{
    /**
     * 商城首页
     *
     * @return mixed
     */
    public function actionIndex()
    {
        // $yii_cache = Yii::$app->cache;
        // $index_benner = $yii_cache->get('ad15_key');
	    // if ($index_benner === false) {
	    //     $index_benner = Ad::find()
	    //     ->orderBy('ordid')
	    //     ->where(['board_id'=>15, 'status'=>1])
	    //     ->limit(4)
        //     ->all();
        // }
        
        $item_list = Item::find()
        ->orderBy('id')
        ->where(['status'=>1])
        ->limit(10)
        ->all();

        // var_dump($item_list);

            
        return $this->renderPartial('index', [
            'title' => '商城首页-demo_mall是一家提供优质、实惠、正品的跨境购物商城'
        ]);
    }
}
