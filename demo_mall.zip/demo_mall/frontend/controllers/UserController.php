<?php
namespace frontend\controllers;

use Yii;
use frontend\models\PasswordResetRequestForm;
use yii\base\InvalidParamException;
use yii\web\BadRequestHttpException;
use yii\web\Controller;
use yii\filters\VerbFilter;
use yii\filters\AccessControl;
// use frontend\models\Ad;
// use frontend\models\Item;

/**
 * Site controller
 */
class UserController extends Controller
{
    /**
     * 分类管理列表
     *
     * @return mixed
     */
    public function actionIndex()
    {
        return $this->renderPartial('index', [
            'title' => '我的管理-demo_mall是一家提供优质、实惠、正品的跨境购物商城'
        ]);
    }

    /**
     * 订单管理
     *
     * @return mixed
     */
    public function actionOrders()
    {
        return $this->renderPartial('orders', [
            'title' => '全部订单-demo_mall是一家提供优质、实惠、正品的跨境购物商城'
        ]); 
    }

    /**
     * 发表评价评价
     *
     * @return mixed
     */
    public function actionComments()
    {
        return $this->renderPartial('comments', [
            'title' => '发表评价-demo_mall是一家提供优质、实惠、正品的跨境购物商城'
        ]);
    } 

    /**
     * 我的钱包
     *
     * @return mixed
     */
    public function actionMyburse()
    {
        return $this->renderPartial('myburse', [
            'title' => '我的钱包-demo_mall是一家提供优质、实惠、正品的跨境购物商城'
        ]);
    }

    /**
     * 钱包充值
     *
     * @return mixed
     */
    public function actionRecharge()
    {
        return $this->renderPartial('recharge', [
            'title' => '充值-demo_mall是一家提供优质、实惠、正品的跨境购物商城'
        ]);
    }

    /**
     * 钱包提现
     *
     * @return mixed
     */
     public function actionWithdrawals()
     {
         echo '功能尚未完善';
     }

    /**
     * 交易记录
     *
     * @return mixed
     */
    public function actionTraderecord()
    {
        return $this->renderPartial('traderecord', [
            'title' => '交易记录-demo_mall是一家提供优质、实惠、正品的跨境购物商城'
        ]);
    }

    /**
     * 我的收藏
     *
     * @return mixed
     */
    public function actionMycollection()
    {
        return $this->renderPartial('mycollection', [
            'title' => '我的收藏-demo_mall是一家提供优质、实惠、正品的跨境购物商城'
        ]);
    }

        /**
     * 收货地址管理
     *
     * @return mixed
     */
     public function actionAddresslist()
     {
         return $this->renderPartial('addresslist', [
             'title' => '收货地址管理-demo_mall是一家提供优质、实惠、正品的跨境购物商城'
         ]);
     }
 
     /**
      * 添加地址
      *
      * @return mixed
      */
     public function actionAddressadd()
     {
         return $this->renderPartial('addressadd', [
             'title' => '添加地址-demo_mall是一家提供优质、实惠、正品的跨境购物商城'
         ]);
     }
 
     /**
      * 编辑地址
      *
      * @return mixed
      */
     public function actionAddressedit()
     {
         return $this->renderPartial('addressedit', [
             'title' => '编辑地址-demo_mall是一家提供优质、实惠、正品的跨境购物商城'
         ]);
     } 

    /**
     * 我的银行卡管理
     *
     * @return mixed
     */
    public function actionMybankcard()
    {
        return $this->renderPartial('mybankcard', [
            'title' => '银行卡管理-demo_mall是一家提供优质、实惠、正品的跨境购物商城'
        ]);
    }

    /**
     * 添加银行卡
     *
     * @return mixed
     */
    public function actionAddbankcard()
    {
        return $this->renderPartial('addbankcard', [
            'title' => '添加银行卡-demo_mall是一家提供优质、实惠、正品的跨境购物商城'
        ]);
    }

    /**
     * 密码管理
     *
     * @return mixed
     */
    public function actionPassword()
    {
        return $this->renderPartial('password', [
            'title' => '密码管理-demo_mall是一家提供优质、实惠、正品的跨境购物商城'
        ]);
    }

    /**
     * 修改登录密码
     *
     * @return mixed
     */
     public function actionModifyloginpsw()
     {
         return $this->renderPartial('modifyloginpsw', [
             'title' => '修改登录密码-demo_mall是一家提供优质、实惠、正品的跨境购物商城'
         ]);
     }

     /**
     * 修改交易密码
     *
     * @return mixed
     */
    public function actionModifytradepsw()
    {
        return $this->renderPartial('modifytradepsw', [
            'title' => '修改交易密码-demo_mall是一家提供优质、实惠、正品的跨境购物商城'
        ]);
    }

    /**
     * 会员登录
     *
     * @return mixed
     */
    public function actionLogin()
    {
        return $this->renderPartial('login', [
            'title' => '登陆-demo_mall是一家提供优质、实惠、正品的跨境购物商城'
        ]);
    }

    /**
     * 会员注册
     *
     * @return mixed
     */
    public function actionRegist()
    {
        return $this->renderPartial('regist', [
            'title' => '注册-demo_mall是一家提供优质、实惠、正品的跨境购物商城'
        ]);
    }
}
